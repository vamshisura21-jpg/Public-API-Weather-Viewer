# Public API Weather Viewer: Executive Meteorological Report
**Generated On:** 2026-11-20 11:48:20 | **Project:** CampusSolve #111

## 1. Executive Summary & Core Aggregates

| Metric Description | Value |
| :--- | :--- |
| **Total Monitored Stations** | 40 stations |
| **Average Temperature** | 16.8 °C (62.2 °F) |
| **Temperature Extremes** | Min: -28.5 °C / Max: 48.2 °C |
| **Median Temperature** | 16.6 °C |
| **Average Relative Humidity** | 64.41 % |
| **Mean Wind Speed** | 22.32 km/h (Peak: 105.0 km/h) |
| **Cumulative Precipitation** | 222.5 mm (Peak: 92.4 mm) |
| **Mean Surface Pressure** | 1007.44 hPa |
| **Critical Limit Breaches** | **7** alerts |
| **Warning Advisories** | 2 advisories |
| **Nominal Stations** | 31 stations |

## 2. Threshold Warning & Anomaly Register

| Station | Temperature | Wind | Precip | Active Status Warnings |
| :--- | :--- | :--- | :--- | :--- |
| **Helsinki** (Finland) | 0.0°C | 14.0 km/h | 0.5 mm | WARNING: Freezing Frost Risk (<=0°C) |
| **Yakutsk** (Russia) | -28.5°C | 12.0 km/h | 1.2 mm | CRITICAL: Extreme Sub-Zero Freeze (<=-10°C) |
| **Death Valley** (United States) | 48.2°C | 22.0 km/h | 0.0 mm | CRITICAL: Extreme Heat Wave (>=40°C)<br>WARNING: Extreme Aridity / Fire Hazard (<=15%) |
| **Cherrapunji** (India) | 21.0°C | 34.0 km/h | 92.4 mm | CRITICAL: Torrential Downpour / Flood Risk (>=50mm)<br>NOTICE: Saturated Humidity (>=95%) |
| **Wellington** (New Zealand) | 15.0°C | 88.5 km/h | 12.0 mm | CRITICAL: Severe Gale / Storm Wind (>=80km/h) |
| **Atacama** (Chile) | 26.0°C | 16.0 km/h | 0.0 mm | WARNING: Extreme Aridity / Fire Hazard (<=15%) |
| **Key West** (United States) | 28.5°C | 105.0 km/h | 65.0 mm | CRITICAL: Severe Gale / Storm Wind (>=80km/h)<br>CRITICAL: Torrential Downpour / Flood Risk (>=50mm) |
| **Zermatt** (Switzerland) | -12.4°C | 25.0 km/h | 6.8 mm | CRITICAL: Extreme Sub-Zero Freeze (<=-10°C) |
| **Kuwait City** (Kuwait) | 46.8°C | 28.0 km/h | 0.0 mm | CRITICAL: Extreme Heat Wave (>=40°C) |

## 3. Station Records Audit Table

| ID | City | Country | Temp (°C) | Humidity (%) | Wind (km/h) | Condition | Data Source |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `WTR-1001` | Tokyo | Japan | 18.5 | 58.0% | 12.4 | Mainly Clear | Open-Meteo Public API |
| `WTR-1002` | London | United Kingdom | 11.2 | 82.0% | 21.0 | Slight Rain | Open-Meteo Public API |
| `WTR-1003` | New York | United States | 14.8 | 52.0% | 15.6 | Clear Sky | Open-Meteo Public API |
| `WTR-1004` | Paris | France | 13.0 | 74.0% | 11.8 | Partly Cloudy | Open-Meteo Public API |
| `WTR-1005` | Singapore | Singapore | 31.4 | 84.0% | 8.5 | Slight Rain Showers | Open-Meteo Public API |
| `WTR-1006` | Sydney | Australia | 23.6 | 62.0% | 19.4 | Mainly Clear | Open-Meteo Public API |
| `WTR-1007` | Mumbai | India | 32.8 | 76.0% | 14.0 | Partly Cloudy | Open-Meteo Public API |
| `WTR-1008` | Berlin | Germany | 9.4 | 80.0% | 16.5 | Overcast | Open-Meteo Public API |
| `WTR-1009` | Toronto | Canada | 6.8 | 68.0% | 22.0 | Partly Cloudy | Open-Meteo Public API |
| `WTR-1010` | Dubai | United Arab Emirates | 34.0 | 45.0% | 18.2 | Clear Sky | Open-Meteo Public API |
| `WTR-1011` | Cairo | Egypt | 27.5 | 38.0% | 15.0 | Clear Sky | Open-Meteo Public API |
| `WTR-1012` | Zurich | Switzerland | 8.1 | 85.0% | 10.5 | Slight Rain | Open-Meteo Public API |
| `WTR-1013` | Seoul | South Korea | 12.6 | 54.0% | 13.0 | Mainly Clear | Open-Meteo Public API |
| `WTR-1014` | Bangkok | Thailand | 33.2 | 78.0% | 9.2 | Slight Rain Showers | Open-Meteo Public API |
| `WTR-1015` | San Francisco | United States | 16.2 | 75.0% | 24.5 | Foggy | Open-Meteo Public API |
| `WTR-1016` | Rome | Italy | 19.8 | 60.0% | 11.0 | Mainly Clear | Open-Meteo Public API |
| `WTR-1017` | Madrid | Spain | 17.0 | 48.0% | 14.3 | Clear Sky | Open-Meteo Public API |
| `WTR-1018` | Nairobi | Kenya | 24.0 | 55.0% | 16.0 | Partly Cloudy | Open-Meteo Public API |
| `WTR-1019` | Buenos Aires | Argentina | 22.4 | 65.0% | 17.5 | Mainly Clear | Open-Meteo Public API |
| `WTR-1020` | Auckland | New Zealand | 18.0 | 72.0% | 26.0 | Overcast | Open-Meteo Public API |
| `WTR-1021` | Helsinki | Finland | 0.0 | 88.0% | 14.0 | Slight Snow Fall | Stored Benchmark |
| `WTR-1022` | Bergen | Norway | 7.4 | 100.0% | 28.0 | Moderate Rain | Stored Benchmark |
| `WTR-1023` | Riyadh | Saudi Arabia | 29.0 | 18.0% | 12.0 | Clear Sky | Stored Benchmark |
| `WTR-1024` | Quito | Ecuador | 16.0 | 60.0% | 0.0 | Mainly Clear | Stored Benchmark |
| `WTR-1025` | Reykjavik | Iceland | 1.2 | 79.0% | 32.0 | Overcast | Stored Benchmark |

*... and 15 additional stations stored in persistent database.*

---
*Report compiled automatically by CampusSolve Public API Weather Viewer.*