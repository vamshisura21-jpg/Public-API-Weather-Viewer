/**
 * app.js - CampusSolve Project #111: Public API Weather Viewer
 * Client-Side Core Engine: Live API Fetcher, Defensive Validation, Dynamic Metrics,
 * Chart.js Visualizations, Multi-Format Exporters, and Bulk CSV Validator.
 */

// Global State
let weatherRecords = [];
let filteredRecords = [];
let currentPage = 1;
const pageSize = 8;
let activeChartMode = 'temp';
let weatherChartInstance = null;

// WMO Weather Interpretation Table
const WMO_CODES = {
  0: "Clear Sky",
  1: "Mainly Clear",
  2: "Partly Cloudy",
  3: "Overcast",
  45: "Foggy",
  48: "Depositing Rime Fog",
  51: "Light Drizzle",
  53: "Moderate Drizzle",
  55: "Dense Drizzle",
  61: "Slight Rain",
  63: "Moderate Rain",
  65: "Heavy Rain",
  71: "Slight Snow Fall",
  73: "Moderate Snow Fall",
  75: "Heavy Snow Fall",
  77: "Snow Grains",
  80: "Slight Rain Showers",
  81: "Moderate Rain Showers",
  82: "Violent Rain Showers",
  85: "Slight Snow Showers",
  86: "Heavy Snow Showers",
  95: "Thunderstorm",
  96: "Thunderstorm with Hail",
  99: "Heavy Severe Thunderstorm"
};

// Known Coordinates Fallback Cache
const CITY_GEO_LOOKUP = {
  "Tokyo": { lat: 35.6762, lon: 139.6503, country: "Japan" },
  "London": { lat: 51.5074, lon: -0.1278, country: "United Kingdom" },
  "New York": { lat: 40.7128, lon: -74.0060, country: "United States" },
  "Paris": { lat: 48.8566, lon: 2.3522, country: "France" },
  "Singapore": { lat: 1.3521, lon: 103.8198, country: "Singapore" },
  "Sydney": { lat: -33.8688, lon: 151.2093, country: "Australia" },
  "Mumbai": { lat: 19.0760, lon: 72.8777, country: "India" },
  "Berlin": { lat: 52.5200, lon: 13.4050, country: "Germany" },
  "Dubai": { lat: 25.2048, lon: 55.2708, country: "United Arab Emirates" },
  "Death Valley": { lat: 36.5323, lon: -116.9325, country: "United States" },
  "Yakutsk": { lat: 62.0355, lon: 129.6755, country: "Russia" }
};

// Preloaded Seed Dataset (guarantees instant zero-friction offline execution)
const EMBEDDED_SEED_RECORDS = [
  { id: "WTR-1001", city: "Tokyo", country: "Japan", latitude: 35.6762, longitude: 139.6503, temperature_c: 18.5, apparent_temperature_c: 17.8, humidity_pct: 58.0, wind_speed_kmh: 12.4, precipitation_mm: 0.0, surface_pressure_hpa: 1014.2, weather_code: 1, condition_description: "Mainly Clear", recorded_at: "2026-11-20T08:00:00", data_source: "Open-Meteo Public API", notes: "Nominal autumn morning" },
  { id: "WTR-1002", city: "London", country: "United Kingdom", latitude: 51.5074, longitude: -0.1278, temperature_c: 11.2, apparent_temperature_c: 9.8, humidity_pct: 82.0, wind_speed_kmh: 21.0, precipitation_mm: 2.4, surface_pressure_hpa: 1008.5, weather_code: 61, condition_description: "Slight Rain", recorded_at: "2026-11-20T08:15:00", data_source: "Open-Meteo Public API", notes: "Overcast with light drizzle" },
  { id: "WTR-1003", city: "New York", country: "United States", latitude: 40.7128, longitude: -74.0060, temperature_c: 14.8, apparent_temperature_c: 13.9, humidity_pct: 52.0, wind_speed_kmh: 15.6, precipitation_mm: 0.0, surface_pressure_hpa: 1018.0, weather_code: 0, condition_description: "Clear Sky", recorded_at: "2026-11-20T08:30:00", data_source: "Open-Meteo Public API", notes: "Clear conditions" },
  { id: "WTR-1004", city: "Paris", country: "France", latitude: 48.8566, longitude: 2.3522, temperature_c: 13.0, apparent_temperature_c: 12.1, humidity_pct: 74.0, wind_speed_kmh: 11.8, precipitation_mm: 0.2, surface_pressure_hpa: 1016.3, weather_code: 2, condition_description: "Partly Cloudy", recorded_at: "2026-11-20T08:45:00", data_source: "Open-Meteo Public API", notes: "Mild autumn weather" },
  { id: "WTR-1005", city: "Singapore", country: "Singapore", latitude: 1.3521, longitude: 103.8198, temperature_c: 31.4, apparent_temperature_c: 37.8, humidity_pct: 84.0, wind_speed_kmh: 8.5, precipitation_mm: 8.6, surface_pressure_hpa: 1010.2, weather_code: 80, condition_description: "Slight Rain Showers", recorded_at: "2026-11-20T09:00:00", data_source: "Open-Meteo Public API", notes: "Tropical afternoon shower" },
  { id: "WTR-1006", city: "Sydney", country: "Australia", latitude: -33.8688, longitude: 151.2093, temperature_c: 23.6, apparent_temperature_c: 24.1, humidity_pct: 62.0, wind_speed_kmh: 19.4, precipitation_mm: 0.0, surface_pressure_hpa: 1020.1, weather_code: 1, condition_description: "Mainly Clear", recorded_at: "2026-11-20T09:15:00", data_source: "Open-Meteo Public API", notes: "Pleasant coastal breeze" },
  { id: "WTR-1007", city: "Mumbai", country: "India", latitude: 19.0760, longitude: 72.8777, temperature_c: 32.8, apparent_temperature_c: 38.2, humidity_pct: 76.0, wind_speed_kmh: 14.0, precipitation_mm: 0.0, surface_pressure_hpa: 1011.8, weather_code: 2, condition_description: "Partly Cloudy", recorded_at: "2026-11-20T09:30:00", data_source: "Open-Meteo Public API", notes: "Warm coastal conditions" },
  { id: "WTR-1008", city: "Berlin", country: "Germany", latitude: 52.5200, longitude: 13.4050, temperature_c: 9.4, apparent_temperature_c: 7.6, humidity_pct: 80.0, wind_speed_kmh: 16.5, precipitation_mm: 1.1, surface_pressure_hpa: 1012.4, weather_code: 3, condition_description: "Overcast", recorded_at: "2026-11-20T09:45:00", data_source: "Open-Meteo Public API", notes: "Brisk cloud cover" },
  { id: "WTR-1009", city: "Toronto", country: "Canada", latitude: 43.6532, longitude: -79.3832, temperature_c: 6.8, apparent_temperature_c: 3.9, humidity_pct: 68.0, wind_speed_kmh: 22.0, precipitation_mm: 0.0, surface_pressure_hpa: 1017.5, weather_code: 2, condition_description: "Partly Cloudy", recorded_at: "2026-11-20T10:00:00", data_source: "Open-Meteo Public API", notes: "Crisp temperate lake breeze" },
  { id: "WTR-1010", city: "Dubai", country: "United Arab Emirates", latitude: 25.2048, longitude: 55.2708, temperature_c: 34.0, apparent_temperature_c: 36.2, humidity_pct: 45.0, wind_speed_kmh: 18.2, precipitation_mm: 0.0, surface_pressure_hpa: 1013.9, weather_code: 0, condition_description: "Clear Sky", recorded_at: "2026-11-20T10:15:00", data_source: "Open-Meteo Public API", notes: "Sunny desert heat" },
  { id: "WTR-1021", city: "Helsinki", country: "Finland", latitude: 60.1699, longitude: 24.9384, temperature_c: 0.0, apparent_temperature_c: -3.5, humidity_pct: 88.0, wind_speed_kmh: 14.0, precipitation_mm: 0.5, surface_pressure_hpa: 1013.25, weather_code: 71, condition_description: "Slight Snow Fall", recorded_at: "2026-11-20T13:00:00", data_source: "Stored Benchmark", notes: "Boundary: exact 0.0°C freeze" },
  { id: "WTR-1022", city: "Bergen", country: "Norway", latitude: 60.3913, longitude: 5.3221, temperature_c: 7.4, apparent_temperature_c: 5.1, humidity_pct: 100.0, wind_speed_kmh: 28.0, precipitation_mm: 18.5, surface_pressure_hpa: 1002.0, weather_code: 63, condition_description: "Moderate Rain", recorded_at: "2026-11-20T13:15:00", data_source: "Stored Benchmark", notes: "Boundary: 100% saturation" },
  { id: "WTR-1029", city: "Yakutsk", country: "Russia", latitude: 62.0355, longitude: 129.6755, temperature_c: -28.5, apparent_temperature_c: -36.2, humidity_pct: 82.0, wind_speed_kmh: 12.0, precipitation_mm: 1.2, surface_pressure_hpa: 1028.0, weather_code: 75, condition_description: "Heavy Snow Fall", recorded_at: "2026-11-20T15:00:00", data_source: "Extreme Weather Station", notes: "Edge: extreme sub-zero Siberian frost" },
  { id: "WTR-1030", city: "Death Valley", country: "United States", latitude: 36.5323, longitude: -116.9325, temperature_c: 48.2, apparent_temperature_c: 46.5, humidity_pct: 9.5, wind_speed_kmh: 22.0, precipitation_mm: 0.0, surface_pressure_hpa: 1011.0, weather_code: 0, condition_description: "Clear Sky", recorded_at: "2026-11-20T15:15:00", data_source: "Extreme Weather Station", notes: "Edge: extreme heatwave & aridity" },
  { id: "WTR-1031", city: "Cherrapunji", country: "India", latitude: 25.2744, longitude: 91.7323, temperature_c: 21.0, apparent_temperature_c: 23.5, humidity_pct: 98.0, wind_speed_kmh: 34.0, precipitation_mm: 92.4, surface_pressure_hpa: 998.0, weather_code: 65, condition_description: "Heavy Rain", recorded_at: "2026-11-20T15:30:00", data_source: "Extreme Weather Station", notes: "Edge: torrential downpour flood alert" },
  { id: "WTR-1032", city: "Wellington", country: "New Zealand", latitude: -41.2865, longitude: 174.7762, temperature_c: 15.0, apparent_temperature_c: 11.2, humidity_pct: 84.0, wind_speed_kmh: 88.5, precipitation_mm: 12.0, surface_pressure_hpa: 990.2, weather_code: 82, condition_description: "Violent Rain Showers", recorded_at: "2026-11-20T15:45:00", data_source: "Extreme Weather Station", notes: "Edge: severe gale storm wind alert" }
];

// Initialize on DOM Load
document.addEventListener("DOMContentLoaded", () => {
  initClock();
  initData();
});

function initClock() {
  const update = () => {
    const now = new Date();
    const el = document.getElementById("clock-display");
    if (el) el.innerText = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };
  update();
  setInterval(update, 1000);
}

// Data Initialization (Fetch sample_data.json or fallback to embedded seeds)
async function initData() {
  try {
    const res = await fetch("sample_data.json");
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        weatherRecords = data;
      } else {
        weatherRecords = EMBEDDED_SEED_RECORDS;
      }
    } else {
      weatherRecords = EMBEDDED_SEED_RECORDS;
    }
  } catch (err) {
    // If running from file:// protocol where fetch is restricted by browser sandbox
    weatherRecords = EMBEDDED_SEED_RECORDS;
  }

  // Pre-calculate threshold indicators for all records
  weatherRecords = weatherRecords.map(r => normalizeRecord(r));
  filteredRecords = [...weatherRecords];

  // Refresh Views
  updateExecutiveSummary();
  renderTable();
  initOrUpdateChart();
}

function normalizeRecord(r) {
  const temp_c = parseFloat(r.temperature_c) || 0.0;
  const temp_f = (temp_c * 9 / 5) + 32;
  const wind_kmh = parseFloat(r.wind_speed_kmh) || 0.0;
  const precip_mm = parseFloat(r.precipitation_mm) || 0.0;
  const hum_pct = parseFloat(r.humidity_pct) || 0.0;

  // Derive status indicators
  const flags = [];
  if (temp_c >= 40.0) flags.push("CRITICAL: Extreme Heat Wave (>=40°C)");
  else if (temp_c >= 35.0) flags.push("WARNING: High Heat Advisory (>=35°C)");
  else if (temp_c <= -10.0) flags.push("CRITICAL: Sub-Zero Freeze (<=-10°C)");
  else if (temp_c <= 0.0) flags.push("WARNING: Freezing Frost Risk (<=0°C)");

  if (wind_kmh >= 80.0) flags.push("CRITICAL: Severe Gale / Storm (>=80km/h)");
  else if (wind_kmh >= 50.0) flags.push("WARNING: High Wind Alert (>=50km/h)");

  if (precip_mm >= 50.0) flags.push("CRITICAL: Torrential Downpour (>=50mm)");
  else if (precip_mm >= 20.0) flags.push("WARNING: Heavy Rain (>=20mm)");

  if (hum_pct >= 95.0) flags.push("NOTICE: Saturated Air (>=95%)");
  else if (hum_pct <= 15.0) flags.push("WARNING: Extreme Aridity Fire Risk (<=15%)");

  if (flags.length === 0) flags.push("NORMAL: Nominal Operations");

  const hasCritical = flags.some(f => f.startsWith("CRITICAL:"));
  const hasWarning = flags.some(f => f.startsWith("WARNING:") || f.startsWith("CRITICAL:"));

  return {
    ...r,
    temperature_c: temp_c,
    temperature_f: Math.round(temp_f * 10) / 10,
    wind_speed_kmh: wind_kmh,
    precipitation_mm: precip_mm,
    humidity_pct: hum_pct,
    status_indicators: flags,
    has_critical_alert: hasCritical,
    has_warning: hasWarning
  };
}

// Defensive Input Validation (Real-time feedback)
function validateCityRealtime(val) {
  const badge = document.getElementById("validation-feedback");
  const cleaned = val.trim();
  const cityRegex = /^[A-Za-z\s\-'.]{2,60}$/;

  if (!cleaned) {
    badge.innerHTML = `<span class="validation-badge invalid">✘ City name cannot be blank</span>`;
    return false;
  }
  if (cleaned.length < 2) {
    badge.innerHTML = `<span class="validation-badge invalid">✘ Minimum 2 characters required</span>`;
    return false;
  }
  if (!cityRegex.test(cleaned)) {
    badge.innerHTML = `<span class="validation-badge invalid">✘ Only letters, hyphens, and spaces allowed</span>`;
    return false;
  }

  badge.innerHTML = `<span class="validation-badge valid">✔ Valid city name format ("${cleaned}")</span>`;
  return true;
}

function quickSelectCity(name) {
  const input = document.getElementById("city-input");
  input.value = name;
  validateCityRealtime(name);
  handleFetchWeather();
}

// Live Public API Weather Querying (Open-Meteo + Mock Fallback)
async function handleFetchWeather() {
  const input = document.getElementById("city-input");
  const cityName = input.value.trim();
  if (!validateCityRealtime(cityName)) return;

  const btn = document.getElementById("btn-fetch");
  btn.disabled = true;
  btn.innerHTML = `<span>⏳</span> Querying...`;

  try {
    let lat = 0, lon = 0, country = "Global", source = "Live Open-Meteo Public API";

    // 1. Geocode City Name via Open-Meteo Geocoding
    try {
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&language=en&format=json`;
      const geoRes = await fetch(geoUrl, { signal: AbortSignal.timeout(4000) });
      if (geoRes.ok) {
        const geoData = await geoRes.json();
        if (geoData.results && geoData.results.length > 0) {
          lat = geoData.results[0].latitude;
          lon = geoData.results[0].longitude;
          country = geoData.results[0].country || "Global";
        }
      }
    } catch (e) {
      // Offline fallback geocode lookup
      const cached = CITY_GEO_LOOKUP[cityName] || { lat: 25.0, lon: 45.0, country: "International" };
      lat = cached.lat;
      lon = cached.lon;
      country = cached.country;
      source = "Offline Geocoding Fallback";
    }

    // 2. Fetch Weather from Open-Meteo Forecast
    let weatherData = null;
    try {
      const forecastUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,surface_pressure,wind_speed_10m`;
      const fRes = await fetch(forecastUrl, { signal: AbortSignal.timeout(4000) });
      if (fRes.ok) {
        weatherData = await fRes.json();
      }
    } catch (e) {
      source = "Mock Simulation Engine (Offline Fallback)";
    }

    let record;
    const nowIso = new Date().toISOString().replace(/\.\d+Z$/, "");

    if (weatherData && weatherData.current) {
      const c = weatherData.current;
      const code = c.weather_code || 0;
      record = normalizeRecord({
        id: `WTR-${Date.now().toString().slice(-4)}`,
        city: cityName,
        country: country,
        latitude: lat,
        longitude: lon,
        temperature_c: c.temperature_2m,
        apparent_temperature_c: c.apparent_temperature || c.temperature_2m,
        humidity_pct: c.relative_humidity_2m,
        wind_speed_kmh: c.wind_speed_10m,
        precipitation_mm: c.precipitation || 0.0,
        surface_pressure_hpa: c.surface_pressure || 1013.25,
        weather_code: code,
        condition_description: WMO_CODES[code] || "Nominal Weather",
        recorded_at: nowIso,
        data_source: source,
        notes: `Retrieved via ${source}`
      });
    } else {
      // Mock Fallback generator
      const baseTemp = cityName.toLowerCase().includes("death") ? 47.5 :
                       (cityName.toLowerCase().includes("yakut") ? -27.0 : 21.0);
      const code = baseTemp > 40 ? 0 : (baseTemp < 0 ? 73 : 2);
      record = normalizeRecord({
        id: `WTR-${Date.now().toString().slice(-4)}`,
        city: cityName,
        country: country,
        latitude: lat,
        longitude: lon,
        temperature_c: baseTemp,
        apparent_temperature_c: baseTemp + 1.2,
        humidity_pct: 55.0,
        wind_speed_kmh: 14.5,
        precipitation_mm: 0.0,
        surface_pressure_hpa: 1014.0,
        weather_code: code,
        condition_description: WMO_CODES[code],
        recorded_at: nowIso,
        data_source: "Offline Mock Fallback Engine",
        notes: "Generated gracefully by resilient offline fallback engine."
      });
    }

    // Prepend to active records
    weatherRecords.unshift(record);
    filteredRecords = [...weatherRecords];

    // Update Display Card
    displayObservation(record);
    updateExecutiveSummary();
    renderTable();
    initOrUpdateChart();

  } catch (err) {
    console.error("Fetch error:", err);
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span class="btn-icon">⚡</span> Fetch Weather`;
  }
}

function displayObservation(r) {
  document.getElementById("obs-location").innerText = `${r.city}, ${r.country}`;
  document.getElementById("obs-time").innerText = `Recorded: ${r.recorded_at} | Source: ${r.data_source}`;
  document.getElementById("obs-temp").innerText = `${r.temperature_c.toFixed(1)}°C`;
  document.getElementById("obs-temp-f").innerText = `${r.temperature_f.toFixed(1)}°F`;
  document.getElementById("obs-condition").innerText = r.condition_description;
  document.getElementById("obs-apparent").innerText = `${r.apparent_temperature_c.toFixed(1)}°C`;
  document.getElementById("obs-humidity").innerText = `${r.humidity_pct.toFixed(0)}%`;
  document.getElementById("obs-wind").innerText = `${r.wind_speed_kmh.toFixed(1)} km/h`;
  document.getElementById("obs-precip").innerText = `${r.precipitation_mm.toFixed(1)} mm`;
  document.getElementById("obs-pressure").innerText = `${r.surface_pressure_hpa.toFixed(1)} hPa`;

  // Flags
  const flagsEl = document.getElementById("obs-flags-list");
  flagsEl.innerHTML = r.status_indicators.map(f => {
    const cls = f.startsWith("CRITICAL:") ? "pill-crit" : (f.startsWith("WARNING:") ? "pill-warn" : "pill-ok");
    return `<span class="status-pill ${cls}">${f}</span>`;
  }).join("");
}

// Executive Summary Aggregation
function updateExecutiveSummary() {
  if (weatherRecords.length === 0) return;

  const temps = weatherRecords.map(r => r.temperature_c);
  const hums = weatherRecords.map(r => r.humidity_pct);
  const winds = weatherRecords.map(r => r.wind_speed_kmh);
  const precips = weatherRecords.map(r => r.precipitation_mm);

  const avgTemp = temps.reduce((a, b) => a + b, 0) / temps.length;
  const minTemp = Math.min(...temps);
  const maxTemp = Math.max(...temps);

  const avgHum = hums.reduce((a, b) => a + b, 0) / hums.length;
  const avgWind = winds.reduce((a, b) => a + b, 0) / winds.length;
  const maxWind = Math.max(...winds);

  const totalPrecip = precips.reduce((a, b) => a + b, 0);
  const maxPrecip = Math.max(...precips);

  const critAlerts = weatherRecords.filter(r => r.has_critical_alert).length;
  const warnAlerts = weatherRecords.filter(r => r.has_warning && !r.has_critical_alert).length;
  const nominalRatio = ((weatherRecords.length - (critAlerts + warnAlerts)) / weatherRecords.length) * 100;

  // DOM Updates
  document.getElementById("summary-total-badge").innerText = `${weatherRecords.length} Stations Monitored`;
  document.getElementById("metric-avg-temp").innerText = `${avgTemp.toFixed(1)}°C`;
  document.getElementById("metric-temp-range").innerText = `Min: ${minTemp.toFixed(1)}°C | Max: ${maxTemp.toFixed(1)}°C`;
  document.getElementById("metric-avg-hum").innerText = `${avgHum.toFixed(1)}%`;
  document.getElementById("metric-avg-wind").innerText = `${avgWind.toFixed(1)} km/h`;
  document.getElementById("metric-peak-wind").innerText = `Peak: ${maxWind.toFixed(1)} km/h`;
  document.getElementById("metric-total-precip").innerText = `${totalPrecip.toFixed(1)} mm`;
  document.getElementById("metric-peak-precip").innerText = `Peak: ${maxPrecip.toFixed(1)} mm`;
  document.getElementById("metric-crit-alerts").innerText = critAlerts;
  document.getElementById("metric-nominal-pct").innerText = `${nominalRatio.toFixed(1)}%`;

  // Update Threshold Warning Banner
  const banner = document.getElementById("threshold-banner");
  const bannerText = document.getElementById("banner-text");
  const anomalousStations = weatherRecords.filter(r => r.has_warning);

  if (anomalousStations.length > 0) {
    banner.style.display = "flex";
    const sampleHighlights = anomalousStations.slice(0, 3).map(r => `${r.city} (${r.temperature_c}°C, ${r.status_indicators[0]})`).join(" • ");
    bannerText.innerHTML = `<strong>${anomalousStations.length} station(s) flagged with threshold alerts:</strong> ${sampleHighlights}`;
  } else {
    banner.style.display = "none";
  }
}

// Interactive Chart.js Visualizations
function initOrUpdateChart() {
  const ctx = document.getElementById("weatherChart");
  if (!ctx) return;

  const sample = weatherRecords.slice(0, 14);

  let chartData, chartOptions, chartType;

  if (activeChartMode === 'temp') {
    chartType = 'bar';
    chartData = {
      labels: sample.map(r => r.city),
      datasets: [{
        label: 'Temperature (°C)',
        data: sample.map(r => r.temperature_c),
        backgroundColor: sample.map(r => r.temperature_c >= 35 ? 'rgba(239, 68, 68, 0.85)' : (r.temperature_c <= 0 ? 'rgba(56, 189, 248, 0.85)' : 'rgba(16, 185, 129, 0.85)')),
        borderColor: sample.map(r => r.temperature_c >= 35 ? '#ef4444' : (r.temperature_c <= 0 ? '#38bdf8' : '#10b981')),
        borderWidth: 1.5,
        borderRadius: 6
      }]
    };
    chartOptions = {
      responsive: true,
      plugins: {
        legend: { labels: { color: '#94a3b8' } }
      },
      scales: {
        x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(51, 65, 85, 0.2)' } },
        y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(51, 65, 85, 0.2)' } }
      }
    };
  } else if (activeChartMode === 'conditions') {
    chartType = 'doughnut';
    const condMap = {};
    weatherRecords.forEach(r => {
      condMap[r.condition_description] = (condMap[r.condition_description] || 0) + 1;
    });
    chartData = {
      labels: Object.keys(condMap),
      datasets: [{
        data: Object.values(condMap),
        backgroundColor: ['#38bdf8', '#818cf8', '#c084fc', '#f472b6', '#fb923c', '#4ade80', '#34d399', '#f87171']
      }]
    };
    chartOptions = {
      responsive: true,
      plugins: {
        legend: { position: 'right', labels: { color: '#cbd5e1' } }
      }
    };
  } else if (activeChartMode === 'wind_hum') {
    chartType = 'line';
    chartData = {
      labels: sample.map(r => r.city),
      datasets: [
        {
          label: 'Wind Speed (km/h)',
          data: sample.map(r => r.wind_speed_kmh),
          borderColor: '#38bdf8',
          backgroundColor: 'rgba(56, 189, 248, 0.2)',
          fill: true,
          tension: 0.3
        },
        {
          label: 'Relative Humidity (%)',
          data: sample.map(r => r.humidity_pct),
          borderColor: '#a855f7',
          backgroundColor: 'transparent',
          borderDash: [5, 5],
          tension: 0.3
        }
      ]
    };
    chartOptions = {
      responsive: true,
      plugins: { legend: { labels: { color: '#94a3b8' } } },
      scales: {
        x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(51, 65, 85, 0.2)' } },
        y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(51, 65, 85, 0.2)' } }
      }
    };
  }

  if (weatherChartInstance) {
    weatherChartInstance.destroy();
  }

  if (window.Chart) {
    weatherChartInstance = new Chart(ctx, {
      type: chartType,
      data: chartData,
      options: chartOptions
    });
  }
}

function switchChartMode(mode) {
  activeChartMode = mode;
  document.querySelectorAll('.chart-controls button').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  initOrUpdateChart();
}

// Multi-Dimensional Search & Filtering
function handleFilterChange() {
  const kw = document.getElementById("search-keyword").value.trim().toLowerCase();
  const cond = document.getElementById("filter-condition").value;
  const alertsOnly = document.getElementById("filter-alerts-only").checked;

  filteredRecords = weatherRecords.filter(r => {
    // Keyword match
    if (kw) {
      const match = r.city.toLowerCase().includes(kw) ||
                    r.country.toLowerCase().includes(kw) ||
                    (r.notes && r.notes.toLowerCase().includes(kw)) ||
                    r.condition_description.toLowerCase().includes(kw);
      if (!match) return false;
    }

    // Condition filter
    if (cond !== "ALL") {
      if (!r.condition_description.toLowerCase().includes(cond.toLowerCase())) {
        return false;
      }
    }

    // Alerts only
    if (alertsOnly && !r.has_warning) {
      return false;
    }

    return true;
  });

  currentPage = 1;
  renderTable();
}

// Paginated Table Rendering
function renderTable() {
  const tbody = document.getElementById("table-body");
  const countText = document.getElementById("filtered-count-text");
  const pageInfo = document.getElementById("pagination-info");
  const btnPrev = document.getElementById("btn-prev-page");
  const btnNext = document.getElementById("btn-next-page");

  countText.innerText = `Showing ${filteredRecords.length} records (of ${weatherRecords.length})`;

  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  if (currentPage > totalPages) currentPage = totalPages;

  pageInfo.innerText = `Page ${currentPage} of ${totalPages}`;
  btnPrev.disabled = currentPage === 1;
  btnNext.disabled = currentPage === totalPages;

  const start = (currentPage - 1) * pageSize;
  const pageItems = filteredRecords.slice(start, start + pageSize);

  if (pageItems.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" style="text-align: center; color: #94a3b8; padding: 24px;">No matching records found.</td></tr>`;
    return;
  }

  tbody.innerHTML = pageItems.map(r => {
    const statusPill = r.has_critical_alert ?
      `<span class="status-pill pill-crit">CRITICAL</span>` :
      (r.has_warning ? `<span class="status-pill pill-warn">WARNING</span>` : `<span class="status-pill pill-ok">NORMAL</span>`);

    const tempColor = r.temperature_c >= 35 ? '#ef4444' : (r.temperature_c <= 0 ? '#38bdf8' : '#10b981');

    return `
      <tr>
        <td><code>${r.id}</code></td>
        <td><strong>${r.city}</strong></td>
        <td>${r.country}</td>
        <td><strong style="color: ${tempColor};">${r.temperature_c.toFixed(1)}°C</strong> (${r.temperature_f}°F)</td>
        <td>${r.humidity_pct.toFixed(0)}%</td>
        <td>${r.wind_speed_kmh.toFixed(1)} km/h</td>
        <td>${r.precipitation_mm.toFixed(1)} mm</td>
        <td>${r.condition_description}</td>
        <td>${statusPill}</td>
        <td>
          <button class="btn-del" onclick="deleteRecord('${r.id}')">Delete</button>
        </td>
      </tr>
    `;
  }).join("");
}

function prevPage() {
  if (currentPage > 1) {
    currentPage--;
    renderTable();
  }
}

function nextPage() {
  const totalPages = Math.ceil(filteredRecords.length / pageSize);
  if (currentPage < totalPages) {
    currentPage++;
    renderTable();
  }
}

function deleteRecord(id) {
  weatherRecords = weatherRecords.filter(r => r.id !== id);
  handleFilterChange();
  updateExecutiveSummary();
  initOrUpdateChart();
}

// Bulk CSV Ingestion Modal
function openBulkImportModal() {
  document.getElementById("import-modal").style.display = "flex";
}

function closeBulkImportModal() {
  document.getElementById("import-modal").style.display = "none";
}

function handleCSVFileSelected(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => processCSVText(e.target.result);
  reader.readAsText(file);
}

function loadSampleLegacyCSV() {
  const sampleCSV = `city,country,latitude,longitude,temperature_c,humidity_pct,wind_speed_kmh,precipitation_mm,condition_description,notes
Boston,United States,42.3601,-71.0589,12.5,65.0,18.0,0.0,Clear Sky,Valid normal station
Melbourne,Australia,-37.8136,144.9631,21.0,55.0,22.0,1.2,Partly Cloudy,Valid southern station
Kyoto,Japan,35.0116,135.7681,17.2,60.0,9.5,0.0,Clear Sky,Valid ancient capital
Invalid123City,Unknown,25.0,75.0,24.0,50.0,10.0,0.0,Clear Sky,DEFECT: Numbers in city name
Dublin,Ireland,53.3498,-6.2603,98.5,85.0,20.0,4.0,Rain,DEFECT: Temperature 98.5C impossible
Lima,Peru,-12.0464,-77.0428,20.0,140.0,12.0,0.0,Fog,DEFECT: Humidity 140% exceeds 100%
Honolulu,United States,21.3069,-157.8583,28.0,68.0,-15.0,0.0,Sunny,DEFECT: Negative wind speed
Anchorage,United States,61.2181,-149.9003,-4.0,72.0,14.0,2.0,Snow,Valid sub-arctic station
,MissingCity,10.0,10.0,25.0,50.0,10.0,0.0,Clear Sky,DEFECT: Blank city name
Havana,Cuba,23.1136,-82.3666,29.5,75.0,16.0,0.0,Partly Cloudy,Valid tropical station`;
  processCSVText(sampleCSV);
}

function processCSVText(csvContent) {
  const lines = csvContent.split(/\r?\n/).filter(l => l.trim().length > 0);
  if (lines.length < 2) return;

  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  const validImported = [];
  const errors = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map(c => c.trim());
    const rowObj = {};
    headers.forEach((h, idx) => { rowObj[h] = cols[idx] || ""; });

    const rowErrors = [];
    // City check
    const city = rowObj.city || "";
    if (!city) rowErrors.push("City name is blank");
    else if (!/^[A-Za-z\s\-'.]{2,60}$/.test(city)) rowErrors.push(`City '${city}' contains illegal characters`);

    // Temp check
    const temp = parseFloat(rowObj.temperature_c);
    if (isNaN(temp)) rowErrors.push("Temperature is non-numeric");
    else if (temp < -60 || temp > 65) rowErrors.push(`Temperature ${temp}°C is outside physical bounds (-60°C to 65°C)`);

    // Humidity check
    const hum = parseFloat(rowObj.humidity_pct);
    if (isNaN(hum)) rowErrors.push("Humidity is non-numeric");
    else if (hum < 0 || hum > 100) rowErrors.push(`Humidity ${hum}% exceeds allowed 0-100%`);

    // Wind check
    const wind = parseFloat(rowObj.wind_speed_kmh || "0");
    if (isNaN(wind) || wind < 0) rowErrors.push(`Wind speed ${rowObj.wind_speed_kmh} must be non-negative`);

    if (rowErrors.length > 0) {
      errors.push({ line: i + 1, city: city || 'Empty', reasons: rowErrors });
    } else {
      validImported.push(normalizeRecord({
        id: `IMP-${Date.now().toString().slice(-4)}-${i}`,
        city: city,
        country: rowObj.country || "Global",
        latitude: parseFloat(rowObj.latitude) || 0,
        longitude: parseFloat(rowObj.longitude) || 0,
        temperature_c: temp,
        apparent_temperature_c: temp,
        humidity_pct: hum,
        wind_speed_kmh: wind,
        precipitation_mm: parseFloat(rowObj.precipitation_mm) || 0,
        surface_pressure_hpa: 1013.25,
        weather_code: 0,
        condition_description: rowObj.condition_description || "Imported Record",
        recorded_at: new Date().toISOString().replace(/\.\d+Z$/, ""),
        data_source: "Bulk CSV Import",
        notes: rowObj.notes || "Imported dataset entry"
      }));
    }
  }

  // Display audit in modal
  document.getElementById("import-results-container").style.display = "block";
  document.getElementById("import-stats").innerHTML = `
    <strong>Validation Results:</strong> Processed ${lines.length - 1} rows • 
    <span style="color: #10b981; font-weight: 600;">${validImported.length} Accepted</span> • 
    <span style="color: #ef4444; font-weight: 600;">${errors.length} Rejected</span>
  `;

  document.getElementById("import-error-list").innerHTML = errors.map(e => `
    <div><strong>Line ${e.line} (${e.city}):</strong> ${e.reasons.join("; ")}</div>
  `).join("");

  if (validImported.length > 0) {
    weatherRecords.unshift(...validImported);
    handleFilterChange();
    updateExecutiveSummary();
    initOrUpdateChart();
  }
}

// Multi-Format Data Exporters (CSV, JSON, Markdown, Audit Log)
function exportData(format) {
  let content = "";
  let mimeType = "text/plain";
  let filename = "weather_export.txt";

  if (format === 'csv') {
    const headers = ["id", "city", "country", "latitude", "longitude", "temperature_c", "temperature_f", "humidity_pct", "wind_speed_kmh", "precipitation_mm", "condition_description", "status_flags", "data_source"];
    const rows = weatherRecords.map(r => [
      r.id, `"${r.city}"`, `"${r.country}"`, r.latitude, r.longitude,
      r.temperature_c, r.temperature_f, r.humidity_pct, r.wind_speed_kmh,
      r.precipitation_mm, `"${r.condition_description}"`,
      `"${r.status_indicators.join(' | ')}"`, `"${r.data_source}"`
    ].join(","));
    content = [headers.join(","), ...rows].join("\n");
    mimeType = "text/csv";
    filename = "weather_export.csv";
  } else if (format === 'json') {
    content = JSON.stringify(weatherRecords, null, 2);
    mimeType = "application/json";
    filename = "weather_records.json";
  } else if (format === 'markdown') {
    const now = new Date().toISOString();
    content = [
      `# CampusSolve #111 : Public API Weather Viewer Executive Report`,
      `**Generated:** ${now} | **Monitored Stations:** ${weatherRecords.length}`,
      ``,
      `## Station Meteorological Register`,
      `| ID | City | Country | Temp (°C) | Humidity (%) | Wind (km/h) | Condition | Status |`,
      `| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |`,
      ...weatherRecords.map(r => `| \`${r.id}\` | **${r.city}** | ${r.country} | ${r.temperature_c}°C | ${r.humidity_pct}% | ${r.wind_speed_kmh} | ${r.condition_description} | ${r.has_warning ? '⚠️ Alert' : '✔ Normal'} |`),
      ``,
      `*Report generated by CampusSolve Web Dashboard.*`
    ].join("\n");
    mimeType = "text/markdown";
    filename = "summary_report.md";
  } else if (format === 'audit') {
    const now = new Date().toISOString();
    content = [
      `=== CAMPUSSOLVE WEATHER VIEWER - SYSTEM AUDIT LOG ===`,
      `TIMESTAMP: ${now}`,
      `TOTAL_STATIONS: ${weatherRecords.length}`,
      `--------------------------------------------------------------------------------`,
      ...weatherRecords.map(r => `[${r.recorded_at}] [${r.has_critical_alert ? 'CRIT' : (r.has_warning ? 'WARN' : 'INFO')}] STATION: ${r.city} | T: ${r.temperature_c}C | H: ${r.humidity_pct}% | W: ${r.wind_speed_kmh}km/h | ${r.status_indicators.join(';')}`),
      `--------------------------------------------------------------------------------`,
      `END OF AUDIT LOG.`
    ].join("\n");
    mimeType = "text/plain";
    filename = "audit_log.txt";
  }

  // Trigger browser download
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
