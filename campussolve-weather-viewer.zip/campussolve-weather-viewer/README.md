# CampusSolve #111 : Public API Weather Viewer
**Domain:** AI, APIs & Smart Applications | **Hackathon Mentor Guide Project #111**

A robust, resilient Python software application and dual-interface platform (Interactive Terminal CLI + Lightweight Tkinter Desktop GUI + Web Dashboard) that fetches real-time meteorological observations from the beginner-friendly **Open-Meteo Public API** (no API keys required), enforces strict defensive input validation, provides automated local file persistence (JSON & CSV), calculates executive summary metrics, alerts on overdue reporting deadlines and critical threshold breaches, and renders graphical trend visualizations.

---

## 🌟 Feature Matrix & PDF Specification Compliance

| Feature Specification | Requirement Status (PDF) | Implementation Details |
| :--- | :--- | :--- |
| **Interactive Terminal Interface** | **MUST-HAVE (Core)** | Menu-driven command prompt facilitating seamless user interactions, ANSI color styling, banner, paginated fixed-width tables, and safe input loops (`main.py`). |
| **Defensive Input Validation** | **MUST-HAVE (Core)** | Real-time sanitization and range checks ensuring values conform to domain constraints. Centralized input wrappers looping until valid inputs matching regex (`^[A-Za-z\s\-'.]{2,60}$`), coordinate boundaries, and terrestrial limits (-60°C to +65°C) are provided (`src/validator.py`). |
| **Core Business Logic Engine** | **MUST-HAVE (Core)** | Connects to Open-Meteo Geocoding and Forecast endpoints; displays key values (Temp °C/°F, Apparent Feel, Humidity %, Wind km/h & mph, Precip mm, Surface Pressure hPa, WMO conditions). Graceful fallback catching `RequestException`, `URLError`, or `ImportError` switching to deterministic offline mock cache (`src/api_engine.py`). |
| **Local Data Persistence** | **MUST-HAVE (Core)** | Automated synchronized reading/writing to `data/weather_records.json` and `data/weather_records.csv` ensuring data survives program restarts. Features automatic corruption recovery catching `FileNotFoundError` and `JSONDecodeError` (`src/storage.py`). |
| **Record Query & Search** | **MUST-HAVE (Core)** | Keyword and category-based filtering tools allowing quick retrieval of stored information across stations, condition categories (Clear, Rain, Snow, Fog, etc.), temperature bounds, and alert levels (`src/analytics.py`). |
| **Executive Summary Generation**| **MUST-HAVE (Core)** | Comprehensive aggregation module computing totals, averages, thermal extremes, medians, moisture, kinetic storm risks, overdue reporting deadlines, and operational status ratios (`src/analytics.py`). |
| **Visual Data Plotting** | **MUST-HAVE (Core)** | Matplotlib integration generating clear trend charts and visual distributions for exported reports (`exports/weather_trend_chart.png`) + zero-dependency SVG vector dashboard (`exports/weather_trend_chart.svg`) + terminal ASCII distribution bars (`src/visualizer.py`). |
| **Multi-Format Summary Export** | **STRETCH (Good-to-Have)** | Generates structured Markdown (`exports/summary_report.md`), plain-text audit logs (`exports/audit_log.txt`), and RFC-4180 CSV (`exports/weather_export.csv`) for external review (`src/exporter.py`). |
| **Threshold Warning Indicators** | **STRETCH (Good-to-Have)** | Automated console warning flags highlighting overdue deadlines (`CRITICAL: Overdue Reporting Deadline`), anomalous entries, and critical limit breaches (Heatwave >=40°C, Frost <=0°C, Gale >=50km/h, Torrential Rain >=50mm, Aridity <=15%) (`src/models.py`). |
| **Lightweight Tkinter Desktop GUI** | **STRETCH (Good-to-Have)** | Full-featured native Graphical Interface (`gui.py`) providing visual menu navigation, live API query card, sortable record table with color status tags, analytics badges, Matplotlib chart viewer, CSV ingestion UI, and export triggers. |
| **Interactive Web Dashboard** | **STRETCH (Good-to-Have)** | Modern, responsive web application (`web/index.html`, `style.css`, `app.js`) with Chart.js charts, local Python web server (`app.py`), and offline static execution. |
| **Bulk Dataset Import** | **STRETCH (Good-to-Have)** | Ingests legacy CSV datasets with automatic format validation and detailed row-by-row error logs (`src/importer.py`). |
| **30-50 Realistic Seed Dataset** | **SECTION 7 REQUIREMENT** | Pre-populated with 40 realistic entries containing normal metropolitan stations, physical boundary cases (0.0°C, 100% humidity, 0 mm rain, calm wind), and extreme edge anomalies (`data/`). |

---

## 📁 Repository Structure

```
campussolve-weather-viewer/
├── README.md                          # Comprehensive documentation & demo guide
├── requirements.txt                   # Optional dependencies (matplotlib, requests)
├── run.bat                            # Windows interactive one-click launcher
├── main.py                            # Interactive Terminal Application (Menu-driven CLI)
├── gui.py                             # Lightweight Desktop GUI (Tkinter Visual Navigation)
├── app.py                             # Local Python Web Server (http://localhost:8080)
├── generate_seed_data.py              # Dynamic generator for the 40 realistic seed entries
├── src/
│   ├── __init__.py
│   ├── models.py                      # Dataclasses (WeatherRecord, ExecutiveSummary, ValidationResult)
│   ├── validator.py                   # Defensive sanitization, regex matching, range verification
│   ├── api_engine.py                  # Open-Meteo public API client + RequestException mock fallback
│   ├── storage.py                     # Local JSON & CSV persistence with self-healing recovery
│   ├── analytics.py                   # Executive summary, query engine, anomaly & deadline detection
│   ├── visualizer.py                  # Matplotlib plotting, SVG vector export, ASCII terminal bars
│   ├── exporter.py                    # Multi-format exports (Markdown, Audit Log, CSV)
│   └── importer.py                    # Bulk dataset import with row-by-row defect logs
├── data/
│   ├── weather_records.json           # JSON database (40 realistic seed entries)
│   ├── weather_records.csv            # Synchronized CSV database
│   ├── sample_legacy_import.csv       # Test dataset with valid rows, defects, and deadline tests
│   └── test_cases_guide.md            # Detailed documentation of boundary & edge test cases
├── exports/
│   ├── summary_report.md              # Exported executive Markdown report
│   ├── audit_log.txt                  # Plain-text chronological system audit log
│   ├── weather_export.csv             # RFC-4180 standardized CSV export
│   ├── weather_trend_chart.png        # High-resolution Matplotlib trend chart
│   └── weather_trend_chart.svg        # Standalone vector SVG dashboard chart
├── web/
│   ├── index.html                     # Responsive Web Dashboard Website
│   ├── style.css                      # Modern dark-mode glassmorphic design
│   ├── app.js                         # Dynamic frontend logic & Chart.js integration
│   └── sample_data.json               # Seed dataset for offline website execution
└── tests/
    └── test_weather_viewer.py         # Automated unit & integration test suite (18 tests)
```

---

## 🚀 Quick Start Guide

### Option 1: One-Click Windows Launcher (`run.bat`)
Double-click `run.bat` in the project folder to open the interactive launcher menu:
- Press `1` to run the Interactive Terminal Application (`main.py`)
- Press `2` to launch the Lightweight Desktop GUI (`gui.py`)
- Press `3` to start the Web Server and open `http://localhost:8080`
- Press `4` to open `web/index.html` directly in your browser
- Press `5` to execute the automated test suite (18/18 unit tests)
- Press `6` to re-generate the seed dataset

### Option 2: Running the Interactive Terminal CLI
```bash
py main.py
# or: python main.py
```

### Option 3: Running the Lightweight Desktop GUI (Tkinter)
```bash
py gui.py
```
*Zero setup required — Tkinter is built right into the Python Standard Library!*

### Option 4: Launching the Web Dashboard
```bash
py app.py
```
Navigate to `http://localhost:8080` in your web browser. (Or double-click `web/index.html` to run offline without a server).

### Option 5: Running the Automated Test Suite
```bash
py -m unittest tests/test_weather_viewer.py
```
Output:
```
..................
----------------------------------------------------------------------
Ran 18 tests in 7.067s

OK
```

---

## 🎬 Hackathon Live Demo Script (Section 9 Walkthrough)

To present a winning demonstration as envisioned in **Section 9: What a Good Demo Looks Like**:

1. **Branded Welcome Screen & Storage Load:**
   - Launch `py main.py`. Point out the branded header banner and the indicator displaying that 40 records are active in synchronized JSON/CSV persistence.
2. **Defensive Input Validation in Action:**
   - Select Option `[1]` (*Fetch & Record Weather*).
   - Enter invalid inputs intentionally (e.g. `12345`, `!@#$`, or blank). Show how the input wrapper catches the violation and prompts again without crashing.
   - Enter a valid city like `London`, `Tokyo`, or `San Francisco`. Show the retrieved key values, WMO weather interpretation, and calculated threshold flags.
3. **Executive Summary & Trend Analytics:**
   - Select Option `[4]` (*Executive Summary*).
   - Display the computed thermal averages, thermal extremes (-28.5°C in Yakutsk to 48.2°C in Death Valley), kinetic storm warnings, overdue reporting deadlines, and hydrological status.
4. **Visual Data Plotting:**
   - Select Option `[5]` (*Visual Data Plotting*).
   - Showcase the ASCII horizontal bar chart rendered directly in the terminal, and open the generated `exports/weather_trend_chart.png` or `exports/weather_trend_chart.svg`.
5. **Bulk Ingestion with Row-by-Row Error Logs:**
   - Select Option `[7]` (*Bulk Dataset Import*). Press Enter to use `data/sample_legacy_import.csv`.
   - Point out the detailed defect log: shows exact row numbers where defective data (e.g., negative wind speed, temperature of 98.5°C, humidity of 140%) were rejected while valid records were safely merged!
6. **Multi-Format Export & State Preservation:**
   - Select Option `[6]` to generate Markdown, Audit Log, and CSV files in `exports/`.
   - Select Option `[0]` (*Exit*). Point out the clean shutdown notice.
   - Relaunch `py main.py` to prove that state was preserved across restarts.
7. **The Lightweight Desktop GUI (Tkinter):**
   - Select Option `[9]` from the terminal menu, or launch `py gui.py`.
   - Showcase the visual menu navigation tabs: Live API Fetch, Stored Records Table with color-coded status badges, Analytics Badges, Matplotlib Chart Viewer, and Ingestion / Export tabs!

---

## 🛡️ Defensive Engineering & Self-Healing Architecture (Section 8)

1. **Handling Corrupted or Missing Local Storage:**
   Encapsulates file reads in try-except blocks detecting `FileNotFoundError` and `JSONDecodeError`. If JSON corruption occurs, the system automatically recovers from CSV backup or creates clean initial templates.
2. **Preventing Crashes from Invalid / Non-Numeric Terminal Inputs:**
   Centralized input wrapper functions (`prompt_with_validation`) loop defensively until valid entries conforming to regex patterns and numerical boundary limits are supplied.
3. **Scalable Table Formatting & Pagination Breaks:**
   Fixed-width columns, separator lines, and interactive pagination (`Page N of Total`, `Next [N]`, `Prev [P]`, `Quit [Q]`) ensure terminal readability even with large datasets.
4. **Managing Intermittent Network Timeouts & Dependencies Gracefully:**
   Defensive fallback routines catch `RequestException`, `URLError`, `HTTPError`, `TimeoutError`, or `ImportError` and switch gracefully to local mock caches.
