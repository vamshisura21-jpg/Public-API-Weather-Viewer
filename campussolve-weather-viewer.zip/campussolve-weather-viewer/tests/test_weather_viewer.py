"""
test_weather_viewer.py - Automated Unit & Integration Test Suite
Validates Defensive Input Validation, API fallback logic, Persistence roundtrips,
Analytics aggregations, Bulk Ingestion error detection, Multi-format exports,
and Tkinter Graphical Interface integration.
"""

import os
import sys
import unittest
import tempfile
import json
import csv
from datetime import datetime, timedelta

# Add base directory to path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.models import WeatherRecord, ValidationResult, ExecutiveSummary
from src.validator import DefensiveValidator, prompt_with_validation
from src.api_engine import PublicWeatherAPIClient
from src.storage import LocalStorageManager
from src.analytics import WeatherAnalyticsEngine
from src.visualizer import VisualDataPlotter
from src.exporter import MultiFormatExporter
from src.importer import BulkDatasetImporter


class TestDefensiveValidation(unittest.TestCase):
    """Verifies strict domain sanitization and boundary checking."""

    def test_city_validation_valid(self):
        res = DefensiveValidator.validate_city_name("San Francisco")
        self.assertTrue(res.is_valid)
        self.assertEqual(res.cleaned_value, "San Francisco")

    def test_city_validation_empty_and_spaces(self):
        self.assertFalse(DefensiveValidator.validate_city_name("").is_valid)
        self.assertFalse(DefensiveValidator.validate_city_name("   ").is_valid)
        self.assertFalse(DefensiveValidator.validate_city_name(None).is_valid)

    def test_city_validation_invalid_symbols(self):
        self.assertFalse(DefensiveValidator.validate_city_name("Tokyo123!").is_valid)
        self.assertFalse(DefensiveValidator.validate_city_name("<script>alert()</script>").is_valid)

    def test_temperature_boundary_checks(self):
        # Physical boundary: -60°C to +65°C
        self.assertTrue(DefensiveValidator.validate_temperature("0.0").is_valid)
        self.assertTrue(DefensiveValidator.validate_temperature("-60.0").is_valid)
        self.assertTrue(DefensiveValidator.validate_temperature("65.0").is_valid)
        self.assertFalse(DefensiveValidator.validate_temperature("75.0").is_valid)
        self.assertFalse(DefensiveValidator.validate_temperature("-85.0").is_valid)
        self.assertFalse(DefensiveValidator.validate_temperature("abc").is_valid)

    def test_humidity_range_checks(self):
        self.assertTrue(DefensiveValidator.validate_humidity("0").is_valid)
        self.assertTrue(DefensiveValidator.validate_humidity("100").is_valid)
        self.assertFalse(DefensiveValidator.validate_humidity("-5").is_valid)
        self.assertFalse(DefensiveValidator.validate_humidity("105").is_valid)

    def test_coordinates_boundaries(self):
        self.assertTrue(DefensiveValidator.validate_latitude("90.0").is_valid)
        self.assertTrue(DefensiveValidator.validate_latitude("-90.0").is_valid)
        self.assertFalse(DefensiveValidator.validate_latitude("90.1").is_valid)
        
        self.assertTrue(DefensiveValidator.validate_longitude("180.0").is_valid)
        self.assertTrue(DefensiveValidator.validate_longitude("-180.0").is_valid)
        self.assertFalse(DefensiveValidator.validate_longitude("-180.5").is_valid)

    def test_wind_and_precip_validation(self):
        self.assertTrue(DefensiveValidator.validate_wind_speed("45.5").is_valid)
        self.assertFalse(DefensiveValidator.validate_wind_speed("-10.0").is_valid)
        self.assertTrue(DefensiveValidator.validate_precipitation("0.0").is_valid)
        self.assertFalse(DefensiveValidator.validate_precipitation("-1.0").is_valid)


class TestLocalStorageAndCorruptionRecovery(unittest.TestCase):
    """Verifies file persistence and automated corruption recovery."""

    def setUp(self):
        self.test_dir = tempfile.TemporaryDirectory()
        self.json_path = os.path.join(self.test_dir.name, "test_records.json")
        self.csv_path = os.path.join(self.test_dir.name, "test_records.csv")
        self.storage = LocalStorageManager(self.json_path, self.csv_path)

    def tearDown(self):
        self.test_dir.cleanup()

    def test_save_and_load_records(self):
        rec = WeatherRecord(
            id="TEST-001",
            city="Berlin",
            country="Germany",
            latitude=52.52,
            longitude=13.40,
            temperature_c=12.5,
            apparent_temperature_c=11.0,
            humidity_pct=65.0,
            wind_speed_kmh=15.0,
            precipitation_mm=0.0,
            surface_pressure_hpa=1012.0,
            weather_code=1,
            condition_description="Mainly Clear",
            recorded_at="2026-11-20T10:00:00"
        )
        self.assertTrue(self.storage.append_record(rec))

        loaded, warning = self.storage.load_all_records()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].city, "Berlin")
        self.assertEqual(loaded[0].temperature_c, 12.5)

    def test_corrupted_json_auto_recovery_from_csv(self):
        rec = WeatherRecord(
            id="TEST-002",
            city="Paris",
            country="France",
            latitude=48.85,
            longitude=2.35,
            temperature_c=14.0,
            apparent_temperature_c=13.0,
            humidity_pct=70.0,
            wind_speed_kmh=10.0,
            precipitation_mm=0.0,
            surface_pressure_hpa=1015.0,
            weather_code=0,
            condition_description="Clear Sky",
            recorded_at="2026-11-20T10:00:00"
        )
        self.storage.append_record(rec)

        # Corrupt the JSON file with garbage data
        with open(self.json_path, "w", encoding="utf-8") as f:
            f.write("{ INVALID MALFORMED JSON CONTENT ...")

        # Load should detect corruption and gracefully recover from CSV backup
        loaded, warning = self.storage.load_all_records()
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].city, "Paris")
        self.assertIsNotNone(warning)


class TestAnalyticsAndSummaryEngine(unittest.TestCase):
    """Verifies executive calculations, filtering, and threshold warnings."""

    def test_executive_summary_calculation(self):
        records = [
            WeatherRecord(id="R1", city="C1", country="K1", latitude=0, longitude=0,
                          temperature_c=10.0, apparent_temperature_c=10.0, humidity_pct=50.0,
                          wind_speed_kmh=10.0, precipitation_mm=2.0, surface_pressure_hpa=1010.0,
                          weather_code=0, condition_description="Clear Sky", recorded_at="T1"),
            WeatherRecord(id="R2", city="C2", country="K2", latitude=0, longitude=0,
                          temperature_c=30.0, apparent_temperature_c=30.0, humidity_pct=70.0,
                          wind_speed_kmh=20.0, precipitation_mm=8.0, surface_pressure_hpa=1012.0,
                          weather_code=61, condition_description="Slight Rain", recorded_at="T2"),
        ]

        summary = WeatherAnalyticsEngine.generate_executive_summary(records)
        self.assertIsNotNone(summary)
        self.assertEqual(summary.total_records, 2)
        self.assertEqual(summary.avg_temperature_c, 20.0)
        self.assertEqual(summary.min_temperature_c, 10.0)
        self.assertEqual(summary.max_temperature_c, 30.0)
        self.assertEqual(summary.avg_humidity_pct, 60.0)
        self.assertEqual(summary.total_precipitation_mm, 10.0)

    def test_threshold_warning_flags_and_overdue_deadlines(self):
        extreme_heat = WeatherRecord(id="E1", city="HeatCity", country="K", latitude=0, longitude=0,
                                     temperature_c=42.0, apparent_temperature_c=42.0, humidity_pct=20.0,
                                     wind_speed_kmh=10.0, precipitation_mm=0.0, surface_pressure_hpa=1010.0,
                                     weather_code=0, condition_description="Clear Sky", recorded_at="T")
        self.assertTrue(extreme_heat.has_critical_alert)
        self.assertTrue(any("Extreme Heat" in f for f in extreme_heat.status_indicators))

        freeze = WeatherRecord(id="E2", city="ColdCity", country="K", latitude=0, longitude=0,
                               temperature_c=-15.0, apparent_temperature_c=-20.0, humidity_pct=80.0,
                               wind_speed_kmh=10.0, precipitation_mm=0.0, surface_pressure_hpa=1010.0,
                               weather_code=75, condition_description="Snow", recorded_at="T")
        self.assertTrue(freeze.has_critical_alert)

        # Overdue deadline verification
        past_time = (datetime.now() - timedelta(days=2)).isoformat()
        overdue_rec = WeatherRecord(id="E3", city="OverdueCity", country="K", latitude=0, longitude=0,
                                    temperature_c=20.0, apparent_temperature_c=20.0, humidity_pct=50.0,
                                    wind_speed_kmh=10.0, precipitation_mm=0.0, surface_pressure_hpa=1013.0,
                                    weather_code=0, condition_description="Clear Sky", recorded_at="T",
                                    deadline_at=past_time)
        self.assertTrue(overdue_rec.is_overdue)
        self.assertTrue(overdue_rec.has_critical_alert)
        self.assertTrue(any("Overdue Reporting Deadline" in f for f in overdue_rec.status_indicators))

    def test_multi_dimensional_search_filter(self):
        records = [
            WeatherRecord(id="R1", city="Cairo", country="Egypt", latitude=30.0, longitude=31.0,
                          temperature_c=35.0, apparent_temperature_c=35.0, humidity_pct=30.0,
                          wind_speed_kmh=15.0, precipitation_mm=0.0, surface_pressure_hpa=1015.0,
                          weather_code=0, condition_description="Clear Sky", recorded_at="T1"),
            WeatherRecord(id="R2", city="Oslo", country="Norway", latitude=59.0, longitude=10.0,
                          temperature_c=-2.0, apparent_temperature_c=-5.0, humidity_pct=80.0,
                          wind_speed_kmh=25.0, precipitation_mm=2.0, surface_pressure_hpa=1010.0,
                          weather_code=71, condition_description="Snow", recorded_at="T2"),
        ]

        # Search by keyword
        res = WeatherAnalyticsEngine.filter_records(records, keyword="Cairo")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0].city, "Cairo")

        # Search by condition
        res_snow = WeatherAnalyticsEngine.filter_records(records, condition_filter="Snow")
        self.assertEqual(len(res_snow), 1)
        self.assertEqual(res_snow[0].city, "Oslo")

        # Search by temperature range
        res_temp = WeatherAnalyticsEngine.filter_records(records, min_temp=0.0)
        self.assertEqual(len(res_temp), 1)
        self.assertEqual(res_temp[0].city, "Cairo")


class TestPublicAPIAndFallback(unittest.TestCase):
    """Verifies public weather fetching and resilient offline mock fallback."""

    def test_fetch_weather_known_city(self):
        record, msg = PublicWeatherAPIClient.fetch_current_weather("Tokyo")
        self.assertIsNotNone(record)
        self.assertEqual(record.city, "Tokyo")
        self.assertTrue(-60.0 <= record.temperature_c <= 65.0)
        self.assertTrue(0.0 <= record.humidity_pct <= 100.0)

    def test_fetch_weather_arbitrary_city_simulation(self):
        record, msg = PublicWeatherAPIClient.fetch_current_weather("RandomFictionalTown")
        self.assertIsNotNone(record)
        self.assertEqual(record.city, "Randomfictionaltown")
        self.assertTrue(len(record.status_indicators) > 0)


class TestBulkDatasetImporter(unittest.TestCase):
    """Verifies ingestion of legacy datasets and detailed error logging."""

    def test_bulk_csv_validation(self):
        test_csv_content = """city,country,temperature_c,humidity_pct,wind_speed_kmh,deadline_at
Tokyo,Japan,18.5,60.0,12.0,
BadCity99,Global,20.0,50.0,10.0,
London,UK,999.0,80.0,15.0,
Paris,France,15.0,150.0,10.0,
Berlin,Germany,12.0,70.0,14.0,2026-11-01T00:00:00"""

        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".csv") as tmp:
            tmp.write(test_csv_content)
            tmp_path = tmp.name

        try:
            valid, errors, total = BulkDatasetImporter.import_csv_file(tmp_path)
            self.assertEqual(total, 5)
            self.assertEqual(len(valid), 2)  # Tokyo and Berlin
            self.assertEqual(len(errors), 3)  # BadCity99, London (999C), Paris (150% hum)
            # Verify Berlin has deadline_at preserved
            berlin = next(r for r in valid if r.city == "Berlin")
            self.assertEqual(berlin.deadline_at, "2026-11-01T00:00:00")
            self.assertTrue(berlin.is_overdue)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)


class TestMultiFormatExporter(unittest.TestCase):
    """Verifies generation of Markdown, Audit Log, and standardized CSV."""

    def test_multi_format_export(self):
        records = [
            WeatherRecord(id="EXP-1", city="Madrid", country="Spain", latitude=40.4, longitude=-3.7,
                          temperature_c=18.0, apparent_temperature_c=17.5, humidity_pct=50.0,
                          wind_speed_kmh=12.0, precipitation_mm=0.0, surface_pressure_hpa=1018.0,
                          weather_code=0, condition_description="Clear Sky", recorded_at="2026-11-20T10:00:00")
        ]
        summary = WeatherAnalyticsEngine.generate_executive_summary(records)

        with tempfile.TemporaryDirectory() as export_dir:
            res = MultiFormatExporter.export_all_formats(records, summary, export_dir)
            self.assertTrue(os.path.exists(res["markdown"]))
            self.assertTrue(os.path.exists(res["audit_log"]))
            self.assertTrue(os.path.exists(res["csv"]))

            with open(res["markdown"], "r", encoding="utf-8") as f:
                md_content = f.read()
                self.assertIn("Public API Weather Viewer", md_content)
                self.assertIn("Madrid", md_content)


class TestVisualPlotter(unittest.TestCase):
    """Verifies Matplotlib and zero-dependency SVG chart exports."""

    def test_plot_and_export(self):
        records = [
            WeatherRecord(id="V1", city="Stockholm", country="Sweden", latitude=59.3, longitude=18.0,
                          temperature_c=5.0, apparent_temperature_c=3.0, humidity_pct=75.0,
                          wind_speed_kmh=18.0, precipitation_mm=0.0, surface_pressure_hpa=1015.0,
                          weather_code=2, condition_description="Partly Cloudy", recorded_at="2026-11-20T10:00:00")
        ]
        summary = WeatherAnalyticsEngine.generate_executive_summary(records)

        with tempfile.TemporaryDirectory() as tmp_dir:
            png_path = os.path.join(tmp_dir, "chart.png")
            svg_path = os.path.join(tmp_dir, "chart.svg")
            results = VisualDataPlotter.plot_and_export(records, summary, png_path, svg_path)

            self.assertTrue(os.path.exists(svg_path))
            # If Matplotlib is installed, png should exist
            if "png" in results:
                self.assertTrue(os.path.exists(png_path))


class TestGUIIntegration(unittest.TestCase):
    """Verifies that GUI module loads and components can be instantiated."""

    def test_gui_module_availability(self):
        import gui
        self.assertTrue(hasattr(gui, "WeatherViewerGUI"))
        self.assertTrue(hasattr(gui, "launch_gui"))


if __name__ == "__main__":
    unittest.main()
