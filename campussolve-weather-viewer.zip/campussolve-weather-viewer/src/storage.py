"""
storage.py - Resilient Local Data Persistence Layer
Handles automated reading and writing of structured records to JSON and CSV files.
Features automatic corruption recovery (handling FileNotFoundError, JSONDecodeError, PermissionError),
schema checks, and multi-format synchronization.
"""

import csv
import json
import os
from typing import List, Optional, Tuple
from .models import WeatherRecord


class LocalStorageManager:
    """Manages file persistence and integrity checking for weather records."""

    DEFAULT_CSV_HEADERS = [
        "id", "city", "country", "latitude", "longitude",
        "temperature_c", "apparent_temperature_c", "humidity_pct",
        "wind_speed_kmh", "precipitation_mm", "surface_pressure_hpa",
        "weather_code", "condition_description", "recorded_at",
        "data_source", "notes", "deadline_at"
    ]

    def __init__(self, json_path: str, csv_path: str):
        self.json_path = json_path
        self.csv_path = csv_path
        self._ensure_storage_ready()

    def _ensure_storage_ready(self) -> None:
        """Verifies directories and initializes clean storage templates if missing."""
        os.makedirs(os.path.dirname(os.path.abspath(self.json_path)), exist_ok=True)
        os.makedirs(os.path.dirname(os.path.abspath(self.csv_path)), exist_ok=True)

        # Initialize JSON file if absent
        if not os.path.exists(self.json_path) or os.path.getsize(self.json_path) == 0:
            self._write_clean_json_template()

        # Initialize CSV file if absent
        if not os.path.exists(self.csv_path) or os.path.getsize(self.csv_path) == 0:
            self._write_clean_csv_template()

    def _write_clean_json_template(self) -> None:
        """Writes empty JSON list structure."""
        try:
            with open(self.json_path, "w", encoding="utf-8") as f:
                json.dump([], f, indent=2)
        except OSError:
            pass

    def _write_clean_csv_template(self) -> None:
        """Writes empty CSV header structure."""
        try:
            with open(self.csv_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(self.DEFAULT_CSV_HEADERS)
        except OSError:
            pass

    def load_all_records(self) -> Tuple[List[WeatherRecord], Optional[str]]:
        """
        Loads records safely from JSON file.
        Falls back to CSV if JSON is corrupted, or re-initializes template cleanly.
        """
        records: List[WeatherRecord] = []
        warning_msg: Optional[str] = None

        # 1. Try JSON Load
        try:
            if os.path.exists(self.json_path):
                with open(self.json_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        raw_list = json.loads(content)
                        if isinstance(raw_list, list):
                            for idx, item in enumerate(raw_list):
                                if isinstance(item, dict):
                                    try:
                                        rec = WeatherRecord.from_dict(item)
                                        records.append(rec)
                                    except Exception:
                                        continue
                            return records, None
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            warning_msg = f"JSON corruption detected ({e}). Attempting fallback to CSV recovery."
        except FileNotFoundError:
            self._write_clean_json_template()
            return [], None
        except Exception as e:
            warning_msg = f"Unexpected error reading JSON: {e}"

        # 2. Fallback to CSV if JSON failed or was empty
        if not records and os.path.exists(self.csv_path):
            try:
                with open(self.csv_path, "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        try:
                            rec = WeatherRecord.from_dict(row)
                            records.append(rec)
                        except Exception:
                            continue
                if records:
                    # Self-heal JSON persistence
                    self.save_all_records(records)
                    return records, f"Recovered {len(records)} records from CSV backup."
            except Exception as e:
                warning_msg = f"Both JSON and CSV load failed: {e}. Resetting to clean template."

        # If completely unrecoverable, recreate templates
        if not records and warning_msg:
            self._write_clean_json_template()
            self._write_clean_csv_template()

        return records, warning_msg

    def save_all_records(self, records: List[WeatherRecord]) -> bool:
        """
        Persists full list of records synchronously to both JSON and CSV files.
        Ensures complete crash resilience and format compatibility.
        """
        try:
            # 1. Save JSON
            data = [r.to_dict() for r in records]
            with open(self.json_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            # 2. Save CSV
            with open(self.csv_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=self.DEFAULT_CSV_HEADERS, extrasaction="ignore")
                writer.writeheader()
                for r in records:
                    writer.writerow(r.to_dict())

            return True
        except Exception as exc:
            print(f"\033[31m[Storage Error] Could not persist records: {exc}\033[0m")
            return False

    def append_record(self, record: WeatherRecord) -> bool:
        """Appends a new record to both JSON and CSV persistence."""
        records, _ = self.load_all_records()
        records.append(record)
        return self.save_all_records(records)

    def delete_record_by_id(self, record_id: str) -> bool:
        """Removes a record by its unique ID."""
        records, _ = self.load_all_records()
        initial_len = len(records)
        records = [r for r in records if r.id != record_id]
        if len(records) < initial_len:
            self.save_all_records(records)
            return True
        return False
