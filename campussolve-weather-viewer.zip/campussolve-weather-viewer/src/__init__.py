"""
CampusSolve Project #111: Public API Weather Viewer
Package initialization.
"""

__version__ = "1.0.0"
__author__ = "CampusSolve Hackathon Development Team"
