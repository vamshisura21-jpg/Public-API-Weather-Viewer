"""
api_engine.py - Core Public API Weather Fetching & Processing Engine
Interfaces with the beginner-friendly Open-Meteo public API (no API key required).
Provides resilient HTTP querying with defensive timeout and offline mock fallback routines.
"""

import json
import math
import random
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime
from typing import Dict, Any, Optional, Tuple
from .models import WeatherRecord

# Graceful optional dependency detection (Section 8: catch RequestException or ImportError)
try:
    import requests
    from requests.exceptions import RequestException
    HAS_REQUESTS = True
except ImportError:
    class RequestException(Exception):
        """Stub fallback if requests is uninstalled."""
        pass
    HAS_REQUESTS = False

# WMO Weather Interpretation Codes (WMO Code -> Textual Description)
WMO_WEATHER_CODES = {
    0: "Clear Sky",
    1: "Mainly Clear",
    2: "Partly Cloudy",
    3: "Overcast",
    45: "Foggy",
    48: "Depositing Rime Fog",
    51: "Light Drizzle",
    53: "Moderate Drizzle",
    55: "Dense Drizzle",
    61: "Slight Rain",
    63: "Moderate Rain",
    65: "Heavy Rain",
    71: "Slight Snow Fall",
    73: "Moderate Snow Fall",
    75: "Heavy Snow Fall",
    77: "Snow Grains",
    80: "Slight Rain Showers",
    81: "Moderate Rain Showers",
    82: "Violent Rain Showers",
    85: "Slight Snow Showers",
    86: "Heavy Snow Showers",
    95: "Thunderstorm",
    96: "Thunderstorm with Slight Hail",
    99: "Thunderstorm with Heavy Hail"
}

# Known world cities coordinates database for instant offline mock generation
CITY_GEO_CACHE: Dict[str, Tuple[float, float, str]] = {
    "Tokyo": (35.6762, 139.6503, "Japan"),
    "New York": (40.7128, -74.0060, "United States"),
    "London": (51.5074, -0.1278, "United Kingdom"),
    "Paris": (48.8566, 2.3522, "France"),
    "Singapore": (1.3521, 103.8198, "Singapore"),
    "Sydney": (-33.8688, 151.2093, "Australia"),
    "Mumbai": (19.0760, 72.8777, "India"),
    "Delhi": (28.6139, 77.2090, "India"),
    "Bangalore": (12.9716, 77.5946, "India"),
    "Cairo": (30.0444, 31.2357, "Egypt"),
    "Berlin": (52.5200, 13.4050, "Germany"),
    "Toronto": (43.6532, -79.3832, "Canada"),
    "Dubai": (25.2048, 55.2708, "United Arab Emirates"),
    "Sao Paulo": (-23.5505, -46.6333, "Brazil"),
    "Reykjavik": (64.1466, -21.9426, "Iceland"),
    "Nairobi": (-1.2921, 36.8219, "Kenya"),
    "Zurich": (47.3769, 8.5417, "Switzerland"),
    "Seoul": (37.5665, 126.9780, "South Korea"),
    "Bangkok": (13.7563, 100.5018, "Thailand"),
    "San Francisco": (37.7749, -122.4194, "United States")
}


class PublicWeatherAPIClient:
    """
    Robust API client querying Open-Meteo public endpoints using Python Standard Library (urllib).
    Switches to high-fidelity mock weather generation if network connection drops or times out.
    """

    GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
    FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
    REQUEST_TIMEOUT_SECONDS = 4.0

    @classmethod
    def geocode_city(cls, city_name: str) -> Tuple[float, float, str, str]:
        """
        Resolves city name to latitude, longitude, and country.
        Returns (latitude, longitude, country_name, source_type).
        """
        cleaned_city = city_name.strip()
        
        # 1. Try real Open-Meteo Geocoding API via requests or urllib
        try:
            params = {
                "name": cleaned_city,
                "count": 1,
                "language": "en",
                "format": "json"
            }
            if HAS_REQUESTS:
                resp = requests.get(cls.GEOCODING_URL, params=params, timeout=cls.REQUEST_TIMEOUT_SECONDS, headers={"User-Agent": "CampusSolve-PublicWeatherViewer/1.0"})
                if resp.status_code == 200:
                    data = resp.json()
                    results = data.get("results")
                    if results and len(results) > 0:
                        top = results[0]
                        lat = float(top.get("latitude", 0.0))
                        lon = float(top.get("longitude", 0.0))
                        country = str(top.get("country", "Global"))
                        return lat, lon, country, "Live Geocoding API"
            else:
                encoded = urllib.parse.urlencode(params)
                req_url = f"{cls.GEOCODING_URL}?{encoded}"
                req = urllib.request.Request(
                    req_url,
                    headers={"User-Agent": "CampusSolve-PublicWeatherViewer/1.0"}
                )
                with urllib.request.urlopen(req, timeout=cls.REQUEST_TIMEOUT_SECONDS) as response:
                    if response.status == 200:
                        data = json.loads(response.read().decode("utf-8"))
                        results = data.get("results")
                        if results and len(results) > 0:
                            top = results[0]
                            lat = float(top.get("latitude", 0.0))
                            lon = float(top.get("longitude", 0.0))
                            country = str(top.get("country", "Global"))
                            return lat, lon, country, "Live Geocoding API"
        except (RequestException, urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, json.JSONDecodeError, Exception):
            pass  # Seamlessly switch to mock fallback

        # 2. Mock Fallback from offline cache or algorithmic coordinate generator
        for known_city, (k_lat, k_lon, k_country) in CITY_GEO_CACHE.items():
            if known_city.lower() == cleaned_city.lower():
                return k_lat, k_lon, k_country, "Offline Geocoding Cache"

        # Deterministic coordinate hash for any unlisted city
        h = sum(ord(c) for c in cleaned_city)
        lat = round((h % 120) - 45.0 + ((h % 97) / 100.0), 4)
        lon = round((h * 3 % 340) - 170.0 + ((h % 89) / 100.0), 4)
        return lat, lon, "International", "Simulated Geocoding Engine"

    @classmethod
    def fetch_current_weather(cls, city_name: str) -> Tuple[WeatherRecord, str]:
        """
        Fetches current weather for a specified city name.
        Returns a populated WeatherRecord and status message.
        """
        lat, lon, country, geo_source = cls.geocode_city(city_name)
        now_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        record_id = f"WTR-{int(datetime.now().timestamp() * 1000)}"

        # Attempt Live Public API fetch via requests or urllib
        try:
            params = {
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,surface_pressure,wind_speed_10m"
            }
            curr = None
            if HAS_REQUESTS:
                resp = requests.get(cls.FORECAST_URL, params=params, timeout=cls.REQUEST_TIMEOUT_SECONDS, headers={"User-Agent": "CampusSolve-PublicWeatherViewer/1.0"})
                if resp.status_code == 200:
                    payload = resp.json()
                    curr = payload.get("current", {})
            else:
                encoded = urllib.parse.urlencode(params)
                req_url = f"{cls.FORECAST_URL}?{encoded}"
                req = urllib.request.Request(
                    req_url,
                    headers={"User-Agent": "CampusSolve-PublicWeatherViewer/1.0"}
                )
                with urllib.request.urlopen(req, timeout=cls.REQUEST_TIMEOUT_SECONDS) as response:
                    if response.status == 200:
                        payload = json.loads(response.read().decode("utf-8"))
                        curr = payload.get("current", {})

            if curr is not None:
                weather_code = int(curr.get("weather_code", 0))
                condition_desc = WMO_WEATHER_CODES.get(weather_code, "Atmospheric Conditions")
                
                record = WeatherRecord(
                    id=record_id,
                    city=city_name.title(),
                    country=country,
                    latitude=lat,
                    longitude=lon,
                    temperature_c=float(curr.get("temperature_2m", 20.0)),
                    apparent_temperature_c=float(curr.get("apparent_temperature", curr.get("temperature_2m", 20.0))),
                    humidity_pct=float(curr.get("relative_humidity_2m", 50.0)),
                    wind_speed_kmh=float(curr.get("wind_speed_10m", 10.0)),
                    precipitation_mm=float(curr.get("precipitation", 0.0)),
                    surface_pressure_hpa=float(curr.get("surface_pressure", 1013.25)),
                    weather_code=weather_code,
                    condition_description=condition_desc,
                    recorded_at=now_iso,
                    data_source="Live Open-Meteo Public API",
                    notes=f"Retrieved via {geo_source}"
                )
                return record, f"Successfully fetched live data via Open-Meteo for {city_name}."
        except (RequestException, urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, json.JSONDecodeError, Exception) as exc:
            pass  # Fall through to mock cache fallback

        # Resilient Offline Mock Simulation Generation
        # Base realistic climate conditions based on latitude
        lat_abs = abs(lat)
        if lat_abs > 60:
            base_temp = -8.0 + random.uniform(-10.0, 5.0)
            base_code = random.choice([71, 73, 75, 3])
        elif lat_abs < 25:
            base_temp = 28.0 + random.uniform(0.0, 10.0)
            base_code = random.choice([0, 1, 2, 80, 95])
        else:
            base_temp = 16.0 + random.uniform(-6.0, 9.0)
            base_code = random.choice([0, 1, 2, 3, 61, 63])

        precip = round(random.uniform(0.0, 18.0) if base_code in [61, 63, 65, 80, 95] else 0.0, 2)
        humidity = round(random.uniform(40.0, 92.0), 1)
        wind = round(random.uniform(5.0, 48.0), 1)
        pressure = round(random.uniform(995.0, 1024.0), 1)
        apparent = round(base_temp + (humidity / 100.0 * 2.5) - (wind * 0.1), 1)

        record = WeatherRecord(
            id=record_id,
            city=city_name.title(),
            country=country,
            latitude=lat,
            longitude=lon,
            temperature_c=round(base_temp, 1),
            apparent_temperature_c=apparent,
            humidity_pct=humidity,
            wind_speed_kmh=wind,
            precipitation_mm=precip,
            surface_pressure_hpa=pressure,
            weather_code=base_code,
            condition_description=WMO_WEATHER_CODES.get(base_code, "Partly Cloudy"),
            recorded_at=now_iso,
            data_source="Offline Mock Simulation Cache",
            notes="Generated gracefully via offline fallback routine due to network/API unavailability."
        )
        return record, f"Retrieved simulated data via Mock Cache Engine for {city_name} (network offline fallback)."
