"""
importer.py - Bulk Dataset Ingestion & Validation Module
Ingests legacy CSV weather datasets with automated format verification,
strict row-by-row schema checks, and detailed error logging for non-conforming entries.
"""

import csv
from typing import List, Dict, Any, Tuple
from .models import WeatherRecord
from .validator import DefensiveValidator


class BulkDatasetImporter:
    """Safely ingests and validates external CSV records."""

    REQUIRED_FIELDS = {"city", "temperature_c", "humidity_pct"}

    @classmethod
    def import_csv_file(cls, csv_filepath: str) -> Tuple[List[WeatherRecord], List[Dict[str, Any]], int]:
        """
        Ingests a CSV dataset, validating each row defensively.
        Returns:
            - valid_records: List[WeatherRecord]
            - error_logs: List of error dictionaries with line number and issue description
            - total_rows_read: int
        """
        valid_records: List[WeatherRecord] = []
        error_logs: List[Dict[str, Any]] = []
        total_rows = 0

        try:
            with open(csv_filepath, "r", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                
                # Check header conformity
                if not reader.fieldnames:
                    return [], [{"line": 1, "field": "HEADER", "error": "CSV file appears empty or missing headers."}], 0
                
                header_set = {h.strip().lower() for h in reader.fieldnames if h}
                missing = [req for req in cls.REQUIRED_FIELDS if req not in header_set]
                if missing:
                    return [], [{
                        "line": 1,
                        "field": "HEADER",
                        "error": f"Missing mandatory columns: {', '.join(missing)}"
                    }], 0

                for line_idx, row in enumerate(reader, start=2):
                    total_rows += 1
                    # Normalize keys
                    clean_row = {k.strip().lower(): v.strip() for k, v in row.items() if k and v is not None}
                    row_errors: List[str] = []

                    # 1. City validation
                    raw_city = clean_row.get("city", "")
                    city_res = DefensiveValidator.validate_city_name(raw_city)
                    if not city_res.is_valid:
                        row_errors.append(f"City '{raw_city}': {city_res.error_message}")

                    # 2. Temperature validation
                    raw_temp = clean_row.get("temperature_c", "")
                    temp_res = DefensiveValidator.validate_temperature(raw_temp, unit="C")
                    if not temp_res.is_valid:
                        row_errors.append(f"Temperature '{raw_temp}': {temp_res.error_message}")

                    # 3. Humidity validation
                    raw_hum = clean_row.get("humidity_pct", "")
                    hum_res = DefensiveValidator.validate_humidity(raw_hum)
                    if not hum_res.is_valid:
                        row_errors.append(f"Humidity '{raw_hum}': {hum_res.error_message}")

                    # 4. Optional coordinates
                    lat_val = 0.0
                    if "latitude" in clean_row and clean_row["latitude"]:
                        lat_res = DefensiveValidator.validate_latitude(clean_row["latitude"])
                        if lat_res.is_valid:
                            lat_val = lat_res.cleaned_value
                        else:
                            row_errors.append(f"Latitude: {lat_res.error_message}")

                    lon_val = 0.0
                    if "longitude" in clean_row and clean_row["longitude"]:
                        lon_res = DefensiveValidator.validate_longitude(clean_row["longitude"])
                        if lon_res.is_valid:
                            lon_val = lon_res.cleaned_value
                        else:
                            row_errors.append(f"Longitude: {lon_res.error_message}")

                    # 5. Wind & Precip
                    wind_val = 0.0
                    if "wind_speed_kmh" in clean_row and clean_row["wind_speed_kmh"]:
                        wind_res = DefensiveValidator.validate_wind_speed(clean_row["wind_speed_kmh"])
                        if wind_res.is_valid:
                            wind_val = wind_res.cleaned_value
                        else:
                            row_errors.append(f"Wind speed: {wind_res.error_message}")

                    precip_val = 0.0
                    if "precipitation_mm" in clean_row and clean_row["precipitation_mm"]:
                        precip_res = DefensiveValidator.validate_precipitation(clean_row["precipitation_mm"])
                        if precip_res.is_valid:
                            precip_val = precip_res.cleaned_value
                        else:
                            row_errors.append(f"Precipitation: {precip_res.error_message}")

                    # Check if row had any defects
                    if row_errors:
                        error_logs.append({
                            "line": line_idx,
                            "city": raw_city or "Unknown",
                            "errors": row_errors,
                            "raw": row
                        })
                    else:
                        # Construct validated record
                        record_dict = {
                            "id": clean_row.get("id") or f"IMP-{line_idx:04d}",
                            "city": city_res.cleaned_value,
                            "country": clean_row.get("country", "Global"),
                            "latitude": lat_val,
                            "longitude": lon_val,
                            "temperature_c": temp_res.cleaned_value,
                            "apparent_temperature_c": float(clean_row.get("apparent_temperature_c") or temp_res.cleaned_value),
                            "humidity_pct": hum_res.cleaned_value,
                            "wind_speed_kmh": wind_val,
                            "precipitation_mm": precip_val,
                            "surface_pressure_hpa": float(clean_row.get("surface_pressure_hpa") or 1013.25),
                            "weather_code": int(clean_row.get("weather_code") or 0),
                            "condition_description": clean_row.get("condition_description") or "Imported Record",
                            "recorded_at": clean_row.get("recorded_at") or "2026-11-20T10:00:00",
                            "deadline_at": clean_row.get("deadline_at", ""),
                            "data_source": "Bulk Legacy CSV Import",
                            "notes": clean_row.get("notes") or f"Imported from {csv_filepath}"
                        }
                        valid_records.append(WeatherRecord.from_dict(record_dict))

        except Exception as exc:
            error_logs.append({
                "line": 0,
                "field": "FILE_IO",
                "error": f"Failed reading CSV file: {exc}"
            })

        return valid_records, error_logs, total_rows
