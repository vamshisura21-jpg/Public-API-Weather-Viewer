"""
exporter.py - Multi-Format Summary Export Module
Generates structured Markdown reports, plain-text audit logs, and standardized CSV summaries.
Ensures comprehensive compliance reporting and external audit review capabilities.
"""

import csv
import os
from datetime import datetime
from typing import List, Optional
from .models import WeatherRecord, ExecutiveSummary


class MultiFormatExporter:
    """Handles structured document and data export routines."""

    @classmethod
    def export_all_formats(
        cls,
        records: List[WeatherRecord],
        summary: Optional[ExecutiveSummary],
        export_dir: str
    ) -> dict:
        """Exports Markdown, Audit Log, and CSV simultaneously."""
        os.makedirs(export_dir, exist_ok=True)
        results = {}

        md_path = os.path.join(export_dir, "summary_report.md")
        log_path = os.path.join(export_dir, "audit_log.txt")
        csv_path = os.path.join(export_dir, "weather_export.csv")

        results["markdown"] = cls.export_markdown_report(records, summary, md_path)
        results["audit_log"] = cls.export_audit_log(records, summary, log_path)
        results["csv"] = cls.export_standardized_csv(records, csv_path)

        return results

    @classmethod
    def export_markdown_report(
        cls,
        records: List[WeatherRecord],
        summary: Optional[ExecutiveSummary],
        target_path: str
    ) -> str:
        """Generates a structured, professional Markdown executive summary report."""
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            "# Public API Weather Viewer: Executive Meteorological Report",
            f"**Generated On:** {now_str} | **Project:** CampusSolve #111",
            "",
            "## 1. Executive Summary & Core Aggregates",
            ""
        ]

        if summary:
            lines.extend([
                "| Metric Description | Value |",
                "| :--- | :--- |",
                f"| **Total Monitored Stations** | {summary.total_records} stations |",
                f"| **Average Temperature** | {summary.avg_temperature_c} °C ({round(summary.avg_temperature_c * 9/5 + 32, 1)} °F) |",
                f"| **Temperature Extremes** | Min: {summary.min_temperature_c} °C / Max: {summary.max_temperature_c} °C |",
                f"| **Median Temperature** | {summary.median_temperature_c} °C |",
                f"| **Average Relative Humidity** | {summary.avg_humidity_pct} % |",
                f"| **Mean Wind Speed** | {summary.avg_wind_speed_kmh} km/h (Peak: {summary.max_wind_speed_kmh} km/h) |",
                f"| **Cumulative Precipitation** | {summary.total_precipitation_mm} mm (Peak: {summary.max_precipitation_mm} mm) |",
                f"| **Mean Surface Pressure** | {summary.avg_pressure_hpa} hPa |",
                f"| **Critical Limit Breaches** | **{summary.critical_alerts_count}** alerts |",
                f"| **Warning Advisories** | {summary.warning_alerts_count} advisories |",
                f"| **Nominal Stations** | {summary.nominal_count} stations |",
                f"| **Overdue Deadlines** | {summary.overdue_deadlines_count} stations |",
                ""
            ])
        else:
            lines.append("*No records available for statistical calculation.*\n")

        lines.extend([
            "## 2. Threshold Warning & Anomaly Register",
            ""
        ])

        anomalous = [r for r in records if r.has_warning]
        if anomalous:
            lines.extend([
                "| Station | Temperature | Wind | Precip | Active Status Warnings |",
                "| :--- | :--- | :--- | :--- | :--- |"
            ])
            for r in anomalous:
                flags = "<br>".join(r.status_indicators)
                lines.append(f"| **{r.city}** ({r.country}) | {r.temperature_c}°C | {r.wind_speed_kmh} km/h | {r.precipitation_mm} mm | {flags} |")
            lines.append("")
        else:
            lines.append("All monitored stations operated within nominal safety and meteorological boundaries.\n")

        lines.extend([
            "## 3. Station Records Audit Table",
            "",
            "| ID | City | Country | Temp (°C) | Humidity (%) | Wind (km/h) | Condition | Data Source |",
            "| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |"
        ])

        for r in records[:25]:  # Top 25
            lines.append(
                f"| `{r.id}` | {r.city} | {r.country} | {r.temperature_c} | "
                f"{r.humidity_pct}% | {r.wind_speed_kmh} | {r.condition_description} | {r.data_source} |"
            )

        if len(records) > 25:
            lines.append(f"\n*... and {len(records) - 25} additional stations stored in persistent database.*")

        lines.extend([
            "",
            "---",
            "*Report compiled automatically by CampusSolve Public API Weather Viewer.*"
        ])

        with open(target_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        return target_path

    @classmethod
    def export_audit_log(
        cls,
        records: List[WeatherRecord],
        summary: Optional[ExecutiveSummary],
        target_path: str
    ) -> str:
        """Generates plain-text audit logs documenting system operations and anomaly flags."""
        now_str = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
        lines = [
            f"=== CAMPUSSOLVE WEATHER VIEWER - SYSTEM AUDIT LOG ===",
            f"TIMESTAMP: {now_str}",
            f"RECORDS_INSPECTED: {len(records)}",
            "--------------------------------------------------------------------------------"
        ]

        for idx, r in enumerate(records, 1):
            severity = "CRIT" if r.has_critical_alert else ("WARN" if r.has_warning else "INFO")
            flags_str = "; ".join(r.status_indicators)
            lines.append(
                f"[{r.recorded_at}] [{severity:<4}] STATION: {r.city:<16} | T: {r.temperature_c:>5.1f}C | "
                f"H: {r.humidity_pct:>5.1f}% | W: {r.wind_speed_kmh:>5.1f}km/h | FLAGS: {flags_str}"
            )

        lines.append("--------------------------------------------------------------------------------")
        lines.append("SYSTEM STATE: All records verified, schema constraints validated.")
        lines.append(f"END OF AUDIT LOG ({len(records)} entries).")

        with open(target_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        return target_path

    @classmethod
    def export_standardized_csv(cls, records: List[WeatherRecord], target_path: str) -> str:
        """Exports RFC-4180 compliant CSV export file."""
        headers = [
            "id", "city", "country", "latitude", "longitude",
            "temperature_c", "temperature_f", "apparent_temperature_c",
            "humidity_pct", "wind_speed_kmh", "wind_speed_mph",
            "precipitation_mm", "surface_pressure_hpa", "weather_code",
            "condition_description", "recorded_at", "deadline_at", "status_summary", "data_source"
        ]

        with open(target_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            for r in records:
                writer.writerow([
                    r.id, r.city, r.country, r.latitude, r.longitude,
                    r.temperature_c, r.temperature_f, r.apparent_temperature_c,
                    r.humidity_pct, r.wind_speed_kmh, r.wind_speed_mph,
                    r.precipitation_mm, r.surface_pressure_hpa, r.weather_code,
                    r.condition_description, r.recorded_at, r.deadline_at,
                    " | ".join(r.status_indicators), r.data_source
                ])
        return target_path
