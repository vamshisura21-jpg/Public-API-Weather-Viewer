"""
models.py - Foundational Data Structures for Public API Weather Viewer
Defines dataclasses modeling core record attributes, operational states, validation results,
and executive summary metrics.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Dict, Any, List, Optional


@dataclass
class WeatherRecord:
    """Represents a single verified weather observation record."""
    id: str
    city: str
    country: str
    latitude: float
    longitude: float
    temperature_c: float
    apparent_temperature_c: float
    humidity_pct: float
    wind_speed_kmh: float
    precipitation_mm: float
    surface_pressure_hpa: float
    weather_code: int
    condition_description: str
    recorded_at: str  # ISO-8601 string: YYYY-MM-DDTHH:MM:SS
    data_source: str = "Open-Meteo Public API"  # or "Mock Fallback Engine", "CSV Import"
    notes: str = ""
    deadline_at: str = ""  # Optional observation / reporting deadline

    @property
    def temperature_f(self) -> float:
        """Returns temperature in Fahrenheit."""
        return round((self.temperature_c * 9 / 5) + 32, 1)

    @property
    def wind_speed_mph(self) -> float:
        """Returns wind speed in Miles Per Hour."""
        return round(self.wind_speed_kmh * 0.621371, 1)

    @property
    def status_indicators(self) -> List[str]:
        """Calculates threshold warning indicators, overdue deadlines, and anomaly flags."""
        flags: List[str] = []

        # 1. Overdue Reporting Deadline Check
        if self.deadline_at:
            try:
                clean_dl = self.deadline_at.replace("Z", "").split(".")[0]
                dl_time = datetime.fromisoformat(clean_dl)
                if datetime.now() > dl_time:
                    flags.append(f"CRITICAL: Overdue Reporting Deadline (Lapsed: {self.deadline_at})")
            except (ValueError, TypeError):
                pass

        # 2. Atmospheric Thermal Thresholds
        if self.temperature_c >= 40.0:
            flags.append("CRITICAL: Extreme Heat Wave (>=40°C)")
        elif self.temperature_c >= 35.0:
            flags.append("WARNING: High Heat Advisory (>=35°C)")
        elif self.temperature_c <= -10.0:
            flags.append("CRITICAL: Extreme Sub-Zero Freeze (<=-10°C)")
        elif self.temperature_c <= 0.0:
            flags.append("WARNING: Freezing Frost Risk (<=0°C)")

        # 3. Kinetic Wind Thresholds
        if self.wind_speed_kmh >= 80.0:
            flags.append("CRITICAL: Severe Gale / Storm Wind (>=80km/h)")
        elif self.wind_speed_kmh >= 50.0:
            flags.append("WARNING: High Wind Alert (>=50km/h)")

        # 4. Hydrological Precipitation Thresholds
        if self.precipitation_mm >= 50.0:
            flags.append("CRITICAL: Torrential Downpour / Flood Risk (>=50mm)")
        elif self.precipitation_mm >= 20.0:
            flags.append("WARNING: Heavy Precipitation (>=20mm)")

        # 5. Moisture & Aridity Thresholds
        if self.humidity_pct >= 95.0:
            flags.append("NOTICE: Saturated Humidity (>=95%)")
        elif self.humidity_pct <= 15.0:
            flags.append("WARNING: Extreme Aridity / Fire Hazard (<=15%)")

        # 6. Barometric Pressure Anomalies
        if self.surface_pressure_hpa < 970.0:
            flags.append("CRITICAL: Severe Low Pressure System (<970 hPa)")
        elif self.surface_pressure_hpa < 990.0:
            flags.append("WARNING: Depressed Barometric Pressure (<990 hPa)")

        if not flags:
            flags.append("NORMAL: Nominal Atmospheric Conditions")
        return flags

    @property
    def has_critical_alert(self) -> bool:
        """Returns True if any critical limit breach or overdue deadline is active."""
        return any(flag.startswith("CRITICAL:") for flag in self.status_indicators)

    @property
    def has_warning(self) -> bool:
        """Returns True if any warning or critical alert is active."""
        return any(flag.startswith("WARNING:") or flag.startswith("CRITICAL:") for flag in self.status_indicators)

    @property
    def is_overdue(self) -> bool:
        """Returns True if the record has an overdue reporting deadline."""
        return any("Overdue" in flag for flag in self.status_indicators)

    def to_dict(self) -> Dict[str, Any]:
        """Serializes dataclass to standard Python dictionary."""
        data = asdict(self)
        data["temperature_f"] = self.temperature_f
        data["wind_speed_mph"] = self.wind_speed_mph
        data["status_indicators"] = self.status_indicators
        data["has_critical_alert"] = self.has_critical_alert
        data["is_overdue"] = self.is_overdue
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "WeatherRecord":
        """Instantiates a WeatherRecord from a dictionary, handling extra/missing keys."""
        valid_keys = {
            "id", "city", "country", "latitude", "longitude",
            "temperature_c", "apparent_temperature_c", "humidity_pct",
            "wind_speed_kmh", "precipitation_mm", "surface_pressure_hpa",
            "weather_code", "condition_description", "recorded_at",
            "data_source", "notes", "deadline_at"
        }
        filtered_data = {k: v for k, v in data.items() if k in valid_keys}
        
        # Ensure proper numeric typing
        filtered_data["latitude"] = float(filtered_data.get("latitude", 0.0))
        filtered_data["longitude"] = float(filtered_data.get("longitude", 0.0))
        filtered_data["temperature_c"] = float(filtered_data.get("temperature_c", 0.0))
        filtered_data["apparent_temperature_c"] = float(filtered_data.get("apparent_temperature_c", filtered_data["temperature_c"]))
        filtered_data["humidity_pct"] = float(filtered_data.get("humidity_pct", 0.0))
        filtered_data["wind_speed_kmh"] = float(filtered_data.get("wind_speed_kmh", 0.0))
        filtered_data["precipitation_mm"] = float(filtered_data.get("precipitation_mm", 0.0))
        filtered_data["surface_pressure_hpa"] = float(filtered_data.get("surface_pressure_hpa", 1013.25))
        filtered_data["weather_code"] = int(filtered_data.get("weather_code", 0))
        filtered_data["city"] = str(filtered_data.get("city", "Unknown")).strip()
        filtered_data["country"] = str(filtered_data.get("country", "Unknown")).strip()
        filtered_data["condition_description"] = str(filtered_data.get("condition_description", "Clear Sky")).strip()
        filtered_data["recorded_at"] = str(filtered_data.get("recorded_at", datetime.now().isoformat()))
        filtered_data["data_source"] = str(filtered_data.get("data_source", "Stored Record"))
        filtered_data["notes"] = str(filtered_data.get("notes", ""))
        filtered_data["deadline_at"] = str(filtered_data.get("deadline_at", "") or "")
        
        if "id" not in filtered_data or not filtered_data["id"]:
            filtered_data["id"] = f"WTR-{int(datetime.now().timestamp() * 1000)}"

        return cls(**filtered_data)


@dataclass
class ValidationResult:
    """Represents the outcome of a defensive input validation check."""
    is_valid: bool
    cleaned_value: Any = None
    error_message: Optional[str] = None
    warnings: List[str] = field(default_factory=list)


@dataclass
class ExecutiveSummary:
    """Holds aggregated statistical metrics and operational indicators."""
    total_records: int
    avg_temperature_c: float
    min_temperature_c: float
    max_temperature_c: float
    median_temperature_c: float
    avg_humidity_pct: float
    avg_wind_speed_kmh: float
    max_wind_speed_kmh: float
    total_precipitation_mm: float
    max_precipitation_mm: float
    avg_pressure_hpa: float
    condition_counts: Dict[str, int]
    critical_alerts_count: int
    warning_alerts_count: int
    nominal_count: int
    overdue_deadlines_count: int = 0
    generated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
