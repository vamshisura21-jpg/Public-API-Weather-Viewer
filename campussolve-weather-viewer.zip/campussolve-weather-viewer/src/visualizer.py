"""
visualizer.py - Visual Data Plotting Module
Generates clear trend charts and distributions for exported reports.
Uses Matplotlib when available. Gracefully falls back to high-resolution vector SVG
generation and ANSI terminal ASCII charts when external dependencies are uninstalled.
"""

import math
import os
from typing import List, Dict, Optional
from .models import WeatherRecord, ExecutiveSummary


class VisualDataPlotter:
    """Manages visual plotting for terminal output and file exports."""

    @classmethod
    def plot_and_export(
        cls,
        records: List[WeatherRecord],
        summary: ExecutiveSummary,
        output_png_path: str,
        output_svg_path: str
    ) -> Dict[str, str]:
        """
        Attempts to generate Matplotlib charts (PNG).
        Always ensures an SVG vector chart is exported as well for guaranteed zero-dependency output.
        Returns a dictionary of generated files and status notes.
        """
        results = {}

        # 1. Always generate pure-Python SVG vector chart (100% dependency-free)
        try:
            cls._generate_svg_chart(records, summary, output_svg_path)
            results["svg"] = output_svg_path
        except Exception as e:
            results["svg_error"] = str(e)

        # 2. Attempt Matplotlib PNG generation if library is available
        try:
            import matplotlib
            matplotlib.use("Agg")  # Headless backend safe for terminal execution
            import matplotlib.pyplot as plt

            os.makedirs(os.path.dirname(os.path.abspath(output_png_path)), exist_ok=True)
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
            fig.patch.set_facecolor("#1e293b")

            # Chart 1: Temperature Comparison Bar Chart
            sample_cities = records[:12]  # Top 12 records
            cities = [r.city for r in sample_cities]
            temps = [r.temperature_c for r in sample_cities]
            colors = [
                "#ef4444" if t >= 35.0 else ("#3b82f6" if t <= 0.0 else "#10b981")
                for t in temps
            ]

            ax1.set_facecolor("#0f172a")
            bars = ax1.barh(cities, temps, color=colors, edgecolor="#334155")
            ax1.set_title("Temperature Distribution (°C)", color="#f8fafc", fontsize=12, fontweight="bold")
            ax1.set_xlabel("Temperature (°C)", color="#94a3b8")
            ax1.tick_params(colors="#94a3b8")
            for spine in ax1.spines.values():
                spine.set_color("#334155")

            # Chart 2: Weather Conditions Pie Distribution
            top_conditions = dict(sorted(summary.condition_counts.items(), key=lambda x: x[1], reverse=True)[:6])
            labels = list(top_conditions.keys())
            counts = list(top_conditions.values())
            pie_colors = ["#38bdf8", "#818cf8", "#c084fc", "#f472b6", "#fb923c", "#4ade80"]

            ax2.set_facecolor("#0f172a")
            wedges, texts, autotexts = ax2.pie(
                counts,
                labels=labels,
                autopct="%1.1f%%",
                colors=pie_colors[:len(labels)],
                textprops={"color": "#f8fafc"}
            )
            ax2.set_title("Weather Conditions Breakdown", color="#f8fafc", fontsize=12, fontweight="bold")

            plt.tight_layout()
            plt.savefig(output_png_path, dpi=180, facecolor=fig.get_facecolor(), bbox_inches="tight")
            plt.close()
            results["png"] = output_png_path
            results["matplotlib_status"] = "Rendered successfully via Matplotlib engine."
        except ImportError:
            results["matplotlib_status"] = (
                "Matplotlib library not installed. Gracefully fell back to high-res SVG chart "
                f"and terminal ASCII visualization ({output_svg_path})."
            )
        except Exception as e:
            results["matplotlib_status"] = f"Matplotlib rendering encountered exception: {e}"

        return results

    @classmethod
    def _generate_svg_chart(cls, records: List[WeatherRecord], summary: ExecutiveSummary, output_path: str) -> None:
        """Generates a standalone, beautiful SVG dashboard chart without any third-party libraries."""
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        sample = records[:10]
        
        svg_parts = [
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 520" width="100%" height="100%">',
            '  <defs>',
            '    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">',
            '      <stop offset="0%" stop-color="#0f172a"/>',
            '      <stop offset="100%" stop-color="#1e293b"/>',
            '    </linearGradient>',
            '    <linearGradient id="barGrad" x1="0%" y1="0%" x2="100%" y2="0%">',
            '      <stop offset="0%" stop-color="#0284c7"/>',
            '      <stop offset="100%" stop-color="#38bdf8"/>',
            '    </linearGradient>',
            '  </defs>',
            '  <rect width="900" height="520" rx="16" fill="url(#bgGrad)"/>',
            '  <text x="30" y="45" font-family="system-ui, sans-serif" font-size="22" font-weight="700" fill="#f8fafc">Public API Weather Viewer - Executive Visual Analytics</text>',
            f'  <text x="30" y="70" font-family="system-ui, sans-serif" font-size="13" fill="#94a3b8">Sampled Station Trends | Total Records: {summary.total_records} | Avg Temp: {summary.avg_temperature_c}°C</text>',
            '  <!-- Bar Chart Frame -->',
            '  <rect x="30" y="95" width="520" height="390" rx="10" fill="#111827" stroke="#334155" stroke-width="1"/>',
            '  <text x="50" y="125" font-family="system-ui, sans-serif" font-size="14" font-weight="600" fill="#38bdf8">Station Temperatures (°C)</text>'
        ]

        # Draw horizontal bars
        start_y = 150
        bar_height = 24
        gap = 12
        max_t = max([abs(r.temperature_c) for r in sample] + [40.0])
        scale = 260.0 / max_t

        for i, rec in enumerate(sample):
            y = start_y + i * (bar_height + gap)
            bar_w = max(10, int(abs(rec.temperature_c) * scale))
            color = "#ef4444" if rec.temperature_c >= 35.0 else ("#38bdf8" if rec.temperature_c <= 0 else "#10b981")
            
            svg_parts.append(f'  <text x="50" y="{y + 16}" font-family="system-ui, sans-serif" font-size="12" fill="#cbd5e1">{rec.city[:12]}</text>')
            svg_parts.append(f'  <rect x="150" y="{y}" width="{bar_w}" height="{bar_height}" rx="4" fill="{color}"/>')
            svg_parts.append(f'  <text x="{160 + bar_w}" y="{y + 16}" font-family="system-ui, sans-serif" font-size="11" font-weight="bold" fill="#f8fafc">{rec.temperature_c}°C</text>')

        # Right Summary Box
        svg_parts.extend([
            '  <rect x="570" y="95" width="300" height="390" rx="10" fill="#111827" stroke="#334155" stroke-width="1"/>',
            '  <text x="590" y="125" font-family="system-ui, sans-serif" font-size="14" font-weight="600" fill="#f59e0b">Key Atmospheric Indicators</text>',
            f'  <text x="590" y="165" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Min Temperature: <tspan fill="#38bdf8" font-weight="bold">{summary.min_temperature_c}°C</tspan></text>',
            f'  <text x="590" y="195" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Max Temperature: <tspan fill="#ef4444" font-weight="bold">{summary.max_temperature_c}°C</tspan></text>',
            f'  <text x="590" y="225" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Mean Humidity: <tspan fill="#a855f7" font-weight="bold">{summary.avg_humidity_pct}%</tspan></text>',
            f'  <text x="590" y="255" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Avg Wind Speed: <tspan fill="#10b981" font-weight="bold">{summary.avg_wind_speed_kmh} km/h</tspan></text>',
            f'  <text x="590" y="285" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Total Precipitation: <tspan fill="#3b82f6" font-weight="bold">{summary.total_precipitation_mm} mm</tspan></text>',
            f'  <text x="590" y="325" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Critical Limit Alerts: <tspan fill="#f43f5e" font-weight="bold">{summary.critical_alerts_count}</tspan></text>',
            f'  <text x="590" y="355" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Warning Advisories: <tspan fill="#fbbf24" font-weight="bold">{summary.warning_alerts_count}</tspan></text>',
            f'  <text x="590" y="385" font-family="system-ui, sans-serif" font-size="13" fill="#cbd5e1">• Nominal Operations: <tspan fill="#10b981" font-weight="bold">{summary.nominal_count}</tspan></text>',
            '  <text x="590" y="445" font-family="system-ui, sans-serif" font-size="11" fill="#64748b">Generated by CampusSolve Weather Viewer</text>',
            '</svg>'
        ])

        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(svg_parts))

    @classmethod
    def display_terminal_ascii_chart(cls, records: List[WeatherRecord]) -> None:
        """Renders an elegant, formatted ASCII horizontal bar chart in the console."""
        if not records:
            print("  \033[33mNo records to plot in ASCII chart.\033[0m")
            return

        sample = records[:12]
        print("\n\033[1;36m=== VISUAL TERMINAL DISTRIBUTION (TEMPERATURE °C) ===\033[0m")
        print("Station City        | Temp (°C) | Visual Bar Scale (-20°C to +50°C)")
        print("--------------------+-----------+----------------------------------------------")

        for r in sample:
            t = r.temperature_c
            # Scale -20 to +50 (70 units span) into 35 terminal characters
            offset = max(0, min(35, int((t + 20) / 2)))
            bar = "■" * offset
            color = "\033[31m" if t >= 35.0 else ("\033[34m" if t <= 0.0 else "\033[32m")
            print(f"{r.city[:18]:<19} | {t:>6.1f}°C  | {color}{bar}\033[0m ({t:.1f}°C)")
        print("--------------------+-----------+----------------------------------------------\n")
