"""
analytics.py - Executive Summary Generation, Query & Search, and Trend Analytics
Implements computational aggregation algorithms, keyword/category filtering,
threshold anomaly detection, and statistical trend calculations.
"""

import statistics
from typing import List, Dict, Any, Optional
from .models import WeatherRecord, ExecutiveSummary


class WeatherAnalyticsEngine:
    """Provides statistical aggregation, search filtering, and trend analytics."""

    @staticmethod
    def filter_records(
        records: List[WeatherRecord],
        keyword: Optional[str] = None,
        condition_filter: Optional[str] = None,
        min_temp: Optional[float] = None,
        max_temp: Optional[float] = None,
        alerts_only: bool = False
    ) -> List[WeatherRecord]:
        """
        Filters records based on multiple user-defined criteria.
        Enables swift keyword search and multi-dimensional category queries.
        """
        filtered = records

        # 1. Keyword search (City, Country, Notes)
        if keyword:
            kw = keyword.strip().lower()
            filtered = [
                r for r in filtered
                if kw in r.city.lower()
                or kw in r.country.lower()
                or kw in r.condition_description.lower()
                or kw in r.notes.lower()
            ]

        # 2. Condition category filter
        if condition_filter and condition_filter.upper() != "ALL":
            cf = condition_filter.strip().lower()
            filtered = [
                r for r in filtered
                if cf in r.condition_description.lower()
            ]

        # 3. Temperature bounds
        if min_temp is not None:
            filtered = [r for r in filtered if r.temperature_c >= min_temp]
        if max_temp is not None:
            filtered = [r for r in filtered if r.temperature_c <= max_temp]

        # 4. Critical alerts or warnings only
        if alerts_only:
            filtered = [r for r in filtered if r.has_warning]

        return filtered

    @staticmethod
    def generate_executive_summary(records: List[WeatherRecord]) -> Optional[ExecutiveSummary]:
        """
        Computes high-level aggregated summary, averages, distribution, and status metrics.
        Returns None if dataset is empty.
        """
        if not records:
            return None

        temps = [r.temperature_c for r in records]
        humidities = [r.humidity_pct for r in records]
        winds = [r.wind_speed_kmh for r in records]
        precips = [r.precipitation_mm for r in records]
        pressures = [r.surface_pressure_hpa for r in records]

        # Condition breakdown
        cond_counts: Dict[str, int] = {}
        crit_count = 0
        warn_count = 0
        norm_count = 0
        overdue_count = 0

        for r in records:
            desc = r.condition_description
            cond_counts[desc] = cond_counts.get(desc, 0) + 1
            if r.is_overdue:
                overdue_count += 1
            if r.has_critical_alert:
                crit_count += 1
            elif r.has_warning:
                warn_count += 1
            else:
                norm_count += 1

        summary = ExecutiveSummary(
            total_records=len(records),
            avg_temperature_c=round(statistics.mean(temps), 2),
            min_temperature_c=round(min(temps), 2),
            max_temperature_c=round(max(temps), 2),
            median_temperature_c=round(statistics.median(temps), 2),
            avg_humidity_pct=round(statistics.mean(humidities), 2),
            avg_wind_speed_kmh=round(statistics.mean(winds), 2),
            max_wind_speed_kmh=round(max(winds), 2),
            total_precipitation_mm=round(sum(precips), 2),
            max_precipitation_mm=round(max(precips), 2),
            avg_pressure_hpa=round(statistics.mean(pressures), 2),
            condition_counts=cond_counts,
            critical_alerts_count=crit_count,
            warning_alerts_count=warn_count,
            nominal_count=norm_count,
            overdue_deadlines_count=overdue_count
        )
        return summary

    @staticmethod
    def compute_trend_insights(records: List[WeatherRecord]) -> List[str]:
        """Generates qualitative trend commentary and operational alerts."""
        if not records:
            return ["No data available to formulate trend insights."]

        insights: List[str] = []
        temps = [r.temperature_c for r in records]
        precips = [r.precipitation_mm for r in records]
        winds = [r.wind_speed_kmh for r in records]

        # Temperature thermal profile
        avg_temp = statistics.mean(temps)
        if avg_temp >= 28.0:
            insights.append("Thermal Trend: Prevailing tropical/sub-tropical high-temperature pattern.")
        elif avg_temp <= 5.0:
            insights.append("Thermal Trend: Predominantly sub-polar/winter freeze conditions observed.")
        else:
            insights.append("Thermal Trend: Temperate, moderate atmospheric distribution across locations.")

        # Extreme variations
        temp_spread = max(temps) - min(temps)
        if temp_spread > 30.0:
            insights.append(f"Thermal Disparity: High regional variance detected (spread of {temp_spread:.1f}°C).")

        # Hydrological pattern
        rainy_count = sum(1 for p in precips if p > 0.5)
        rain_ratio = (rainy_count / len(records)) * 100
        if rain_ratio >= 40.0:
            insights.append(f"Hydrological Alert: Active precipitation systems present across {rain_ratio:.0f}% of monitored sites.")
        else:
            insights.append(f"Hydrological Status: Dry atmospheric conditions dominant ({100 - rain_ratio:.0f}% non-precipitating).")

        # Wind kinetic profile
        gale_count = sum(1 for w in winds if w >= 50.0)
        if gale_count > 0:
            insights.append(f"Kinetic Storm Risk: {gale_count} station(s) reporting near-gale or gale-force winds (>=50 km/h).")

        # Operational Deadline Alerts
        overdue_count = sum(1 for r in records if r.is_overdue)
        if overdue_count > 0:
            insights.append(f"Operational Advisory: {overdue_count} station(s) have overdue reporting deadlines requiring refresh.")

        return insights
