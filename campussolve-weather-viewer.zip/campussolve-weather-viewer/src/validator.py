"""
validator.py - Defensive Input Validation Module
Provides robust sanitization, regex matching, range checks, and safe interactive terminal input wrappers.
Guarantees program resilience against blank, malformed, out-of-bound, or non-numeric entries.
"""

import re
from typing import Any, Callable, Optional, Set
from .models import ValidationResult


class DefensiveValidator:
    """Encapsulates all domain-specific validation and sanitization algorithms."""

    CITY_PATTERN = re.compile(r"^[A-Za-z\s\-'.]{2,60}$")
    ISO_DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}(?:[T\s]\d{2}:\d{2}(?::\d{2})?)?$")

    @classmethod
    def validate_city_name(cls, raw_input: Any) -> ValidationResult:
        """Sanitizes and validates city names."""
        if raw_input is None:
            return ValidationResult(False, error_message="City name cannot be null or empty.")
        cleaned = str(raw_input).strip()
        if not cleaned:
            return ValidationResult(False, error_message="City name cannot be blank.")
        if len(cleaned) < 2:
            return ValidationResult(False, error_message="City name too short (minimum 2 characters).")
        if len(cleaned) > 60:
            return ValidationResult(False, error_message="City name exceeds 60 characters limit.")
        if not cls.CITY_PATTERN.match(cleaned):
            return ValidationResult(
                False,
                error_message="Invalid characters in city name. Only letters, spaces, hyphens, and apostrophes allowed."
            )
        # Title case normalized
        normalized = cleaned.title()
        return ValidationResult(True, cleaned_value=normalized)

    @classmethod
    def validate_latitude(cls, raw_input: Any) -> ValidationResult:
        """Validates geographic latitude (-90.0 to +90.0)."""
        try:
            val = float(str(raw_input).strip())
            if not (-90.0 <= val <= 90.0):
                return ValidationResult(False, error_message="Latitude must be between -90.0 and +90.0 degrees.")
            return ValidationResult(True, cleaned_value=round(val, 4))
        except (ValueError, TypeError):
            return ValidationResult(False, error_message="Latitude must be a valid decimal number.")

    @classmethod
    def validate_longitude(cls, raw_input: Any) -> ValidationResult:
        """Validates geographic longitude (-180.0 to +180.0)."""
        try:
            val = float(str(raw_input).strip())
            if not (-180.0 <= val <= 180.0):
                return ValidationResult(False, error_message="Longitude must be between -180.0 and +180.0 degrees.")
            return ValidationResult(True, cleaned_value=round(val, 4))
        except (ValueError, TypeError):
            return ValidationResult(False, error_message="Longitude must be a valid decimal number.")

    @classmethod
    def validate_temperature(cls, raw_input: Any, unit: str = "C") -> ValidationResult:
        """Validates atmospheric temperature (-60°C to +65°C or -76°F to +149°F)."""
        try:
            val = float(str(raw_input).strip())
            if unit.upper() == "F":
                # Convert to Celsius for uniform range checking
                temp_c = (val - 32.0) * 5 / 9
            else:
                temp_c = val
            
            if not (-60.0 <= temp_c <= 65.0):
                return ValidationResult(
                    False,
                    error_message=f"Temperature {val}°{unit.upper()} is outside terrestrial physical limits (-60°C to 65°C)."
                )
            return ValidationResult(True, cleaned_value=round(temp_c, 2))
        except (ValueError, TypeError):
            return ValidationResult(False, error_message="Temperature must be a valid numeric value.")

    @classmethod
    def validate_humidity(cls, raw_input: Any) -> ValidationResult:
        """Validates relative humidity percentage (0.0% to 100.0%)."""
        try:
            val = float(str(raw_input).strip())
            if not (0.0 <= val <= 100.0):
                return ValidationResult(False, error_message="Relative humidity must be strictly between 0% and 100%.")
            return ValidationResult(True, cleaned_value=round(val, 1))
        except (ValueError, TypeError):
            return ValidationResult(False, error_message="Humidity must be a valid percentage decimal.")

    @classmethod
    def validate_wind_speed(cls, raw_input: Any) -> ValidationResult:
        """Validates wind velocity in km/h (0.0 to 350.0 km/h)."""
        try:
            val = float(str(raw_input).strip())
            if not (0.0 <= val <= 350.0):
                return ValidationResult(False, error_message="Wind speed must be between 0.0 and 350.0 km/h.")
            return ValidationResult(True, cleaned_value=round(val, 2))
        except (ValueError, TypeError):
            return ValidationResult(False, error_message="Wind speed must be a non-negative number.")

    @classmethod
    def validate_precipitation(cls, raw_input: Any) -> ValidationResult:
        """Validates rainfall/snow precipitation in mm (0.0 to 1500.0 mm)."""
        try:
            val = float(str(raw_input).strip())
            if not (0.0 <= val <= 1500.0):
                return ValidationResult(False, error_message="Precipitation must be between 0.0 and 1500.0 mm.")
            return ValidationResult(True, cleaned_value=round(val, 2))
        except (ValueError, TypeError):
            return ValidationResult(False, error_message="Precipitation must be a non-negative number.")

    @classmethod
    def validate_pressure(cls, raw_input: Any) -> ValidationResult:
        """Validates atmospheric surface pressure in hPa (800.0 to 1100.0 hPa)."""
        try:
            val = float(str(raw_input).strip())
            if not (800.0 <= val <= 1100.0):
                return ValidationResult(False, error_message="Atmospheric pressure must be between 800.0 and 1100.0 hPa.")
            return ValidationResult(True, cleaned_value=round(val, 2))
        except (ValueError, TypeError):
            return ValidationResult(False, error_message="Pressure must be a valid number.")

    @classmethod
    def validate_timestamp(cls, raw_input: Any) -> ValidationResult:
        """Validates date/time string conforming to ISO format."""
        if not raw_input:
            return ValidationResult(False, error_message="Timestamp cannot be empty.")
        cleaned = str(raw_input).strip()
        if not cls.ISO_DATE_PATTERN.match(cleaned):
            return ValidationResult(False, error_message="Date must follow YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS format.")
        return ValidationResult(True, cleaned_value=cleaned)


def prompt_with_validation(
    prompt_text: str,
    validator_func: Callable[[str], ValidationResult],
    default_val: Optional[str] = None
) -> Any:
    """
    Centralized terminal input wrapper function that loops defensively
    until a valid input meeting domain constraints is provided.
    Prevents program crashes from empty or illegal user inputs.
    """
    while True:
        try:
            suffix = f" [{default_val}]: " if default_val is not None else ": "
            user_input = input(f"\033[36m{prompt_text}\033[0m{suffix}").strip()
            
            if not user_input and default_val is not None:
                user_input = default_val

            result = validator_func(user_input)
            if result.is_valid:
                return result.cleaned_value
            else:
                print(f"  \033[31m[Validation Error] {result.error_message}\033[0m Try again.")
        except (KeyboardInterrupt, EOFError):
            print("\n  \033[33m[Notice] Input interrupted. Using default or returning.\033[0m")
            if default_val is not None:
                res = validator_func(default_val)
                if res.is_valid:
                    return res.cleaned_value
            raise


def prompt_menu_choice(prompt_text: str, valid_options: Set[str], default_val: Optional[str] = None) -> str:
    """Safely prompts user for menu selection from a set of choices."""
    valid_lower = {opt.lower(): opt for opt in valid_options}
    while True:
        try:
            suffix = f" [{default_val}]: " if default_val else ": "
            raw = input(f"\033[32m{prompt_text}\033[0m{suffix}").strip().lower()
            if not raw and default_val:
                raw = default_val.lower()
            if raw in valid_lower:
                return valid_lower[raw]
            print(f"  \033[31m[Input Error] Invalid choice '{raw}'. Choose from: {', '.join(valid_options)}\033[0m")
        except (KeyboardInterrupt, EOFError):
            print("\n  \033[33m[Notice] Operation cancelled.\033[0m")
            return default_val if default_val else list(valid_options)[0]
