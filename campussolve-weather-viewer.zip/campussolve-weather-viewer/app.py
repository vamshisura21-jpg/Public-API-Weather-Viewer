#!/usr/bin/env python3
"""
app.py - CampusSolve Project #111: Public API Weather Viewer
Dedicated Web Application Server providing static file serving and JSON API endpoints.
Uses Python Standard Library (http.server, json, os) - Zero external dependencies required.
"""

import http.server
import json
import os
import sys
import urllib.parse
from datetime import datetime

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from src.storage import LocalStorageManager
from src.analytics import WeatherAnalyticsEngine
from src.api_engine import PublicWeatherAPIClient
from src.exporter import MultiFormatExporter
from src.models import WeatherRecord

PORT = 8080
WEB_DIR = os.path.join(CURRENT_DIR, "web")
DATA_DIR = os.path.join(CURRENT_DIR, "data")
EXPORTS_DIR = os.path.join(CURRENT_DIR, "exports")

storage = LocalStorageManager(
    os.path.join(DATA_DIR, "weather_records.json"),
    os.path.join(DATA_DIR, "weather_records.csv")
)


class WeatherAPIHandler(http.server.SimpleHTTPRequestHandler):
    """Handles static web dashboard assets and REST API requests."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=WEB_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        # API Route: Get All Records
        if path == "/api/records":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            records, _ = storage.load_all_records()
            data = [r.to_dict() for r in records]
            self.wfile.write(json.dumps(data, indent=2).encode("utf-8"))
            return

        # API Route: Get Executive Summary
        elif path == "/api/summary":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            records, _ = storage.load_all_records()
            summary = WeatherAnalyticsEngine.generate_executive_summary(records)
            payload = summary.to_dict() if summary else {}
            self.wfile.write(json.dumps(payload, indent=2).encode("utf-8"))
            return

        # API Route: Live Weather Fetch for a City
        elif path == "/api/fetch":
            city = query.get("city", ["Tokyo"])[0]
            record, status_msg = PublicWeatherAPIClient.fetch_current_weather(city)
            storage.append_record(record)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            resp = {
                "record": record.to_dict(),
                "status_message": status_msg
            }
            self.wfile.write(json.dumps(resp, indent=2).encode("utf-8"))
            return

        # API Route: Multi-Format Export Trigger
        elif path == "/api/export":
            records, _ = storage.load_all_records()
            summary = WeatherAnalyticsEngine.generate_executive_summary(records)
            res = MultiFormatExporter.export_all_formats(records, summary, EXPORTS_DIR)

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(json.dumps(res, indent=2).encode("utf-8"))
            return

        # Fallback to static files in web/
        super().do_GET()


def run_server(port=PORT):
    server_address = ("", port)
    httpd = http.server.HTTPServer(server_address, WeatherAPIHandler)
    print("\n\033[1;36m╔══════════════════════════════════════════════════════════════════════════╗\033[0m")
    print(f"\033[1;36m║\033[0m   \033[1;32mCAMPUSSOLVE #111 : PUBLIC API WEATHER VIEWER WEB SERVER RUNNING\033[0m        \033[1;36m║\033[0m")
    print("\033[1;36m╠══════════════════════════════════════════════════════════════════════════╣\033[0m")
    print(f"\033[1;36m║\033[0m   Dashboard URL:  \033[1;37mhttp://localhost:{port}\033[0m                              \033[1;36m║\033[0m")
    print(f"\033[1;36m║\033[0m   API Endpoints:  \033[33m/api/records\033[0m, \033[33m/api/summary\033[0m, \033[33m/api/fetch\033[0m               \033[1;36m║\033[0m")
    print("\033[1;36m║\033[0m   Press Ctrl+C to terminate server safely.                               \033[1;36m║\033[0m")
    print("\033[1;36m╚══════════════════════════════════════════════════════════════════════════╝\033[0m\n")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\033[33m[Server] Shutting down cleanly.\033[0m")
        httpd.server_close()


if __name__ == "__main__":
    port_arg = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    run_server(port_arg)
