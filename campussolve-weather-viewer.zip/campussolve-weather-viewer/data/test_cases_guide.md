# Test Cases & Seed Dataset Guide: Public API Weather Viewer
**Project #111: CampusSolve**

This guide documents the 40 realistic seed entries included in `data/weather_records.json` and `data/weather_records.csv`.
The dataset demonstrates robust validation, anomaly detection, and statistical analysis across three distinct categories:

---

### Category A: Normal Meteorological Stations (Entries WTR-1001 to WTR-1020)
*Represents standard, nominal operational reporting across global metropolitan and regional hubs.*

| ID | Station City | Country | Temp (°C) | Humidity (%) | Wind (km/h) | Condition | Operational Profile |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `WTR-1001` | Tokyo | Japan | 18.5 | 58.0 | 12.4 | Mainly Clear | Nominal temperate autumn conditions |
| `WTR-1002` | London | UK | 11.2 | 82.0 | 21.0 | Slight Rain | Maritime damp front, light drizzle |
| `WTR-1003` | New York | USA | 14.8 | 52.0 | 15.6 | Clear Sky | High pressure system, sunny |
| `WTR-1004` | Paris | France | 13.0 | 74.0 | 11.8 | Partly Cloudy | Mild continental autumn weather |
| `WTR-1005` | Singapore | Singapore | 31.4 | 84.0 | 8.5 | Rain Showers | Tropical humid convection showers |
| `WTR-1006` | Sydney | Australia | 23.6 | 62.0 | 19.4 | Mainly Clear | Coastal onshore breeze |
| `WTR-1007` | Mumbai | India | 32.8 | 76.0 | 14.0 | Partly Cloudy | Coastal tropical warmth |
| `WTR-1008` | Berlin | Germany | 9.4 | 80.0 | 16.5 | Overcast | Low cloud deck, cool breeze |
| `WTR-1009` | Toronto | Canada | 6.8 | 68.0 | 22.0 | Partly Cloudy | Great Lakes seasonal chill |
| `WTR-1010` | Dubai | UAE | 34.0 | 45.0 | 18.2 | Clear Sky | Arid subtropical sunshine |
| `WTR-1011` | Cairo | Egypt | 27.5 | 38.0 | 15.0 | Clear Sky | Dry desert warmth |
| `WTR-1012` | Zurich | Switzerland | 8.1 | 85.0 | 10.5 | Slight Rain | Pre-alpine valley moisture |
| `WTR-1013` | Seoul | South Korea | 12.6 | 54.0 | 13.0 | Mainly Clear | Crisp continental autumn |
| `WTR-1014` | Bangkok | Thailand | 33.2 | 78.0 | 9.2 | Rain Showers | High heat index & monsoonal humidity |
| `WTR-1015` | San Francisco | USA | 16.2 | 75.0 | 24.5 | Foggy | Marine layer advection fog |
| `WTR-1016` | Rome | Italy | 19.8 | 60.0 | 11.0 | Mainly Clear | Mediterranean calm |
| `WTR-1017` | Madrid | Spain | 17.0 | 48.0 | 14.3 | Clear Sky | High plateau arid clarity |
| `WTR-1018` | Nairobi | Kenya | 24.0 | 55.0 | 16.0 | Partly Cloudy | Equatorial highland temperate |
| `WTR-1019` | Buenos Aires| Argentina | 22.4 | 65.0 | 17.5 | Mainly Clear | Southern hemisphere late spring |
| `WTR-1020` | Auckland | New Zealand | 18.0 | 72.0 | 26.0 | Overcast | Maritime oceanic flow |

---

### Category B: Boundary Value Test Cases (Entries WTR-1021 to WTR-1028)
*Tests physical and mathematical boundary conditions to ensure numerical stability and strict validation.*

| ID | Station City | Country | Boundary Condition Tested | Metric Value | Validator Verification |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `WTR-1021` | Helsinki | Finland | **Exact 0.0°C Freezing Point** | `0.0°C` | Confirms zero is non-negative float and triggers `Freezing Frost Risk` |
| `WTR-1022` | Bergen | Norway | **100.0% Relative Humidity** | `100.0%` | Upper physical saturation limit accepted without overflow |
| `WTR-1023` | Riyadh | Saudi Arabia | **Exact 0.0 mm Rainfall** | `0.0 mm` | Zero precipitation accurately preserved |
| `WTR-1024` | Quito | Ecuador | **Dead Calm Wind Speed** | `0.0 km/h` | Stationary air velocity without division-by-zero or negative errors |
| `WTR-1025` | Reykjavik | Iceland | **High Sub-Polar Latitude** | `64.1466°N` | Confirms northern coordinate parsing and sub-1000 hPa low pressure |
| `WTR-1026` | Denver | USA | **Low Elevation Barometric Pressure** | `845.0 hPa` | High altitude mountain pressure boundary |
| `WTR-1027` | Oslo | Norway | **Near-Freezing Transition** | `2.0°C` | Tests single-digit above-freezing status |
| `WTR-1028` | Chicago | USA | **Lakefront Wind Boundary** | `38.0 km/h` | Sustained high breeze right beneath warning threshold |

---

### Category C: Edge Conditions & Critical Limit Breaches (Entries WTR-1029 to WTR-1040)
*Triggers automated Threshold Warning flags and proves extreme meteorological anomaly tracking.*

| ID | Station City | Anomaly Type | Extreme Values | Automated Triggered Flags |
| :--- | :--- | :--- | :--- | :--- |
| `WTR-1029` | Yakutsk | Sub-Zero Siberian Freeze | `-28.5°C` (Feels like `-36.2°C`) | `CRITICAL: Sub-Zero Freeze (<=-10°C)` |
| `WTR-1030` | Death Valley | Extreme Desert Heatwave | `48.2°C`, `9.5%` Humidity | `CRITICAL: Extreme Heat Wave (>=40°C)`<br>`WARNING: Extreme Aridity Fire Risk (<=15%)` |
| `WTR-1031` | Cherrapunji | Torrential Downpour | `92.4 mm` Rain, `98%` Humidity | `CRITICAL: Torrential Downpour (>=50mm)` |
| `WTR-1032` | Wellington | Severe Gale Storm | `88.5 km/h` Wind | `CRITICAL: Severe Gale / Storm (>=80km/h)` |
| `WTR-1033` | Atacama | Hyper-Arid Fire Hazard | `8.0%` Humidity | `WARNING: Extreme Aridity Fire Risk (<=15%)` |
| `WTR-1034` | Key West | Hurricane Force Velocity | `105.0 km/h` Wind, `65 mm` Rain | `CRITICAL: Severe Gale / Storm (>=80km/h)`<br>`CRITICAL: Torrential Downpour (>=50mm)` |
| `WTR-1035` | Zermatt | High Alpine Blizzard | `-12.4°C`, `25 km/h` Wind | `CRITICAL: Sub-Zero Freeze (<=-10°C)` |
| `WTR-1036` | Kuwait City | Critical Heat Advisory | `46.8°C` (Feels like `49.2°C`) | `CRITICAL: Extreme Heat Wave (>=40°C)` |
| `WTR-1037` | Cape Town | Strong Coastal Trade Wind | `35.0 km/h` Wind | Elevated wind status |
| `WTR-1038` | Amsterdam | Continuous Maritime Rain | `3.8 mm` Rain, `88%` Humidity | Moderate damp precipitation |
| `WTR-1039` | Stockholm | Northern Chill | `3.8°C`, `16.0 km/h` Wind | Nominal Nordic baseline |
| `WTR-1040` | Mexico City | Subtropical Plateau | `22.0°C`, `1024 hPa` Pressure | High barometric baseline |
