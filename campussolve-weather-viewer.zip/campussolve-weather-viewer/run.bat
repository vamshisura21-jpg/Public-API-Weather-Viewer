@echo off
setlocal
title CampusSolve #111 - Public API Weather Viewer

:: Locate Working Python (prefer py launcher to bypass Windows Store dummy alias)
set "PY_CMD=py"
where %PY_CMD% >nul 2>nul
if %errorlevel% neq 0 (
    set "PY_CMD=C:\Users\harry\AppData\Local\Programs\Python\Python313\python.exe"
    if not exist "%PY_CMD%" (
        set "PY_CMD=python"
    )
)

:menu
cls
echo ==============================================================================
echo           CAMPUSSOLVE #111 : PUBLIC API WEATHER VIEWER & ANALYTICS
echo ==============================================================================
echo.
echo   [1] Launch Interactive Terminal Menu Application (CLI)
echo   [2] Launch Lightweight Graphical Interface (Tkinter Desktop GUI)
echo   [3] Launch Web Dashboard Server (http://localhost:8080)
echo   [4] Open Web Dashboard Directly in Browser (index.html)
echo   [5] Run Automated Unit & Integration Tests
echo   [6] Re-Generate Seed Dataset (40 Normal, Boundary, and Edge entries)
echo   [0] Exit
echo.
echo ==============================================================================
set /p choice="Enter option [0-6]: "

if "%choice%"=="1" (
    cls
    "%PY_CMD%" main.py
    pause
    goto menu
)
if "%choice%"=="2" (
    cls
    echo Launching Lightweight Desktop GUI (Tkinter)...
    start "" "%PY_CMD%" gui.py
    goto menu
)
if "%choice%"=="3" (
    cls
    echo Starting Web Dashboard on http://localhost:8080 ...
    start "" "http://localhost:8080"
    "%PY_CMD%" app.py
    pause
    goto menu
)
if "%choice%"=="4" (
    start "" "web\index.html"
    goto menu
)
if "%choice%"=="5" (
    cls
    "%PY_CMD%" tests\test_weather_viewer.py
    pause
    goto menu
)
if "%choice%"=="6" (
    cls
    "%PY_CMD%" generate_seed_data.py
    pause
    goto menu
)
if "%choice%"=="0" (
    exit /b 0
)

goto menu
