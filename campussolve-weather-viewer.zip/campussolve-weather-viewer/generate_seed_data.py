"""
generate_seed_data.py - Generates 40 realistic seed entries with normal, boundary, and edge conditions
"""

import json
import csv
import os

SEED_ENTRIES = [
    # Normal entries
    {"id": "WTR-1001", "city": "Tokyo", "country": "Japan", "latitude": 35.6762, "longitude": 139.6503,
     "temperature_c": 18.5, "apparent_temperature_c": 17.8, "humidity_pct": 58.0, "wind_speed_kmh": 12.4,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1014.2, "weather_code": 1, "condition_description": "Mainly Clear",
     "recorded_at": "2026-11-20T08:00:00", "data_source": "Open-Meteo Public API", "notes": "Nominal autumn morning"},
    {"id": "WTR-1002", "city": "London", "country": "United Kingdom", "latitude": 51.5074, "longitude": -0.1278,
     "temperature_c": 11.2, "apparent_temperature_c": 9.8, "humidity_pct": 82.0, "wind_speed_kmh": 21.0,
     "precipitation_mm": 2.4, "surface_pressure_hpa": 1008.5, "weather_code": 61, "condition_description": "Slight Rain",
     "recorded_at": "2026-11-20T08:15:00", "data_source": "Open-Meteo Public API", "notes": "Overcast with light drizzle"},
    {"id": "WTR-1003", "city": "New York", "country": "United States", "latitude": 40.7128, "longitude": -74.0060,
     "temperature_c": 14.8, "apparent_temperature_c": 13.9, "humidity_pct": 52.0, "wind_speed_kmh": 15.6,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1018.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T08:30:00", "data_source": "Open-Meteo Public API", "notes": "Clear conditions"},
    {"id": "WTR-1004", "city": "Paris", "country": "France", "latitude": 48.8566, "longitude": 2.3522,
     "temperature_c": 13.0, "apparent_temperature_c": 12.1, "humidity_pct": 74.0, "wind_speed_kmh": 11.8,
     "precipitation_mm": 0.2, "surface_pressure_hpa": 1016.3, "weather_code": 2, "condition_description": "Partly Cloudy",
     "recorded_at": "2026-11-20T08:45:00", "data_source": "Open-Meteo Public API", "notes": "Mild autumn weather"},
    {"id": "WTR-1005", "city": "Singapore", "country": "Singapore", "latitude": 1.3521, "longitude": 103.8198,
     "temperature_c": 31.4, "apparent_temperature_c": 37.8, "humidity_pct": 84.0, "wind_speed_kmh": 8.5,
     "precipitation_mm": 8.6, "surface_pressure_hpa": 1010.2, "weather_code": 80, "condition_description": "Slight Rain Showers",
     "recorded_at": "2026-11-20T09:00:00", "data_source": "Open-Meteo Public API", "notes": "Tropical afternoon shower"},
    {"id": "WTR-1006", "city": "Sydney", "country": "Australia", "latitude": -33.8688, "longitude": 151.2093,
     "temperature_c": 23.6, "apparent_temperature_c": 24.1, "humidity_pct": 62.0, "wind_speed_kmh": 19.4,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1020.1, "weather_code": 1, "condition_description": "Mainly Clear",
     "recorded_at": "2026-11-20T09:15:00", "data_source": "Open-Meteo Public API", "notes": "Pleasant coastal breeze"},
    {"id": "WTR-1007", "city": "Mumbai", "country": "India", "latitude": 19.0760, "longitude": 72.8777,
     "temperature_c": 32.8, "apparent_temperature_c": 38.2, "humidity_pct": 76.0, "wind_speed_kmh": 14.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1011.8, "weather_code": 2, "condition_description": "Partly Cloudy",
     "recorded_at": "2026-11-20T09:30:00", "data_source": "Open-Meteo Public API", "notes": "Warm coastal conditions"},
    {"id": "WTR-1008", "city": "Berlin", "country": "Germany", "latitude": 52.5200, "longitude": 13.4050,
     "temperature_c": 9.4, "apparent_temperature_c": 7.6, "humidity_pct": 80.0, "wind_speed_kmh": 16.5,
     "precipitation_mm": 1.1, "surface_pressure_hpa": 1012.4, "weather_code": 3, "condition_description": "Overcast",
     "recorded_at": "2026-11-20T09:45:00", "data_source": "Open-Meteo Public API", "notes": "Brisk cloud cover"},
    {"id": "WTR-1009", "city": "Toronto", "country": "Canada", "latitude": 43.6532, "longitude": -79.3832,
     "temperature_c": 6.8, "apparent_temperature_c": 3.9, "humidity_pct": 68.0, "wind_speed_kmh": 22.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1017.5, "weather_code": 2, "condition_description": "Partly Cloudy",
     "recorded_at": "2026-11-20T10:00:00", "data_source": "Open-Meteo Public API", "notes": "Crisp temperate lake breeze"},
    {"id": "WTR-1010", "city": "Dubai", "country": "United Arab Emirates", "latitude": 25.2048, "longitude": 55.2708,
     "temperature_c": 34.0, "apparent_temperature_c": 36.2, "humidity_pct": 45.0, "wind_speed_kmh": 18.2,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1013.9, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T10:15:00", "data_source": "Open-Meteo Public API", "notes": "Sunny desert heat"},
    {"id": "WTR-1011", "city": "Cairo", "country": "Egypt", "latitude": 30.0444, "longitude": 31.2357,
     "temperature_c": 27.5, "apparent_temperature_c": 27.0, "humidity_pct": 38.0, "wind_speed_kmh": 15.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1015.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T10:30:00", "data_source": "Open-Meteo Public API", "notes": "Warm dry midday"},
    {"id": "WTR-1012", "city": "Zurich", "country": "Switzerland", "latitude": 47.3769, "longitude": 8.5417,
     "temperature_c": 8.1, "apparent_temperature_c": 6.2, "humidity_pct": 85.0, "wind_speed_kmh": 10.5,
     "precipitation_mm": 3.2, "surface_pressure_hpa": 1016.8, "weather_code": 61, "condition_description": "Slight Rain",
     "recorded_at": "2026-11-20T10:45:00", "data_source": "Open-Meteo Public API", "notes": "Alpine valley drizzle"},
    {"id": "WTR-1013", "city": "Seoul", "country": "South Korea", "latitude": 37.5665, "longitude": 126.9780,
     "temperature_c": 12.6, "apparent_temperature_c": 11.8, "humidity_pct": 54.0, "wind_speed_kmh": 13.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1021.5, "weather_code": 1, "condition_description": "Mainly Clear",
     "recorded_at": "2026-11-20T11:00:00", "data_source": "Open-Meteo Public API", "notes": "Clear autumnal high pressure"},
    {"id": "WTR-1014", "city": "Bangkok", "country": "Thailand", "latitude": 13.7563, "longitude": 100.5018,
     "temperature_c": 33.2, "apparent_temperature_c": 39.5, "humidity_pct": 78.0, "wind_speed_kmh": 9.2,
     "precipitation_mm": 4.5, "surface_pressure_hpa": 1009.4, "weather_code": 80, "condition_description": "Slight Rain Showers",
     "recorded_at": "2026-11-20T11:15:00", "data_source": "Open-Meteo Public API", "notes": "Warm tropical humidity"},
    {"id": "WTR-1015", "city": "San Francisco", "country": "United States", "latitude": 37.7749, "longitude": -122.4194,
     "temperature_c": 16.2, "apparent_temperature_c": 15.5, "humidity_pct": 75.0, "wind_speed_kmh": 24.5,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1019.2, "weather_code": 45, "condition_description": "Foggy",
     "recorded_at": "2026-11-20T11:30:00", "data_source": "Open-Meteo Public API", "notes": "Coastal marine layer fog"},
    {"id": "WTR-1016", "city": "Rome", "country": "Italy", "latitude": 41.9028, "longitude": 12.4964,
     "temperature_c": 19.8, "apparent_temperature_c": 19.5, "humidity_pct": 60.0, "wind_speed_kmh": 11.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1015.7, "weather_code": 1, "condition_description": "Mainly Clear",
     "recorded_at": "2026-11-20T11:45:00", "data_source": "Open-Meteo Public API", "notes": "Mild Mediterranean weather"},
    {"id": "WTR-1017", "city": "Madrid", "country": "Spain", "latitude": 40.4168, "longitude": -3.7038,
     "temperature_c": 17.0, "apparent_temperature_c": 16.2, "humidity_pct": 48.0, "wind_speed_kmh": 14.3,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1018.4, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T12:00:00", "data_source": "Open-Meteo Public API", "notes": "Sunny plateau conditions"},
    {"id": "WTR-1018", "city": "Nairobi", "country": "Kenya", "latitude": -1.2921, "longitude": 36.8219,
     "temperature_c": 24.0, "apparent_temperature_c": 24.0, "humidity_pct": 55.0, "wind_speed_kmh": 16.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1014.0, "weather_code": 2, "condition_description": "Partly Cloudy",
     "recorded_at": "2026-11-20T12:15:00", "data_source": "Open-Meteo Public API", "notes": "Highland tropical temperate"},
    {"id": "WTR-1019", "city": "Buenos Aires", "country": "Argentina", "latitude": -34.6037, "longitude": -58.3816,
     "temperature_c": 22.4, "apparent_temperature_c": 22.8, "humidity_pct": 65.0, "wind_speed_kmh": 17.5,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1016.0, "weather_code": 1, "condition_description": "Mainly Clear",
     "recorded_at": "2026-11-20T12:30:00", "data_source": "Open-Meteo Public API", "notes": "Late spring warmth"},
    {"id": "WTR-1020", "city": "Auckland", "country": "New Zealand", "latitude": -36.8485, "longitude": 174.7633,
     "temperature_c": 18.0, "apparent_temperature_c": 17.2, "humidity_pct": 72.0, "wind_speed_kmh": 26.0,
     "precipitation_mm": 1.5, "surface_pressure_hpa": 1011.0, "weather_code": 3, "condition_description": "Overcast",
     "recorded_at": "2026-11-20T12:45:00", "data_source": "Open-Meteo Public API", "notes": "Maritime cloudy front"},

    # Boundary Value test cases
    {"id": "WTR-1021", "city": "Helsinki", "country": "Finland", "latitude": 60.1699, "longitude": 24.9384,
     "temperature_c": 0.0, "apparent_temperature_c": -3.5, "humidity_pct": 88.0, "wind_speed_kmh": 14.0,
     "precipitation_mm": 0.5, "surface_pressure_hpa": 1013.25, "weather_code": 71, "condition_description": "Slight Snow Fall",
     "recorded_at": "2026-11-20T13:00:00", "data_source": "Stored Benchmark", "notes": "Boundary test: exact 0.0°C freeze threshold"},
    {"id": "WTR-1022", "city": "Bergen", "country": "Norway", "latitude": 60.3913, "longitude": 5.3221,
     "temperature_c": 7.4, "apparent_temperature_c": 5.1, "humidity_pct": 100.0, "wind_speed_kmh": 28.0,
     "precipitation_mm": 18.5, "surface_pressure_hpa": 1002.0, "weather_code": 63, "condition_description": "Moderate Rain",
     "recorded_at": "2026-11-20T13:15:00", "data_source": "Stored Benchmark", "notes": "Boundary test: 100.0% saturated humidity"},
    {"id": "WTR-1023", "city": "Riyadh", "country": "Saudi Arabia", "latitude": 24.7136, "longitude": 46.6753,
     "temperature_c": 29.0, "apparent_temperature_c": 27.5, "humidity_pct": 18.0, "wind_speed_kmh": 12.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1017.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T13:30:00", "data_source": "Stored Benchmark", "notes": "Boundary test: exact 0.0 mm rain with low humidity"},
    {"id": "WTR-1024", "city": "Quito", "country": "Ecuador", "latitude": -0.1807, "longitude": -78.4678,
     "temperature_c": 16.0, "apparent_temperature_c": 16.0, "humidity_pct": 60.0, "wind_speed_kmh": 0.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1013.25, "weather_code": 1, "condition_description": "Mainly Clear",
     "recorded_at": "2026-11-20T13:45:00", "data_source": "Stored Benchmark", "notes": "Boundary test: exact 0.0 km/h dead calm wind"},
    {"id": "WTR-1025", "city": "Reykjavik", "country": "Iceland", "latitude": 64.1466, "longitude": -21.9426,
     "temperature_c": 1.2, "apparent_temperature_c": -3.8, "humidity_pct": 79.0, "wind_speed_kmh": 32.0,
     "precipitation_mm": 0.8, "surface_pressure_hpa": 994.0, "weather_code": 3, "condition_description": "Overcast",
     "recorded_at": "2026-11-20T14:00:00", "data_source": "Stored Benchmark", "notes": "Boundary test: high latitude sub-polar station"},
    {"id": "WTR-1026", "city": "Denver", "country": "United States", "latitude": 39.7392, "longitude": -104.9903,
     "temperature_c": 11.5, "apparent_temperature_c": 10.2, "humidity_pct": 32.0, "wind_speed_kmh": 18.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 845.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T14:15:00", "data_source": "Stored Benchmark", "notes": "Boundary test: high elevation low barometric pressure"},
    {"id": "WTR-1027", "city": "Oslo", "country": "Norway", "latitude": 59.9139, "longitude": 10.7522,
     "temperature_c": 2.0, "apparent_temperature_c": -1.2, "humidity_pct": 78.0, "wind_speed_kmh": 15.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1019.0, "weather_code": 2, "condition_description": "Partly Cloudy",
     "recorded_at": "2026-11-20T14:30:00", "data_source": "Stored Benchmark", "notes": "Near-freezing northern boundary"},
    {"id": "WTR-1028", "city": "Chicago", "country": "United States", "latitude": 41.8781, "longitude": -87.6298,
     "temperature_c": 8.0, "apparent_temperature_c": 3.8, "humidity_pct": 64.0, "wind_speed_kmh": 38.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1012.0, "weather_code": 2, "condition_description": "Partly Cloudy",
     "recorded_at": "2026-11-20T14:45:00", "data_source": "Stored Benchmark", "notes": "Windy city coastal threshold test"},

    # Edge Condition & Extreme Limit Breaches (Threshold Warnings)
    {"id": "WTR-1029", "city": "Yakutsk", "country": "Russia", "latitude": 62.0355, "longitude": 129.6755,
     "temperature_c": -28.5, "apparent_temperature_c": -36.2, "humidity_pct": 82.0, "wind_speed_kmh": 12.0,
     "precipitation_mm": 1.2, "surface_pressure_hpa": 1028.0, "weather_code": 75, "condition_description": "Heavy Snow Fall",
     "recorded_at": "2026-11-20T15:00:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: extreme sub-zero Siberian frost"},
    {"id": "WTR-1030", "city": "Death Valley", "country": "United States", "latitude": 36.5323, "longitude": -116.9325,
     "temperature_c": 48.2, "apparent_temperature_c": 46.5, "humidity_pct": 9.5, "wind_speed_kmh": 22.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1011.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T15:15:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: extreme heatwave and severe aridity"},
    {"id": "WTR-1031", "city": "Cherrapunji", "country": "India", "latitude": 25.2744, "longitude": 91.7323,
     "temperature_c": 21.0, "apparent_temperature_c": 23.5, "humidity_pct": 98.0, "wind_speed_kmh": 34.0,
     "precipitation_mm": 92.4, "surface_pressure_hpa": 998.0, "weather_code": 65, "condition_description": "Heavy Rain",
     "recorded_at": "2026-11-20T15:30:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: torrential downpour flood alert"},
    {"id": "WTR-1032", "city": "Wellington", "country": "New Zealand", "latitude": -41.2865, "longitude": 174.7762,
     "temperature_c": 15.0, "apparent_temperature_c": 11.2, "humidity_pct": 84.0, "wind_speed_kmh": 88.5,
     "precipitation_mm": 12.0, "surface_pressure_hpa": 990.2, "weather_code": 82, "condition_description": "Violent Rain Showers",
     "recorded_at": "2026-11-20T15:45:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: severe gale storm wind alert"},
    {"id": "WTR-1033", "city": "Atacama", "country": "Chile", "latitude": -23.8634, "longitude": -69.1328,
     "temperature_c": 26.0, "apparent_temperature_c": 24.0, "humidity_pct": 8.0, "wind_speed_kmh": 16.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1018.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T16:00:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: extreme dryness fire hazard"},
    {"id": "WTR-1034", "city": "Key West", "country": "United States", "latitude": 24.5551, "longitude": -81.7800,
     "temperature_c": 28.5, "apparent_temperature_c": 33.2, "humidity_pct": 92.0, "wind_speed_kmh": 105.0,
     "precipitation_mm": 65.0, "surface_pressure_hpa": 978.0, "weather_code": 99, "condition_description": "Thunderstorm with Heavy Hail",
     "recorded_at": "2026-11-20T16:15:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: hurricane wind and severe storm"},
    {"id": "WTR-1035", "city": "Zermatt", "country": "Switzerland", "latitude": 45.9765, "longitude": 7.7491,
     "temperature_c": -12.4, "apparent_temperature_c": -19.5, "humidity_pct": 74.0, "wind_speed_kmh": 25.0,
     "precipitation_mm": 6.8, "surface_pressure_hpa": 985.0, "weather_code": 73, "condition_description": "Moderate Snow Fall",
     "recorded_at": "2026-11-20T16:30:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: sub-zero alpine blizzard"},
    {"id": "WTR-1036", "city": "Kuwait City", "country": "Kuwait", "latitude": 29.3759, "longitude": 47.9774,
     "temperature_c": 46.8, "apparent_temperature_c": 49.2, "humidity_pct": 22.0, "wind_speed_kmh": 28.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1006.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T16:45:00", "data_source": "Extreme Weather Station", "notes": "Edge condition: extreme heat advisory"},
    {"id": "WTR-1037", "city": "Cape Town", "country": "South Africa", "latitude": -33.9249, "longitude": 18.4241,
     "temperature_c": 21.5, "apparent_temperature_c": 21.0, "humidity_pct": 68.0, "wind_speed_kmh": 35.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1017.0, "weather_code": 1, "condition_description": "Mainly Clear",
     "recorded_at": "2026-11-20T17:00:00", "data_source": "Stored Benchmark", "notes": "Cape Doctor trade winds"},
    {"id": "WTR-1038", "city": "Amsterdam", "country": "Netherlands", "latitude": 52.3676, "longitude": 4.9041,
     "temperature_c": 10.5, "apparent_temperature_c": 8.0, "humidity_pct": 88.0, "wind_speed_kmh": 26.0,
     "precipitation_mm": 3.8, "surface_pressure_hpa": 1009.0, "weather_code": 61, "condition_description": "Slight Rain",
     "recorded_at": "2026-11-20T17:15:00", "data_source": "Stored Benchmark", "notes": "Typical Dutch maritime drizzle"},
    {"id": "WTR-1039", "city": "Stockholm", "country": "Sweden", "latitude": 59.3293, "longitude": 18.0686,
     "temperature_c": 3.8, "apparent_temperature_c": 1.2, "humidity_pct": 75.0, "wind_speed_kmh": 16.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1018.0, "weather_code": 2, "condition_description": "Partly Cloudy",
     "recorded_at": "2026-11-20T17:30:00", "data_source": "Stored Benchmark", "notes": "Nordic late autumn chill"},
    {"id": "WTR-1040", "city": "Mexico City", "country": "Mexico", "latitude": 19.4326, "longitude": -99.1332,
     "temperature_c": 22.0, "apparent_temperature_c": 21.4, "humidity_pct": 46.0, "wind_speed_kmh": 12.0,
     "precipitation_mm": 0.0, "surface_pressure_hpa": 1024.0, "weather_code": 0, "condition_description": "Clear Sky",
     "recorded_at": "2026-11-20T17:45:00", "data_source": "Stored Benchmark", "notes": "Subtropical highland plateau"}
]

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
WEB_DIR = os.path.join(BASE_DIR, "web")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(WEB_DIR, exist_ok=True)

# Write JSON
json_path = os.path.join(DATA_DIR, "weather_records.json")
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(SEED_ENTRIES, f, indent=2, ensure_ascii=False)
print(f"Generated {len(SEED_ENTRIES)} JSON entries at {json_path}")

# Write CSV
csv_path = os.path.join(DATA_DIR, "weather_records.csv")
fieldnames = list(SEED_ENTRIES[0].keys())
with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(SEED_ENTRIES)
print(f"Generated {len(SEED_ENTRIES)} CSV entries at {csv_path}")

# Also copy to web/sample_data.json for instant offline website load
web_json_path = os.path.join(WEB_DIR, "sample_data.json")
with open(web_json_path, "w", encoding="utf-8") as f:
    json.dump(SEED_ENTRIES, f, indent=2, ensure_ascii=False)
print(f"Saved web seed dataset at {web_json_path}")
