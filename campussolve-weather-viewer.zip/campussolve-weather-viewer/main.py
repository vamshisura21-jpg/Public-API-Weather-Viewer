#!/usr/bin/env python3
"""
main.py - CampusSolve Project #111: Public API Weather Viewer
Interactive Menu-Driven Terminal Application with Defensive Validation,
Public API Integration, Local Persistence, Analytics, and Visual Plotting.
"""

import os
import sys
import time
from typing import List

# Add parent directory to path so imports work smoothly
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from src.models import WeatherRecord
from src.validator import DefensiveValidator, prompt_with_validation, prompt_menu_choice
from src.api_engine import PublicWeatherAPIClient
from src.storage import LocalStorageManager
from src.analytics import WeatherAnalyticsEngine
from src.visualizer import VisualDataPlotter
from src.exporter import MultiFormatExporter
from src.importer import BulkDatasetImporter

# ANSI Color Codes for Professional Terminal UI
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"
BG_BLUE = "\033[44m"


class WeatherViewerApp:
    """Orchestrates interactive menu loop, backend handlers, and presentation views."""

    def __init__(self):
        self.data_dir = os.path.join(CURRENT_DIR, "data")
        self.exports_dir = os.path.join(CURRENT_DIR, "exports")
        self.json_path = os.path.join(self.data_dir, "weather_records.json")
        self.csv_path = os.path.join(self.data_dir, "weather_records.csv")
        
        self.storage = LocalStorageManager(self.json_path, self.csv_path)
        records, warning = self.storage.load_all_records()
        self.records: List[WeatherRecord] = records
        self.init_warning = warning

    def print_banner(self) -> None:
        """Displays stylized, branded application welcome header."""
        print(f"\n{BOLD}{CYAN}╔══════════════════════════════════════════════════════════════════════════════╗{RESET}")
        print(f"{BOLD}{CYAN}║{RESET}         {BOLD}{WHITE}CAMPUSSOLVE #111 : PUBLIC API WEATHER VIEWER & ANALYTICS{RESET}             {BOLD}{CYAN}║{RESET}")
        print(f"{BOLD}{CYAN}║{RESET}   {DIM}Domain: AI, APIs & Smart Applications | Automated Persistence & Reporting{RESET}  {BOLD}{CYAN}║{RESET}")
        print(f"{BOLD}{CYAN}╚══════════════════════════════════════════════════════════════════════════════╝{RESET}")
        if self.init_warning:
            print(f" {YELLOW}[Notice] {self.init_warning}{RESET}")
        print(f" {GREEN}●{RESET} Persistent Storage Active: {BOLD}{len(self.records)}{RESET} records loaded | JSON & CSV synchronized.\n")

    def run(self) -> None:
        """Main application lifecycle and navigation dispatch loop."""
        self.print_banner()

        while True:
            self.display_menu()
            choice = input(f"\n{BOLD}{CYAN}Enter Menu Selection [0-10]:{RESET} ").strip()

            if choice == "1":
                self.handle_fetch_weather()
            elif choice == "2":
                self.handle_view_records()
            elif choice == "3":
                self.handle_query_search()
            elif choice == "4":
                self.handle_executive_summary()
            elif choice == "5":
                self.handle_visual_plotting()
            elif choice == "6":
                self.handle_multi_format_export()
            elif choice == "7":
                self.handle_bulk_import()
            elif choice == "8":
                self.handle_delete_record()
            elif choice == "9":
                self.handle_launch_tkinter_gui()
            elif choice == "10":
                self.handle_launch_web_dashboard()
            elif choice == "0" or choice.lower() in ["exit", "q", "quit"]:
                self.handle_exit()
                break
            else:
                print(f" {RED}[Invalid Option] Please enter a valid number from 0 to 10.{RESET}")

    def display_menu(self) -> None:
        """Renders main command menu with clear visual categories."""
        print(f"{BOLD}{WHITE}─────────────── PRIMARY NAVIGATION DISPATCH ───────────────{RESET}")
        print(f"  {BOLD}{GREEN}[1]{RESET} Fetch & Record Weather from Public API (Open-Meteo)")
        print(f"  {BOLD}{GREEN}[2]{RESET} View Stored Weather Records (Tabular & Paginated)")
        print(f"  {BOLD}{GREEN}[3]{RESET} Record Query & Multi-Dimensional Search")
        print(f"  {BOLD}{GREEN}[4]{RESET} Executive Summary Generation & Trend Insights")
        print(f"  {BOLD}{GREEN}[5]{RESET} Visual Data Plotting (Matplotlib Charts + Terminal)")
        print(f"  {BOLD}{GREEN}[6]{RESET} Multi-Format Summary Export (Markdown / Audit Log / CSV)")
        print(f"  {BOLD}{GREEN}[7]{RESET} Bulk Dataset Import (Legacy CSV with Row Error Logs)")
        print(f"  {BOLD}{GREEN}[8]{RESET} Delete Stored Record by ID")
        print(f"  {BOLD}{CYAN}[9]{RESET} Launch Lightweight Graphical Interface (Tkinter GUI)")
        print(f"  {BOLD}{CYAN}[10]{RESET} Launch Web Dashboard Website (Local Server)")
        print(f"  {BOLD}{RED}[0]{RESET} Exit Program (Preserve & Sync State)")
        print(f"{BOLD}{WHITE}────────────────────────────────────────────────────────────{RESET}")

    def handle_fetch_weather(self) -> None:
        """Workflow 1: Fetches live/mock weather with defensive input sanitization."""
        print(f"\n{BOLD}{BLUE}--- [FETCH WEATHER FROM PUBLIC API] ---{RESET}")
        print(f" {DIM}Enter a city name. Defensive validation sanitizes and validates real-time.{RESET}")

        city_name = prompt_with_validation(
            "Enter City Name (e.g. London, Tokyo, San Francisco)",
            DefensiveValidator.validate_city_name
        )

        print(f"\n {YELLOW}⚡ Querying Open-Meteo Public API for '{city_name}'...{RESET}")
        record, status_msg = PublicWeatherAPIClient.fetch_current_weather(city_name)
        print(f" {GREEN}✔ {status_msg}{RESET}")

        # Display key values in a clean formatted card
        self.print_single_record_card(record)

        # Allow user to add optional observation notes
        optional_notes = input(f" {CYAN}Add optional observation notes (or press Enter to skip):{RESET} ").strip()
        if optional_notes:
            record.notes = optional_notes

        # Persist record
        saved = self.storage.append_record(record)
        if saved:
            self.records.append(record)
            print(f" {GREEN}✔ Record successfully saved to JSON & CSV persistence.{RESET} ID: {BOLD}{record.id}{RESET}")
        else:
            print(f" {RED}✘ Failed to persist record locally.{RESET}")

    def print_single_record_card(self, r: WeatherRecord) -> None:
        """Prints a structured card displaying all key meteorological values."""
        temp_color = RED if r.temperature_c >= 35.0 else (BLUE if r.temperature_c <= 0.0 else GREEN)
        print(f"\n{BOLD}{WHITE}┌──────────────────────────────────────────────────────────────┐{RESET}")
        print(f"{BOLD}{WHITE}│{RESET}  {BOLD}{WHITE}METEOROLOGICAL OBSERVATION CARD : {r.city.upper()}, {r.country.upper()}{RESET}")
        print(f"{BOLD}{WHITE}├──────────────────────────────────────────────────────────────┤{RESET}")
        print(f"{BOLD}{WHITE}│{RESET}  Record ID:             {BOLD}{r.id}{RESET}")
        print(f"{BOLD}{WHITE}│{RESET}  Coordinates:           {r.latitude:.4f}°, {r.longitude:.4f}°")
        print(f"{BOLD}{WHITE}│{RESET}  Temperature:           {temp_color}{BOLD}{r.temperature_c}°C{RESET} ({r.temperature_f}°F)")
        print(f"{BOLD}{WHITE}│{RESET}  Apparent Feel:         {r.apparent_temperature_c}°C")
        print(f"{BOLD}{WHITE}│{RESET}  Condition:             {BOLD}{YELLOW}{r.condition_description}{RESET} (WMO Code {r.weather_code})")
        print(f"{BOLD}{WHITE}│{RESET}  Relative Humidity:     {r.humidity_pct}%")
        print(f"{BOLD}{WHITE}│{RESET}  Wind Speed:            {r.wind_speed_kmh} km/h ({r.wind_speed_mph} mph)")
        print(f"{BOLD}{WHITE}│{RESET}  Precipitation:         {r.precipitation_mm} mm")
        print(f"{BOLD}{WHITE}│{RESET}  Surface Pressure:      {r.surface_pressure_hpa} hPa")
        print(f"{BOLD}{WHITE}│{RESET}  Timestamp:             {r.recorded_at}")
        print(f"{BOLD}{WHITE}│{RESET}  Data Source:           {CYAN}{r.data_source}{RESET}")
        
        # Display threshold warning indicators
        print(f"{BOLD}{WHITE}├──────────────────────────────────────────────────────────────┤{RESET}")
        print(f"{BOLD}{WHITE}│{RESET}  {BOLD}Threshold Warning Indicators:{RESET}")
        for flag in r.status_indicators:
            flag_color = RED if flag.startswith("CRITICAL:") else (YELLOW if flag.startswith("WARNING:") else GREEN)
            print(f"{BOLD}{WHITE}│{RESET}    {flag_color}● {flag}{RESET}")
        print(f"{BOLD}{WHITE}└──────────────────────────────────────────────────────────────┘{RESET}\n")

    def handle_view_records(self, custom_list: List[WeatherRecord] = None) -> None:
        """Workflow 2: Displays formatted records table with pagination breaks."""
        dataset = custom_list if custom_list is not None else self.records
        if not dataset:
            print(f"\n {YELLOW}[Empty Dataset] No weather records stored yet. Fetch or import data first.{RESET}\n")
            return

        print(f"\n{BOLD}{WHITE}=== STORED WEATHER RECORDS ({len(dataset)} Total) ==={RESET}")
        page_size = 10
        total_pages = (len(dataset) + page_size - 1) // page_size
        current_page = 0

        while True:
            start_idx = current_page * page_size
            end_idx = min(start_idx + page_size, len(dataset))
            page_slice = dataset[start_idx:end_idx]

            self._render_table_header()
            for r in page_slice:
                self._render_table_row(r)
            self._render_table_footer()

            print(f" {DIM}Page {current_page + 1} of {total_pages} (Displaying records {start_idx + 1}-{end_idx} of {len(dataset)}){RESET}")

            if total_pages <= 1:
                break

            prompt_nav = f" [N]ext Page | [P]rev Page | [Q]uit to Menu: "
            cmd = input(f"{CYAN}{prompt_nav}{RESET}").strip().lower()
            if cmd == "n":
                if current_page + 1 < total_pages:
                    current_page += 1
                else:
                    print(f" {YELLOW}Already at final page.{RESET}")
            elif cmd == "p":
                if current_page > 0:
                    current_page -= 1
                else:
                    print(f" {YELLOW}Already at first page.{RESET}")
            elif cmd in ["q", "quit", ""]:
                break

    def _render_table_header(self) -> None:
        print("+" + "-"*11 + "+" + "-"*16 + "+" + "-"*15 + "+" + "-"*9 + "+" + "-"*10 + "+" + "-"*12 + "+" + "-"*18 + "+" + "-"*12 + "+")
        print(f"| {'ID':<9} | {'City':<14} | {'Country':<13} | {'Temp':<7} | {'Humidity':<8} | {'Wind':<10} | {'Condition':<16} | {'Status':<10} |")
        print("+" + "="*11 + "+" + "="*16 + "+" + "="*15 + "+" + "="*9 + "+" + "="*10 + "+" + "="*12 + "+" + "="*18 + "+" + "="*12 + "+")

    def _render_table_row(self, r: WeatherRecord) -> None:
        t_str = f"{r.temperature_c:>4.1f}°C"
        h_str = f"{r.humidity_pct:>5.1f}%"
        w_str = f"{r.wind_speed_kmh:>5.1f}km/h"
        
        status_text = "CRIT" if r.has_critical_alert else ("WARN" if r.has_warning else "OK")
        status_color = RED if r.has_critical_alert else (YELLOW if r.has_warning else GREEN)
        
        print(f"| {r.id[:9]:<9} | {r.city[:14]:<14} | {r.country[:13]:<13} | {t_str:<7} | {h_str:<8} | {w_str:<10} | {r.condition_description[:16]:<16} | {status_color}{status_text:<10}{RESET} |")

    def _render_table_footer(self) -> None:
        print("+" + "-"*11 + "+" + "-"*16 + "+" + "-"*15 + "+" + "-"*9 + "+" + "-"*10 + "+" + "-"*12 + "+" + "-"*18 + "+" + "-"*12 + "+")

    def handle_query_search(self) -> None:
        """Workflow 3: Keyword and category-based filtering tools."""
        print(f"\n{BOLD}{BLUE}--- [RECORD QUERY & MULTI-DIMENSIONAL SEARCH] ---{RESET}")
        print(" Filter criteria (press Enter on any prompt to leave unconstrained):")

        # Keyword
        raw_kw = input(f" {CYAN}Keyword search (City, Country, Notes):{RESET} ").strip()
        keyword = raw_kw if raw_kw else None

        # Condition category
        raw_cond = input(f" {CYAN}Condition category (e.g. Clear, Rain, Snow, Overcast):{RESET} ").strip()
        condition = raw_cond if raw_cond else None

        # Min Temp
        raw_min = input(f" {CYAN}Minimum temperature °C (optional):{RESET} ").strip()
        min_temp = None
        if raw_min:
            t_res = DefensiveValidator.validate_temperature(raw_min)
            if t_res.is_valid:
                min_temp = t_res.cleaned_value

        # Max Temp
        raw_max = input(f" {CYAN}Maximum temperature °C (optional):{RESET} ").strip()
        max_temp = None
        if raw_max:
            t_res = DefensiveValidator.validate_temperature(raw_max)
            if t_res.is_valid:
                max_temp = t_res.cleaned_value

        # Alerts only
        raw_alert = input(f" {CYAN}Filter to warning/critical alerts only? [y/N]:{RESET} ").strip().lower()
        alerts_only = raw_alert in ["y", "yes"]

        # Run query
        results = WeatherAnalyticsEngine.filter_records(
            self.records,
            keyword=keyword,
            condition_filter=condition,
            min_temp=min_temp,
            max_temp=max_temp,
            alerts_only=alerts_only
        )

        print(f"\n {GREEN}✔ Found {len(results)} matching records.{RESET}")
        if results:
            self.handle_view_records(custom_list=results)

    def handle_executive_summary(self) -> None:
        """Workflow 4: Generates totals, averages, status indicators, and trends."""
        summary = WeatherAnalyticsEngine.generate_executive_summary(self.records)
        if not summary:
            print(f"\n {YELLOW}[Notice] Cannot generate summary on empty dataset.{RESET}\n")
            return

        insights = WeatherAnalyticsEngine.compute_trend_insights(self.records)

        print(f"\n{BOLD}{WHITE}╔══════════════════════════════════════════════════════════════════════════════╗{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}                 {BOLD}{YELLOW}EXECUTIVE METEOROLOGICAL SUMMARY & TRENDS{RESET}                    {BOLD}{WHITE}║{RESET}")
        print(f"{BOLD}{WHITE}╠══════════════════════════════════════════════════════════════════════════════╣{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}  Total Monitored Stations:        {BOLD}{summary.total_records}{RESET} locations")
        print(f"{BOLD}{WHITE}║{RESET}  Average Temperature:             {BOLD}{summary.avg_temperature_c}°C{RESET} ({round(summary.avg_temperature_c * 9/5 + 32, 1)}°F)")
        print(f"{BOLD}{WHITE}║{RESET}  Thermal Extremes:                Min: {BLUE}{summary.min_temperature_c}°C{RESET} | Max: {RED}{summary.max_temperature_c}°C{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}  Median Temperature:              {summary.median_temperature_c}°C")
        print(f"{BOLD}{WHITE}║{RESET}  Mean Relative Humidity:          {summary.avg_humidity_pct}%")
        print(f"{BOLD}{WHITE}║{RESET}  Average Wind Velocity:           {summary.avg_wind_speed_kmh} km/h (Peak: {summary.max_wind_speed_kmh} km/h)")
        print(f"{BOLD}{WHITE}║{RESET}  Cumulative Precipitation:        {summary.total_precipitation_mm} mm (Max: {summary.max_precipitation_mm} mm)")
        print(f"{BOLD}{WHITE}║{RESET}  Mean Barometric Pressure:        {summary.avg_pressure_hpa} hPa")
        print(f"{BOLD}{WHITE}╠══════════════════════════════════════════════════════════════════════════════╣{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}  {BOLD}Operational Status Breakdown:{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}    {RED}● Critical Limit Breaches:{RESET}    {BOLD}{summary.critical_alerts_count}{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}    {YELLOW}● Warning Advisories:{RESET}         {BOLD}{summary.warning_alerts_count}{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}    {RED}● Overdue Deadlines:{RESET}          {BOLD}{summary.overdue_deadlines_count}{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}    {GREEN}● Nominal Operations:{RESET}         {BOLD}{summary.nominal_count}{RESET}")
        print(f"{BOLD}{WHITE}╠══════════════════════════════════════════════════════════════════════════════╣{RESET}")
        print(f"{BOLD}{WHITE}║{RESET}  {BOLD}Key Weather Trends & Observations:{RESET}")
        for ins in insights:
            print(f"{BOLD}{WHITE}║{RESET}    {CYAN}▸{RESET} {ins}")
        print(f"{BOLD}{WHITE}╚══════════════════════════════════════════════════════════════════════════════╝{RESET}\n")

    def handle_visual_plotting(self) -> None:
        """Workflow 5: Matplotlib integration generating trend charts & terminal distributions."""
        summary = WeatherAnalyticsEngine.generate_executive_summary(self.records)
        if not summary:
            print(f"\n {YELLOW}[Notice] Please load or fetch records before plotting.{RESET}\n")
            return

        # 1. Render in-terminal ASCII chart
        VisualDataPlotter.display_terminal_ascii_chart(self.records)

        # 2. Export visual chart files (Matplotlib PNG + Vector SVG)
        png_path = os.path.join(self.exports_dir, "weather_trend_chart.png")
        svg_path = os.path.join(self.exports_dir, "weather_trend_chart.svg")

        print(f" {YELLOW}⚡ Rendering graphical visual charts...{RESET}")
        results = VisualDataPlotter.plot_and_export(self.records, summary, png_path, svg_path)

        if "png" in results:
            print(f" {GREEN}✔ Matplotlib PNG Chart generated:{RESET} {results['png']}")
        else:
            print(f" {YELLOW}[Notice] {results.get('matplotlib_status')}{RESET}")

        if "svg" in results:
            print(f" {GREEN}✔ Vector SVG Chart generated:{RESET} {results['svg']}")

    def handle_multi_format_export(self) -> None:
        """Workflow 6: Generates structured Markdown, plain-text audit logs, and CSV."""
        summary = WeatherAnalyticsEngine.generate_executive_summary(self.records)
        print(f"\n {YELLOW}⚡ Exporting multi-format reports to {self.exports_dir}...{RESET}")

        res = MultiFormatExporter.export_all_formats(self.records, summary, self.exports_dir)
        print(f" {GREEN}✔ Markdown Executive Report:{RESET}   {res['markdown']}")
        print(f" {GREEN}✔ Plain-Text Audit Log:       {RESET}   {res['audit_log']}")
        print(f" {GREEN}✔ Standardized RFC-4180 CSV:  {RESET}   {res['csv']}\n")

    def handle_bulk_import(self) -> None:
        """Workflow 7: Ingests legacy CSV dataset with automatic format validation and error logs."""
        print(f"\n{BOLD}{BLUE}--- [BULK DATASET IMPORT] ---{RESET}")
        default_csv = os.path.join(self.data_dir, "sample_legacy_import.csv")
        print(f" {DIM}Enter CSV file path to ingest.{RESET}")
        filepath = input(f" {CYAN}CSV File Path [{default_csv}]:{RESET} ").strip()
        if not filepath:
            filepath = default_csv

        if not os.path.exists(filepath):
            print(f" {RED}[Error] File not found at '{filepath}'.{RESET}")
            return

        print(f" {YELLOW}⚡ Ingesting and performing defensive row-by-row validation...{RESET}")
        valid_recs, error_logs, total_rows = BulkDatasetImporter.import_csv_file(filepath)

        print(f"\n{BOLD}{WHITE}Bulk Import Audit Results:{RESET}")
        print(f"  • Total Rows Evaluated:  {BOLD}{total_rows}{RESET}")
        print(f"  • Valid Records Ingested: {GREEN}{BOLD}{len(valid_recs)}{RESET}")
        print(f"  • Defective Rows Flagged: {RED}{BOLD}{len(error_logs)}{RESET}")

        if error_logs:
            print(f"\n{BOLD}{RED}Detailed Row-by-Row Error Log:{RESET}")
            for err in error_logs:
                line = err.get("line")
                errs = err.get("errors", [err.get("error")])
                print(f"  {RED}Line {line:>2}:{RESET} {'; '.join(errs)}")

        if valid_recs:
            for vr in valid_recs:
                self.storage.append_record(vr)
                self.records.append(vr)
            print(f"\n {GREEN}✔ Successfully merged {len(valid_recs)} valid records into persistent storage.{RESET}\n")

    def handle_delete_record(self) -> None:
        """Workflow 8: Deletes record by ID."""
        rec_id = input(f" {CYAN}Enter Record ID to delete (e.g. WTR-1001):{RESET} ").strip()
        if not rec_id:
            return
        success = self.storage.delete_record_by_id(rec_id)
        if success:
            self.records = [r for r in self.records if r.id != rec_id]
            print(f" {GREEN}✔ Record '{rec_id}' removed from JSON & CSV persistence.{RESET}")
        else:
            print(f" {YELLOW}[Notice] Record ID '{rec_id}' not found.{RESET}")

    def handle_launch_tkinter_gui(self) -> None:
        """Workflow 9: Launches lightweight Graphical Interface (Tkinter)."""
        print(f"\n {YELLOW}⚡ Launching lightweight Tkinter Graphical Interface window...{RESET}")
        try:
            import subprocess
            gui_script = os.path.join(CURRENT_DIR, "gui.py")
            subprocess.Popen([sys.executable, gui_script])
            print(f" {GREEN}✔ Desktop Tkinter GUI launched in standalone window.{RESET}\n")
        except Exception as e:
            print(f" {RED}[Error] Could not launch Desktop GUI: {e}{RESET}\n")

    def handle_launch_web_dashboard(self) -> None:
        """Workflow 10: Instructions to open or run the Web Dashboard Website."""
        web_index = os.path.join(CURRENT_DIR, "web", "index.html")
        print(f"\n{BOLD}{CYAN}=== WEB DASHBOARD WEBSITE READY ==={RESET}")
        print(f" The website is fully implemented and accessible in multiple ways:")
        print(f"   1. Direct Browser Open: Open {BOLD}{web_index}{RESET} directly in Chrome/Edge/Firefox.")
        print(f"   2. Dedicated Server: Run {BOLD}python app.py{RESET} to launch the interactive local server on http://localhost:8080")
        print(f"   3. Standalone HTML5/CSS/JS frontend works offline with instant sample data & live Open-Meteo fetching!\n")

    def handle_exit(self) -> None:
        """Clean shutdown verifying persistence preservation."""
        print(f"\n {YELLOW}Preserving application state...{RESET}")
        self.storage.save_all_records(self.records)
        print(f" {GREEN}✔ All {len(self.records)} records preserved across JSON & CSV.{RESET}")
        print(f" {CYAN}Thank you for using CampusSolve Public API Weather Viewer. Goodbye!{RESET}\n")


if __name__ == "__main__":
    try:
        app = WeatherViewerApp()
        app.run()
    except (KeyboardInterrupt, EOFError):
        print(f"\n\n {YELLOW}[Exiting] Program terminated by user.{RESET}")
        sys.exit(0)
