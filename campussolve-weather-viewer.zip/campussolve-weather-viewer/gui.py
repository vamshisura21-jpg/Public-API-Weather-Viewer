#!/usr/bin/env python3
"""
gui.py - Lightweight Graphical Interface (Tkinter) for CampusSolve #111
Public API Weather Viewer & Analytics Platform
Fulfills Section 4 & 5 Stretch Feature: "Optional lightweight Graphical Interface (Tkinter) for visual menu navigation"
"""

import os
import sys
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
from typing import List, Optional

# Ensure project root is in python path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from src.models import WeatherRecord, ExecutiveSummary
from src.validator import DefensiveValidator
from src.api_engine import PublicWeatherAPIClient
from src.storage import LocalStorageManager
from src.analytics import WeatherAnalyticsEngine
from src.visualizer import VisualDataPlotter
from src.exporter import MultiFormatExporter
from src.importer import BulkDatasetImporter

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


class WeatherViewerGUI(tk.Tk):
    """Modern, lightweight Tkinter Graphical Interface for Public API Weather Viewer."""

    def __init__(self):
        super().__init__()
        self.title("CampusSolve #111 : Public API Weather Viewer & Analytics")
        self.geometry("1100x750")
        self.minsize(980, 680)

        # File paths
        self.data_dir = os.path.join(CURRENT_DIR, "data")
        self.exports_dir = os.path.join(CURRENT_DIR, "exports")
        self.json_path = os.path.join(self.data_dir, "weather_records.json")
        self.csv_path = os.path.join(self.data_dir, "weather_records.csv")
        self.chart_png_path = os.path.join(self.exports_dir, "weather_trend_chart.png")
        self.chart_svg_path = os.path.join(self.exports_dir, "weather_trend_chart.svg")

        # Storage & data state
        self.storage = LocalStorageManager(self.json_path, self.csv_path)
        self.records: List[WeatherRecord] = []
        self.last_fetched_record: Optional[WeatherRecord] = None
        self.chart_photo = None  # To retain image reference

        # Configure Theme & Styling
        self.configure_styles()

        # Build UI layout
        self.create_header()
        self.create_notebook()
        self.create_statusbar()

        # Initial load
        self.reload_records()

    def configure_styles(self):
        """Sets up a clean, modern color scheme and ttk widget styles."""
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass

        # Color palette
        self.BG_MAIN = "#0f172a"
        self.BG_CARD = "#1e293b"
        self.BG_HEADER = "#090d16"
        self.FG_TEXT = "#f8fafc"
        self.FG_MUTED = "#94a3b8"
        self.ACCENT_CYAN = "#0ea5e9"
        self.ACCENT_GREEN = "#10b981"
        self.ACCENT_RED = "#ef4444"
        self.ACCENT_YELLOW = "#f59e0b"

        self.configure(bg=self.BG_MAIN)

        self.style.configure(".", background=self.BG_MAIN, foreground=self.FG_TEXT, font=("Segoe UI", 10))
        self.style.configure("TNotebook", background=self.BG_MAIN, tabmargins=[4, 4, 4, 0])
        self.style.configure("TNotebook.Tab", background="#1e293b", foreground=self.FG_MUTED, padding=[16, 8], font=("Segoe UI", 10, "bold"))
        self.style.map("TNotebook.Tab", background=[("selected", self.ACCENT_CYAN)], foreground=[("selected", "#ffffff")])

        self.style.configure("TFrame", background=self.BG_MAIN)
        self.style.configure("Card.TFrame", background=self.BG_CARD, relief="flat")
        self.style.configure("TLabel", background=self.BG_MAIN, foreground=self.FG_TEXT)
        self.style.configure("Card.TLabel", background=self.BG_CARD, foreground=self.FG_TEXT)
        self.style.configure("Muted.TLabel", background=self.BG_MAIN, foreground=self.FG_MUTED, font=("Segoe UI", 9))
        self.style.configure("Header.TLabel", background=self.BG_HEADER, foreground="#ffffff", font=("Segoe UI", 15, "bold"))

        # Buttons
        self.style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=[12, 6])
        self.style.configure("Action.TButton", font=("Segoe UI", 9, "bold"), padding=[10, 5])

        # Treeview (Table)
        self.style.configure("Treeview", background="#1e293b", foreground="#f8fafc", fieldbackground="#1e293b", rowheight=26, font=("Segoe UI", 9))
        self.style.configure("Treeview.Heading", background="#334155", foreground="#ffffff", font=("Segoe UI", 9, "bold"), relief="flat")
        self.style.map("Treeview", background=[("selected", "#0284c7")], foreground=[("selected", "#ffffff")])

    def create_header(self):
        """Top branded banner matching Hackathon Project #111 identity."""
        header_frame = tk.Frame(self, bg=self.BG_HEADER, height=64)
        header_frame.pack(fill="x", side="top")

        title_lbl = tk.Label(
            header_frame,
            text="CAMPUSSOLVE #111 : PUBLIC API WEATHER VIEWER",
            bg=self.BG_HEADER,
            fg="#38bdf8",
            font=("Segoe UI", 14, "bold")
        )
        title_lbl.pack(anchor="w", padx=20, pady=(10, 2))

        sub_lbl = tk.Label(
            header_frame,
            text="Domain: AI, APIs & Smart Applications | Automated Persistence, Validation & Visual Plotting",
            bg=self.BG_HEADER,
            fg=self.FG_MUTED,
            font=("Segoe UI", 9)
        )
        sub_lbl.pack(anchor="w", padx=20, pady=(0, 10))

    def create_notebook(self):
        """Main tabbed navigation structure."""
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=16, pady=12)

        # Create Tab Pages
        self.tab_fetch = ttk.Frame(self.notebook)
        self.tab_records = ttk.Frame(self.notebook)
        self.tab_analytics = ttk.Frame(self.notebook)
        self.tab_charts = ttk.Frame(self.notebook)
        self.tab_import = ttk.Frame(self.notebook)
        self.tab_export = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_fetch, text=" 📍 Fetch Live API ")
        self.notebook.add(self.tab_records, text=" 📋 Stored Records ")
        self.notebook.add(self.tab_analytics, text=" 📊 Executive Summary ")
        self.notebook.add(self.tab_charts, text=" 📈 Visual Charts ")
        self.notebook.add(self.tab_import, text=" 📥 Bulk CSV Import ")
        self.notebook.add(self.tab_export, text=" 📤 Multi-Format Export ")

        # Build each tab view
        self.build_fetch_tab()
        self.build_records_tab()
        self.build_analytics_tab()
        self.build_charts_tab()
        self.build_import_tab()
        self.build_export_tab()

    def create_statusbar(self):
        """Bottom status indicator."""
        self.status_var = tk.StringVar(value="Ready. Initialized local JSON & CSV persistence.")
        status_bar = tk.Label(
            self,
            textvariable=self.status_var,
            bg="#090d16",
            fg=self.FG_MUTED,
            font=("Segoe UI", 9),
            anchor="w",
            padx=16,
            pady=4
        )
        status_bar.pack(fill="x", side="bottom")

    # =========================================================================
    # TAB 1: FETCH LIVE WEATHER (PUBLIC API & DEFENSIVE VALIDATION)
    # =========================================================================
    def build_fetch_tab(self):
        container = ttk.Frame(self.tab_fetch)
        container.pack(fill="both", expand=True, padx=20, pady=16)

        # Input Card
        input_card = tk.LabelFrame(
            container,
            text=" Query Open-Meteo Public API (Keyless & Real-Time) ",
            bg=self.BG_CARD,
            fg="#38bdf8",
            font=("Segoe UI", 11, "bold"),
            padx=16,
            pady=14
        )
        input_card.pack(fill="x", pady=(0, 16))

        row1 = tk.Frame(input_card, bg=self.BG_CARD)
        row1.pack(fill="x", pady=4)

        tk.Label(row1, text="City Name:", bg=self.BG_CARD, fg="#ffffff", font=("Segoe UI", 10, "bold")).pack(side="left", padx=(0, 8))
        self.city_entry = tk.Entry(row1, font=("Segoe UI", 11), width=28, bg="#0f172a", fg="#ffffff", insertbackground="#ffffff")
        self.city_entry.insert(0, "Tokyo")
        self.city_entry.pack(side="left", padx=(0, 12))
        self.city_entry.bind("<Return>", lambda e: self.on_fetch_weather())

        fetch_btn = tk.Button(
            row1,
            text="⚡ Fetch Weather Data",
            command=self.on_fetch_weather,
            bg="#0284c7",
            fg="#ffffff",
            font=("Segoe UI", 10, "bold"),
            activebackground="#0369a1",
            relief="flat",
            padx=14,
            pady=4,
            cursor="hand2"
        )
        fetch_btn.pack(side="left", padx=4)

        # Quick city presets
        preset_frame = tk.Frame(input_card, bg=self.BG_CARD)
        preset_frame.pack(fill="x", pady=(10, 0))
        tk.Label(preset_frame, text="Quick Presets:", bg=self.BG_CARD, fg=self.FG_MUTED, font=("Segoe UI", 9)).pack(side="left", padx=(0, 8))
        for preset in ["London", "New York", "Paris", "Singapore", "Sydney", "Mumbai", "San Francisco"]:
            btn = tk.Button(
                preset_frame,
                text=preset,
                command=lambda p=preset: self.set_preset_city(p),
                bg="#334155",
                fg="#f8fafc",
                font=("Segoe UI", 8),
                relief="flat",
                padx=8,
                pady=2,
                cursor="hand2"
            )
            btn.pack(side="left", padx=3)

        # Observation Card Display
        self.card_frame = tk.LabelFrame(
            container,
            text=" Meteorological Observation Card & Threshold Warning Flags ",
            bg=self.BG_CARD,
            fg="#38bdf8",
            font=("Segoe UI", 11, "bold"),
            padx=18,
            pady=16
        )
        self.card_frame.pack(fill="both", expand=True)

        self.display_text = tk.Text(
            self.card_frame,
            bg="#0f172a",
            fg="#f8fafc",
            font=("Consolas", 10),
            wrap="word",
            relief="flat",
            padx=12,
            pady=10
        )
        self.display_text.pack(fill="both", expand=True, side="left")
        self.display_text.insert(
            "1.0",
            "Enter a city name above and click 'Fetch Weather Data' to query the Open-Meteo public API.\n\n"
            "Key Values Displayed:\n"
            "  • Temperature (°C / °F) & Apparent Feel\n"
            "  • Relative Humidity, Wind Speed, Barometric Surface Pressure\n"
            "  • Precipitation (mm) & WMO Weather Condition\n"
            "  • Automated Threshold Warnings & Deadline Verifications\n"
        )
        self.display_text.config(state="disabled")

        # Save Action Button
        action_frame = tk.Frame(self.card_frame, bg=self.BG_CARD)
        action_frame.pack(fill="y", side="right", padx=(12, 0))

        self.save_btn = tk.Button(
            action_frame,
            text="💾 Save Record\nto Local DB",
            command=self.on_save_fetched_record,
            bg=self.ACCENT_GREEN,
            fg="#ffffff",
            font=("Segoe UI", 10, "bold"),
            state="disabled",
            relief="flat",
            padx=12,
            pady=10,
            cursor="hand2"
        )
        self.save_btn.pack(fill="x", pady=6)

    def set_preset_city(self, city_name: str):
        self.city_entry.delete(0, tk.END)
        self.city_entry.insert(0, city_name)
        self.on_fetch_weather()

    def on_fetch_weather(self):
        raw_city = self.city_entry.get()
        # Defensive Input Validation
        val_res = DefensiveValidator.validate_city_name(raw_city)
        if not val_res.is_valid:
            messagebox.showerror("Validation Error", f"Input validation failed:\n{val_res.error_message}")
            return

        cleaned_city = val_res.cleaned_value
        self.status_var.set(f"Querying Open-Meteo API for '{cleaned_city}'...")
        self.update_idletasks()

        record, msg = PublicWeatherAPIClient.fetch_current_weather(cleaned_city)
        self.last_fetched_record = record
        self.save_btn.config(state="normal")
        self.status_var.set(f"✔ {msg}")

        # Render formatted card
        self.display_text.config(state="normal")
        self.display_text.delete("1.0", tk.END)

        card_lines = [
            f"╔════════════════════════════════════════════════════════════════════════════╗",
            f"  METEOROLOGICAL OBSERVATION : {record.city.upper()}, {record.country.upper()}",
            f"╠════════════════════════════════════════════════════════════════════════════╣",
            f"  Record ID:             {record.id}",
            f"  Coordinates:           {record.latitude:.4f}° N/S, {record.longitude:.4f}° E/W",
            f"  Temperature:           {record.temperature_c}°C ({record.temperature_f}°F)",
            f"  Apparent Temperature:  {record.apparent_temperature_c}°C",
            f"  Condition:             {record.condition_description} (WMO Code {record.weather_code})",
            f"  Relative Humidity:     {record.humidity_pct}%",
            f"  Wind Velocity:         {record.wind_speed_kmh} km/h ({record.wind_speed_mph} mph)",
            f"  Precipitation:         {record.precipitation_mm} mm",
            f"  Surface Pressure:      {record.surface_pressure_hpa} hPa",
            f"  Timestamp:             {record.recorded_at}",
            f"  Data Source:           {record.data_source}",
            f"╠════════════════════════════════════════════════════════════════════════════╣",
            f"  THRESHOLD WARNING INDICATORS & OPERATIONAL FLAGS:"
        ]
        for flag in record.status_indicators:
            card_lines.append(f"    ● {flag}")
        card_lines.append(f"╚════════════════════════════════════════════════════════════════════════════╝")

        self.display_text.insert("1.0", "\n".join(card_lines))
        self.display_text.config(state="disabled")

    def on_save_fetched_record(self):
        if not self.last_fetched_record:
            return
        saved = self.storage.append_record(self.last_fetched_record)
        if saved:
            self.reload_records()
            messagebox.showinfo("Saved", f"Record '{self.last_fetched_record.city}' saved to JSON & CSV database!")
            self.save_btn.config(state="disabled")
            self.status_var.set(f"Record {self.last_fetched_record.id} persisted successfully.")
        else:
            messagebox.showerror("Error", "Could not persist record to local storage.")

    # =========================================================================
    # TAB 2: STORED RECORDS & QUERY SEARCH
    # =========================================================================
    def build_records_tab(self):
        container = ttk.Frame(self.tab_records)
        container.pack(fill="both", expand=True, padx=16, pady=12)

        # Filter bar
        filter_bar = tk.Frame(container, bg=self.BG_CARD, padx=12, pady=8)
        filter_bar.pack(fill="x", pady=(0, 10))

        tk.Label(filter_bar, text="Search Keyword:", bg=self.BG_CARD, fg="#ffffff", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 6))
        self.search_entry = tk.Entry(filter_bar, font=("Segoe UI", 9), width=18, bg="#0f172a", fg="#ffffff", insertbackground="#ffffff")
        self.search_entry.pack(side="left", padx=(0, 12))
        self.search_entry.bind("<KeyRelease>", lambda e: self.apply_filters())

        tk.Label(filter_bar, text="Condition:", bg=self.BG_CARD, fg="#ffffff", font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 6))
        self.cond_combobox = ttk.Combobox(filter_bar, values=["All", "Clear", "Cloudy", "Rain", "Snow", "Fog", "Thunderstorm"], width=12, state="readonly")
        self.cond_combobox.set("All")
        self.cond_combobox.pack(side="left", padx=(0, 12))
        self.cond_combobox.bind("<<ComboboxSelected>>", lambda e: self.apply_filters())

        self.alerts_only_var = tk.BooleanVar(value=False)
        chk = tk.Checkbutton(
            filter_bar,
            text="Critical / Warnings Only",
            variable=self.alerts_only_var,
            command=self.apply_filters,
            bg=self.BG_CARD,
            fg="#f59e0b",
            selectcolor="#0f172a",
            activebackground=self.BG_CARD,
            font=("Segoe UI", 9, "bold")
        )
        chk.pack(side="left", padx=(0, 12))

        refresh_btn = tk.Button(
            filter_bar,
            text="🔄 Refresh",
            command=self.reload_records,
            bg="#334155",
            fg="#ffffff",
            relief="flat",
            padx=10,
            pady=3,
            cursor="hand2"
        )
        refresh_btn.pack(side="right", padx=4)

        del_btn = tk.Button(
            filter_bar,
            text="🗑 Delete Selected",
            command=self.on_delete_selected_record,
            bg=self.ACCENT_RED,
            fg="#ffffff",
            relief="flat",
            padx=10,
            pady=3,
            cursor="hand2"
        )
        del_btn.pack(side="right", padx=4)

        # Treeview Table
        columns = ("id", "city", "country", "temp", "humidity", "wind", "precip", "condition", "status")
        self.tree = ttk.Treeview(container, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="ID")
        self.tree.heading("city", text="City")
        self.tree.heading("country", text="Country")
        self.tree.heading("temp", text="Temp (°C)")
        self.tree.heading("humidity", text="Humidity")
        self.tree.heading("wind", text="Wind (km/h)")
        self.tree.heading("precip", text="Precip (mm)")
        self.tree.heading("condition", text="Condition")
        self.tree.heading("status", text="Alert Status")

        self.tree.column("id", width=85, anchor="center")
        self.tree.column("city", width=120, anchor="w")
        self.tree.column("country", width=110, anchor="w")
        self.tree.column("temp", width=80, anchor="center")
        self.tree.column("humidity", width=80, anchor="center")
        self.tree.column("wind", width=95, anchor="center")
        self.tree.column("precip", width=85, anchor="center")
        self.tree.column("condition", width=140, anchor="w")
        self.tree.column("status", width=90, anchor="center")

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tree.bind("<<TreeviewSelect>>", self.on_record_selected)

    def apply_filters(self):
        kw = self.search_entry.get().strip() or None
        cond = self.cond_combobox.get().strip()
        alerts = self.alerts_only_var.get()

        filtered = WeatherAnalyticsEngine.filter_records(
            self.records,
            keyword=kw,
            condition_filter=None if cond == "All" else cond,
            alerts_only=alerts
        )
        self.populate_treeview(filtered)

    def populate_treeview(self, records_list: List[WeatherRecord]):
        for item in self.tree.get_children():
            self.tree.delete(item)

        for r in records_list:
            status_tag = "crit" if r.has_critical_alert else ("warn" if r.has_warning else "norm")
            status_text = "CRIT" if r.has_critical_alert else ("WARN" if r.has_warning else "OK")
            self.tree.insert(
                "",
                "end",
                iid=r.id,
                values=(
                    r.id,
                    r.city,
                    r.country,
                    f"{r.temperature_c:.1f}°C",
                    f"{r.humidity_pct:.1f}%",
                    f"{r.wind_speed_kmh:.1f}",
                    f"{r.precipitation_mm:.1f}",
                    r.condition_description,
                    status_text
                ),
                tags=(status_tag,)
            )

        self.tree.tag_configure("crit", foreground="#f87171")
        self.tree.tag_configure("warn", foreground="#fbbf24")
        self.tree.tag_configure("norm", foreground="#34d399")

    def on_record_selected(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        rec_id = selected[0]
        rec = next((r for r in self.records if r.id == rec_id), None)
        if rec:
            self.status_var.set(f"Selected Record: {rec.city} ({rec.country}) | Flags: {', '.join(rec.status_indicators)}")

    def on_delete_selected_record(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Select Record", "Please select a record from the table to delete.")
            return
        rec_id = selected[0]
        confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete record '{rec_id}'?")
        if confirm:
            self.storage.delete_record_by_id(rec_id)
            self.reload_records()
            messagebox.showinfo("Deleted", f"Record '{rec_id}' removed from persistence.")

    def reload_records(self):
        records, warning = self.storage.load_all_records()
        self.records = records
        self.populate_treeview(self.records)
        self.refresh_analytics_view()
        self.status_var.set(f"Loaded {len(self.records)} records from synchronized storage.")

    # =========================================================================
    # TAB 3: EXECUTIVE SUMMARY & ANALYTICS
    # =========================================================================
    def build_analytics_tab(self):
        container = ttk.Frame(self.tab_analytics)
        container.pack(fill="both", expand=True, padx=20, pady=16)

        # Title
        top_bar = tk.Frame(container, bg=self.BG_MAIN)
        top_bar.pack(fill="x", pady=(0, 12))
        tk.Label(top_bar, text="Executive Meteorological Summary & Trends", bg=self.BG_MAIN, fg="#38bdf8", font=("Segoe UI", 13, "bold")).pack(side="left")

        refresh_btn = tk.Button(
            top_bar,
            text="🔄 Re-calculate Metrics",
            command=self.refresh_analytics_view,
            bg="#0284c7",
            fg="#ffffff",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=10,
            pady=4,
            cursor="hand2"
        )
        refresh_btn.pack(side="right")

        # Metric Badges Frame
        self.metrics_container = tk.Frame(container, bg=self.BG_MAIN)
        self.metrics_container.pack(fill="x", pady=6)

        # Insights Text Card
        insights_card = tk.LabelFrame(
            container,
            text=" Trend Insights Commentary & Operational Alerts ",
            bg=self.BG_CARD,
            fg="#f59e0b",
            font=("Segoe UI", 10, "bold"),
            padx=16,
            pady=12
        )
        insights_card.pack(fill="both", expand=True, pady=(12, 0))

        self.insights_text = tk.Text(
            insights_card,
            bg="#0f172a",
            fg="#f8fafc",
            font=("Segoe UI", 10),
            wrap="word",
            relief="flat",
            padx=12,
            pady=10
        )
        self.insights_text.pack(fill="both", expand=True)

    def refresh_analytics_view(self):
        for widget in self.metrics_container.winfo_children():
            widget.destroy()

        summary = WeatherAnalyticsEngine.generate_executive_summary(self.records)
        if not summary:
            return

        insights = WeatherAnalyticsEngine.compute_trend_insights(self.records)

        # Metric Badges
        metrics = [
            ("Total Stations", f"{summary.total_records}", "#38bdf8"),
            ("Avg Temperature", f"{summary.avg_temperature_c}°C", "#10b981"),
            ("Thermal Extremes", f"{summary.min_temperature_c}°C / {summary.max_temperature_c}°C", "#f59e0b"),
            ("Median Temp", f"{summary.median_temperature_c}°C", "#a855f7"),
            ("Mean Humidity", f"{summary.avg_humidity_pct}%", "#38bdf8"),
            ("Avg Wind Velocity", f"{summary.avg_wind_speed_kmh} km/h", "#14b8a6"),
            ("Total Precip", f"{summary.total_precipitation_mm} mm", "#6366f1"),
            ("Critical Alerts", f"{summary.critical_alerts_count}", "#ef4444"),
            ("Warning Advisories", f"{summary.warning_alerts_count}", "#f59e0b"),
            ("Nominal Stations", f"{summary.nominal_count}", "#10b981"),
        ]

        # Arrange badges in grid
        for idx, (lbl, val, col) in enumerate(metrics):
            row = idx // 5
            col_idx = idx % 5
            card = tk.Frame(self.metrics_container, bg=self.BG_CARD, padx=12, pady=10, relief="flat")
            card.grid(row=row, column=col_idx, padx=6, pady=6, sticky="nsew")
            self.metrics_container.columnconfigure(col_idx, weight=1)

            tk.Label(card, text=lbl, bg=self.BG_CARD, fg=self.FG_MUTED, font=("Segoe UI", 8)).pack(anchor="w")
            tk.Label(card, text=val, bg=self.BG_CARD, fg=col, font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(2, 0))

        # Insights Commentary
        self.insights_text.config(state="normal")
        self.insights_text.delete("1.0", tk.END)
        for ins in insights:
            self.insights_text.insert(tk.END, f"  ▸ {ins}\n\n")
        self.insights_text.config(state="disabled")

    # =========================================================================
    # TAB 4: VISUAL DATA PLOTTING (MATPLOTLIB & SVG DASHBOARD)
    # =========================================================================
    def build_charts_tab(self):
        container = ttk.Frame(self.tab_charts)
        container.pack(fill="both", expand=True, padx=20, pady=14)

        # Control bar
        ctl_bar = tk.Frame(container, bg=self.BG_MAIN)
        ctl_bar.pack(fill="x", pady=(0, 10))

        tk.Label(ctl_bar, text="Graphical Trend Charts & Visual Distributions", bg=self.BG_MAIN, fg="#38bdf8", font=("Segoe UI", 12, "bold")).pack(side="left")

        render_btn = tk.Button(
            ctl_bar,
            text="⚡ Render / Refresh Charts",
            command=self.render_visual_charts,
            bg="#0284c7",
            fg="#ffffff",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2"
        )
        render_btn.pack(side="right", padx=6)

        svg_btn = tk.Button(
            ctl_bar,
            text="🌐 Open SVG in Browser",
            command=self.open_svg_chart,
            bg="#334155",
            fg="#ffffff",
            font=("Segoe UI", 9),
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2"
        )
        svg_btn.pack(side="right", padx=6)

        # Chart Canvas / Display Frame
        self.chart_display_frame = tk.Frame(container, bg=self.BG_CARD)
        self.chart_display_frame.pack(fill="both", expand=True)

        self.chart_lbl = tk.Label(self.chart_display_frame, bg=self.BG_CARD, text="Click 'Render / Refresh Charts' to generate visual distribution plots.")
        self.chart_lbl.pack(fill="both", expand=True, padx=10, pady=10)

    def render_visual_charts(self):
        summary = WeatherAnalyticsEngine.generate_executive_summary(self.records)
        if not summary:
            messagebox.showwarning("No Data", "No records available to plot.")
            return

        self.status_var.set("Rendering Matplotlib PNG and Vector SVG charts...")
        self.update_idletasks()

        res = VisualDataPlotter.plot_and_export(
            self.records,
            summary,
            self.chart_png_path,
            self.chart_svg_path
        )

        if "png" in res and os.path.exists(res["png"]) and HAS_PIL:
            try:
                img = Image.open(res["png"])
                # Resize to fit window comfortably
                img.thumbnail((900, 480), Image.Resampling.LANCZOS)
                self.chart_photo = ImageTk.PhotoImage(img)
                self.chart_lbl.configure(image=self.chart_photo, text="")
                self.status_var.set("✔ Visual charts rendered and displayed successfully.")
            except Exception as e:
                self.chart_lbl.configure(text=f"Rendered image saved at {self.chart_png_path}\n(Display note: {e})")
        else:
            status_msg = res.get("matplotlib_status", "Generated charts.")
            self.chart_lbl.configure(text=f"{status_msg}\n\nVector SVG chart ready: {self.chart_svg_path}\nClick 'Open SVG in Browser' to view high-res vector visuals.")
            self.status_var.set("Charts exported to disk.")

    def open_svg_chart(self):
        if os.path.exists(self.chart_svg_path):
            webbrowser.open(f"file://{os.path.abspath(self.chart_svg_path)}")
        else:
            self.render_visual_charts()
            if os.path.exists(self.chart_svg_path):
                webbrowser.open(f"file://{os.path.abspath(self.chart_svg_path)}")

    # =========================================================================
    # TAB 5: BULK DATASET IMPORT (CSV WITH ROW-BY-ROW ERROR LOGS)
    # =========================================================================
    def build_import_tab(self):
        container = ttk.Frame(self.tab_import)
        container.pack(fill="both", expand=True, padx=20, pady=14)

        # File Chooser Bar
        choose_frame = tk.LabelFrame(
            container,
            text=" Select Legacy CSV Dataset to Ingest ",
            bg=self.BG_CARD,
            fg="#38bdf8",
            font=("Segoe UI", 11, "bold"),
            padx=14,
            pady=12
        )
        choose_frame.pack(fill="x", pady=(0, 14))

        self.import_path_entry = tk.Entry(choose_frame, font=("Segoe UI", 10), bg="#0f172a", fg="#ffffff", insertbackground="#ffffff")
        default_csv = os.path.join(self.data_dir, "sample_legacy_import.csv")
        self.import_path_entry.insert(0, default_csv)
        self.import_path_entry.pack(side="left", fill="x", expand=True, padx=(0, 10))

        browse_btn = tk.Button(
            choose_frame,
            text="📁 Browse...",
            command=self.browse_csv_file,
            bg="#334155",
            fg="#ffffff",
            relief="flat",
            padx=10,
            pady=3,
            cursor="hand2"
        )
        browse_btn.pack(side="left", padx=4)

        run_import_btn = tk.Button(
            choose_frame,
            text="📥 Validate & Ingest",
            command=self.run_bulk_import,
            bg=self.ACCENT_GREEN,
            fg="#ffffff",
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2"
        )
        run_import_btn.pack(side="left", padx=4)

        # Ingestion Audit Summary
        self.import_stats_lbl = tk.Label(
            container,
            text="Ready to ingest. Enter or browse for CSV file with legacy observations.",
            bg=self.BG_MAIN,
            fg=self.FG_MUTED,
            font=("Segoe UI", 9)
        )
        self.import_stats_lbl.pack(anchor="w", pady=(0, 8))

        # Defect Log Treeview
        log_frame = tk.LabelFrame(
            container,
            text=" Row-by-Row Error Log (Rejected Non-Conforming Entries) ",
            bg=self.BG_CARD,
            fg="#ef4444",
            font=("Segoe UI", 10, "bold"),
            padx=10,
            pady=10
        )
        log_frame.pack(fill="both", expand=True)

        cols = ("line", "city", "error")
        self.err_tree = ttk.Treeview(log_frame, columns=cols, show="headings")
        self.err_tree.heading("line", text="Line #")
        self.err_tree.heading("city", text="Reported City")
        self.err_tree.heading("error", text="Defensive Validation Rejection Reason")

        self.err_tree.column("line", width=70, anchor="center")
        self.err_tree.column("city", width=140, anchor="w")
        self.err_tree.column("error", width=580, anchor="w")

        err_scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.err_tree.yview)
        self.err_tree.configure(yscrollcommand=err_scroll.set)

        self.err_tree.pack(side="left", fill="both", expand=True)
        err_scroll.pack(side="right", fill="y")

    def browse_csv_file(self):
        f = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")])
        if f:
            self.import_path_entry.delete(0, tk.END)
            self.import_path_entry.insert(0, f)

    def run_bulk_import(self):
        filepath = self.import_path_entry.get().strip()
        if not os.path.exists(filepath):
            messagebox.showerror("File Not Found", f"Specified path does not exist:\n{filepath}")
            return

        for item in self.err_tree.get_children():
            self.err_tree.delete(item)

        valid_recs, error_logs, total_rows = BulkDatasetImporter.import_csv_file(filepath)

        self.import_stats_lbl.configure(
            text=f"Ingestion Audit: {total_rows} Rows Read | {len(valid_recs)} Valid Records Merged | {len(error_logs)} Defective Rows Rejected",
            fg="#10b981" if len(valid_recs) > 0 else "#ef4444"
        )

        for err in error_logs:
            line_no = err.get("line", "?")
            city = err.get("city", "N/A")
            err_reasons = "; ".join(err.get("errors", [err.get("error", "Unknown")]))
            self.err_tree.insert("", "end", values=(line_no, city, err_reasons))

        if valid_recs:
            for vr in valid_recs:
                self.storage.append_record(vr)
            self.reload_records()
            messagebox.showinfo("Import Complete", f"Successfully validated and merged {len(valid_recs)} records!\n{len(error_logs)} defective rows were logged and rejected.")

    # =========================================================================
    # TAB 6: MULTI-FORMAT EXPORT (MARKDOWN / AUDIT LOG / CSV)
    # =========================================================================
    def build_export_tab(self):
        container = ttk.Frame(self.tab_export)
        container.pack(fill="both", expand=True, padx=20, pady=16)

        info_card = tk.LabelFrame(
            container,
            text=" Multi-Format External Summary & Compliance Export ",
            bg=self.BG_CARD,
            fg="#38bdf8",
            font=("Segoe UI", 11, "bold"),
            padx=18,
            pady=16
        )
        info_card.pack(fill="x", pady=(0, 16))

        tk.Label(
            info_card,
            text="Generates three standardized reports for external review and audit:\n"
                 "  1. Structured Markdown Executive Report (exports/summary_report.md)\n"
                 "  2. Plain-Text System Audit Log (exports/audit_log.txt)\n"
                 "  3. RFC-4180 Standardized CSV Data Export (exports/weather_export.csv)",
            bg=self.BG_CARD,
            fg="#cbd5e1",
            font=("Segoe UI", 10),
            justify="left"
        ).pack(anchor="w", pady=(0, 12))

        btn_row = tk.Frame(info_card, bg=self.BG_CARD)
        btn_row.pack(fill="x", pady=6)

        export_btn = tk.Button(
            btn_row,
            text="⚡ Export All Formats Now",
            command=self.run_multi_format_export,
            bg=self.ACCENT_GREEN,
            fg="#ffffff",
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=16,
            pady=8,
            cursor="hand2"
        )
        export_btn.pack(side="left", padx=(0, 10))

        open_folder_btn = tk.Button(
            btn_row,
            text="📂 Open Exports Folder",
            command=self.open_exports_folder,
            bg="#334155",
            fg="#ffffff",
            font=("Segoe UI", 10),
            relief="flat",
            padx=12,
            pady=8,
            cursor="hand2"
        )
        open_folder_btn.pack(side="left")

        # Result display
        self.export_results_text = tk.Text(
            container,
            bg="#0f172a",
            fg="#f8fafc",
            font=("Consolas", 10),
            wrap="word",
            relief="flat",
            padx=14,
            pady=12
        )
        self.export_results_text.pack(fill="both", expand=True)
        self.export_results_text.insert("1.0", "Click 'Export All Formats Now' to generate external audit packages.")
        self.export_results_text.config(state="disabled")

    def run_multi_format_export(self):
        summary = WeatherAnalyticsEngine.generate_executive_summary(self.records)
        res = MultiFormatExporter.export_all_formats(self.records, summary, self.exports_dir)

        self.export_results_text.config(state="normal")
        self.export_results_text.delete("1.0", tk.END)

        out_lines = [
            "✔ MULTI-FORMAT EXPORT COMPLETED SUCCESSFULLY!",
            "=" * 60,
            f"Target Directory: {self.exports_dir}",
            f"Total Records Included: {len(self.records)}",
            "",
            "Generated Files:",
            f"  [1] Markdown Executive Report: {res['markdown']}",
            f"  [2] Chronological Audit Log:    {res['audit_log']}",
            f"  [3] Standardized RFC-4180 CSV:  {res['csv']}",
            "",
            "All exported artifacts comply with domain specifications."
        ]
        self.export_results_text.insert("1.0", "\n".join(out_lines))
        self.export_results_text.config(state="disabled")
        messagebox.showinfo("Export Successful", f"Exported 3 formats successfully to:\n{self.exports_dir}")

    def open_exports_folder(self):
        os.makedirs(self.exports_dir, exist_ok=True)
        if sys.platform == "win32":
            os.startfile(self.exports_dir)
        else:
            webbrowser.open(f"file://{os.path.abspath(self.exports_dir)}")


def launch_gui():
    """Entry point for standalone Tkinter GUI execution."""
    app = WeatherViewerGUI()
    app.mainloop()


if __name__ == "__main__":
    launch_gui()
